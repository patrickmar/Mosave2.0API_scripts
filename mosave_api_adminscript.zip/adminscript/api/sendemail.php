<?php 
date_default_timezone_set('Africa/Lagos');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/* Exception class. */
require_once 'PHPMailer/src/Exception.php';

/* The main PHPMailer class. */
require_once 'PHPMailer/src/PHPMailer.php';

/* SMTP class, needed if you want to use SMTP. */
//require_once '/home/speckl7/gr8jobs.specklessinnovations.com/PHPMailer/src/SMTP.php';

require_once 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(TRUE);

 
    try {
   /* Set the mail sender. */
   $mail->setFrom('care@moloyal.com', 'Darth Vader');

   /* Add a recipient. */
   
//   foreach($to as $to_add){
// $mail->AddAddress($to_add);                  // name is optional
// }
  
$mail = new PHPMailer();
  $mail->SMTPDebug = 0;
  $mail->CharSet = 'UTF-8';
  $mail->isSMTP();
  $mail->SMTPAuth   = true;
  $mail->Host   = "mail.moloyal.com";
  $mail->Port       = 465;
  
  $mail->SMTPSecure = "ssl";




  									//Sets Mailer to send message using SMTP
						//Sets SMTP authentication. Utilizes the Username and Password variables
	$mail->Username = 'care@moloyal.com';					//Sets SMTP username
	$mail->Password = 'Welcome@13#';					//Sets SMTP password
		

	$mail->From = 'care@moloyal.com';			//Sets the From email address for the message
	$mail->FromName = 'Decima  and Co. Support';			//Sets the From name of the message
 $mail->addAddress('oluodebiyi@gmail.com', 'Emperor');

   /* Set the subject. */
   $mail->Subject = 'Forc22e';

   /* Set the mail message body. */
   $mail->Body = 'There is a great disturbance in the Force.';
	$mail->WordWrap = 50;						//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);	
   /* Finally send the mail. */
   $mail->send();
   /* Finally send the mail. */
if (!$mail->send())
{
   /* PHPMailer error. */
   echo $mail->ErrorInfo;
}

}
catch (Exception $e)
{
   /* PHPMailer exception. */
   echo $e->errorMessage();
}
catch (\Exception $e)
{
   /* PHP exception (note the backslash to select the global namespace Exception class). */
   echo $e->getMessage();
}