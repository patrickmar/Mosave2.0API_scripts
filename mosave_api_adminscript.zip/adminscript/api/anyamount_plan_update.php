<?php
date_default_timezone_set('Africa/Lagos');
//connect to db

 $dbs = getConnection();
    $planId=4; 
    
    $dateCreated=date("Y-m-d");
  $ip='';  
 $time=date("H:i:s");
$date_time=$dateCreated.' '.$time;
$sqlsssa = "SELECT * FROM `savings_plan` WHERE sn=:pid";
       
        $stmtbsss = $dbs->prepare($sqlsssa);  
        $stmtbsss->bindParam("pid", $planId);
        
                $stmtbsss->execute();
                $resultsass = $stmtbsss->fetch();
   $plans_id = $resultsass['sn'];              
  $plan_name = $resultsass['plan_name'];
 $savings_amount = $resultsass['plan_amount'];
 $days = $resultsass['days'];
 $percentage_commission = $resultsass['percentage_commission'];
 $money_commission = $resultsass['flat_commision'];
$billing_type = $resultsass['billing_type'];
 
$refs= getTransactionRef();



//                 $planwalletqry="SELECT `account_bal` as planwBalance, `available_bal` as planavailBalance, `customerId`, `accountId` FROM `mosave_plan_wallet` WHERE  plan_id=:pid  ";
   
//   $planwaldb = getConnection();
//         $planwalstmt = $planwaldb->prepare($planwalletqry);  
        
        
//          $planwalstmt->bindParam(":pid", $planId,PDO::PARAM_STR);
            

//  $planwalstmt->execute();
// 	 $reds = $planwalstmt->fetch();
// 	$accountId=$reds['accountId']; 
//  $customerId=$reds['customerId'];
//  $planwBalance=$reds['planwBalance'];
//   $planavailBalance=$reds['planavailBalance'];

// $walletqrys="SELECT `sn`, `agentId`, `accountId`, `accountNo`, `customerId`, `account_bal` FROM `mosave_wallet`  WHERE  customerId=:cid  ";
   
//   $planwaldb = getConnection();
//         $walstmts = $planwaldb->prepare($walletqrys);  
        
        
//          $walstmts->bindParam(":cid", $customerId,PDO::PARAM_STR);
            

//  $walstmts->execute();
// 	 $redsa = $walstmts->fetch();
	 
//  $customerId=$redsa['customerId'];
 
// $wal_account_bal=$redsa['account_bal'];

 $charge_type='';
 
//  if($billing_type=='P'){
     
//      if($planavailBalance!=''){
//  //do an insert into admin_ledger.admin_charge
// $admin_charge= ($planavailBalance * $percentage_commission)/100;
// }else{
//   $admin_charge=0;  
// }


// $charge_type='P';
// }
// if($billing_type=='F'){
//  //do an insert into admin_ledger.admin_charge
// $admin_charge=  $money_commission;
// $charge_type='F';
// }



     //echo $j=$planwalstmt->rowCount();    
     echo '<br>';
               
$m=1;

                      
               $plqry="SELECT `agentId`, `accountId`, `accountNo`, `customerId`, `plan_id`, `account_bal`, `available_bal`  FROM `mosave_plan_wallet` WHERE  plan_id=:pid  ";
   
   $planwaldb = getConnection();
        $plastmt = $planwaldb->prepare($plqry);  
        
        
         $plastmt->bindParam(":pid", $planId,PDO::PARAM_STR);
            

 $plastmt->execute();
	while( $redsplastmt = $plastmt->fetch()){
$accountId=$redsplastmt['accountId']; 
$accountNo=$redsplastmt['accountNo']; 
 $customerId=$redsplastmt['customerId']; 
$planId=$redsplastmt['plan_id']; 
$agentId=$redsplastmt['agentId']; 

// echo $customerId;
// echo '<br><br>';


  $vailBalance=$redsplastmt['available_bal']; 
  
//   echo $vailBalance.'initplan_available_bal';
// echo '<br><br>';
  
$walrys="SELECT `sn`, `agentId`, `accountId`, `accountNo`, `customerId`, `account_bal` FROM `mosave_wallet`  WHERE  customerId=:cid   ";
   
   $paldb = getConnection();
        $walmts = $paldb->prepare($walrys);  
        
        
         $walmts->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
            

 $walmts->execute();
	 $redsa_dd = $walmts->fetch();
	 

 
 $wal_acco_bl=$redsa_dd['account_bal'];
// echo $wal_acco_bl.'initwal_acc_bal';

//   echo '<br><br>';
  
   $planwaltqry="SELECT * FROM `mosave_account_type` WHERE `sn`=:acid  ";
   
  
        $unt_type = $planwaldb->prepare($planwaltqry);  
        
        
         $unt_type->bindParam(":acid", $accountId,PDO::PARAM_STR);
            

 $unt_type->execute();
	 $redssa = $unt_type->fetch();
	$minimum_bal=$redssa['minimum_bal']; 
	
// echo	$minimum_bal.'$minimum_bal';
	
// echo '<br><br>';
  if($vailBalance>$minimum_bal){
    //   echo 'got';
    //   echo '<br><br>';
      
      if($billing_type=='P'){
     
     if($vailBalance!=''){
 //do an insert into admin_ledger.admin_charge
$admin_charge= ($vailBalance * $percentage_commission)/100;
}else{
  $admin_charge=0;  
}


$charge_type='P';
}
if($billing_type=='F'){
 //do an insert into admin_ledger.admin_charge
$admin_charge=  $money_commission;
$charge_type='F';
}


// echo $admin_charge.'admi_char';
// echo '<br><br>';
  $transtype='commission';
$trans_mode='AC';

  $sqla = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
                    `accountType`, `trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:trans_mode,:datecreated,:time,:ip)";
     
$db = getConnection();
        $stmta = $db->prepare($sqla);  
        
        $stmta->bindParam(":customerId", $customerId,PDO::PARAM_STR);
         $stmta->bindParam(":agentId", $agentId,PDO::PARAM_STR);
          $stmta->bindParam(":actids", $accountId,PDO::PARAM_STR);
           $stmta->bindParam(":pid", $planId,PDO::PARAM_STR);
         $stmta->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
         $stmta->bindParam(":transAmount", $admin_charge,PDO::PARAM_STR);
          $stmta->bindParam(":transtype", $transtype,PDO::PARAM_STR);
           $stmta->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
           $stmta->bindParam(":transref", $refs,PDO::PARAM_STR);
        $stmta->bindParam(":accountType", $accountType,PDO::PARAM_STR);
        
         

      
       
       $stmta->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
       $stmta->bindParam(":time", $time,PDO::PARAM_STR);
       $stmta->bindParam(":ip", $ip,PDO::PARAM_STR);

                
                $resultas=$stmta->execute();
  
$sqlwa="INSERT INTO `mosave_admin_ledger`( `plan_id`, `cust_id`, `admin_charge`, `date`, `charge_type`) VALUES (:pId,:cId,:adcharge,:datecreated,:charge_type)";
     
$db = getConnection();
        $stmtsqlwa = $db->prepare($sqlwa);  
        
        $stmtsqlwa->bindParam(":cId", $customerId,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":pId", $planId,PDO::PARAM_STR);
          $stmtsqlwa->bindParam(":adcharge", $admin_charge,PDO::PARAM_STR);
           $stmtsqlwa->bindParam(":datecreated", $date_time,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":charge_type", $charge_type,PDO::PARAM_STR);
         
         

      
       
      
       
                
                $resultsqf=$stmtsqlwa->execute(); 
                

                            
                             $avail_bal=$vailBalance-$admin_charge;
                            // echo $avail_bal.'pla_rem_bal_after_chargededuct';
                            // echo '<br><br>';
                            
                             $updwalqry11="UPDATE `mosave_plan_wallet` SET  `available_bal`=:avbal  WHERE  plan_id=:pid and customerId=:cid  ";
        $waldbs11 = getConnection();
        $plnwalstmt1 = $waldbs11->prepare($updwalqry11);  
         $plnwalstmt1->bindParam(":pid", $planId,PDO::PARAM_STR);
        $plnwalstmt1->bindParam(":cid", $customerId,PDO::PARAM_STR);
$plnwalstmt1->bindParam(":avbal", $avail_bal,PDO::PARAM_STR);   

 $r=$plnwalstmt1->execute();
 
 
 echo '<br>';
 
  $avail_balss=$wal_acco_bl-$admin_charge;
 
//   echo $avail_balss.'wal_rem_bal_after_chargededuct';
//                             echo '<br><br>';
                            
                            
                            
                             $updwalqry11ss="UPDATE `mosave_wallet` SET  `account_bal`=:avbal  WHERE  customerId=:cid ";
       
        $plnwalstmt1ss = $waldbs11->prepare($updwalqry11ss);  
         $plnwalstmt1ss->bindParam(":cid", $customerId,PDO::PARAM_STR);
        
$plnwalstmt1ss->bindParam(":avbal", $avail_balss,PDO::PARAM_STR);   

 $plnwalstmt1ss->execute();
 
 
 
if($r){
                 echo  'success';
}else{
                                          echo  'no plans';
                                    }

                                   }
                                   
                $m++;        
                    }



















function getTransactionRef(){
     $characters = 3;
    $letters    = '23456789';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
     $ref=date("Ymdgis");
     $k=$ref.$str;
     return $k;
     
}
function getConnection()
{
    $dbhost = "localhost";
     $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    
    $dbname = "moloyalc_mosave_master";
    //  $dbhost="localhost";
    //  $dbuser="root";
    //  $dbpass="";
    //  $dbname="moloyalc_master";
    $dbh    = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}

?>
