  
<?php
//phpinfo();
//https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=BulkSMS.ng&to=2348090963549&body=Welcome&dnd=2

// echo $ref=date("Ymdgis");
$to='2349096456814';
$msg='let go';
$url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to='.$to.'&body='.$msg.'&dnd=2';
    
//     $curl = curl_init();
//     $url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to='.$to.'&body='.$msg.'&dnd=2';

// //$url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to=09096456814&body=testing messgae lummy&dnd=2';
// curl_setopt_array($curl, array(
//   CURLOPT_URL => $url,
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_FOLLOWLOCATION => true,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => 'POST',
 
// ));

// $response = curl_exec($curl);

// curl_close($curl);
// echo $response;

echo $c=urlencode('thank you lord');

// $curl = curl_init();

// curl_setopt_array($curl, array(
//   CURLOPT_URL => "https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to=09096456814&body=$c",
  
//   CURLOPT_TIMEOUT => 50,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "POST",
 
// ));

// //$response = curl_exec($curl);
// $err = curl_error($curl);

// curl_close($curl);

// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   echo $response;
// }



// $token=269952;
// $ref_no=13768;
// $amount=10;
// $phoneno='09096456814';
//  $billid=18;
// 	  $itemcode='E05';
	  
	  

 

 $phoneno='09096456814';
    $amount='20';
     $mobilen=substr($phoneno,0,4);
     
        $mobilenetwork = '9MOBILE';
    
        if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='GLO'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='(9MOBILE)'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='AIRTEL'){
	  $billid=20;
	  $itemcode='A05';
	  }
	 $response = array(); 
//      $curl = curl_init();
// $headers = [];

// curl_setopt_array($curl, array(
//   CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => "",
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 50,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "GET",
 
// ));

//  $response1 = curl_exec($curl);
//  $err1 = curl_error($curl);
//   $da=json_decode($response1,true);
//   $token=$da["sessionID"];
//   $ref_no=$da["ex_ref_no"];
//   echo '<br>';

//   curl_close($curl);
    
    
    $ref_no=16206;
    $token=103626;
    $url='http://91.109.117.92/party/?action=1&ex_ref_no='.$ref_no.'&sessionID='.$token.'&trans_amt='.$amount.'&vend_email=rdi@avante-cs.com&bill_id='.$billid.'&item_id='.$itemcode.'&phone_numb='.$phoneno.'';
$curls = curl_init();

curl_setopt_array($curls, array(
  CURLOPT_URL => $url,
   CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 50,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
));

$response12 = curl_exec($curls);
  $err = curl_error($curls);
  echo curl_errno($curls);
echo curl_error($curls);



curl_close($curls);
echo $response12;
$das=json_decode($response12,true);
//echo $err1 = curl_error($curls);
 echo $ref_no.'$ref_no'; echo '<br>';
echo $token.'$token';echo '<br>';
    $session=$das["session_id"];
     echo $url; echo '<br>';
   echo $coder=$das["ex_resp_code"];
echo $ex_resp_desc=$das["ex_resp_desc"];

 
  


?>