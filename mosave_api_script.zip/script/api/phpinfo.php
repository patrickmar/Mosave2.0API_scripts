 <?php 
 phpinfo();
 
 ?>