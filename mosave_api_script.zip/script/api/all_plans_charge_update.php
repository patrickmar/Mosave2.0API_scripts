   $dateCreated=date("Y-m-d");
  $ip='';  
 $time=date("H:i:s");
$date_time=$dateCreated.' '.$time;
$sqlsssa = "SELECT * FROM `savings_plan` WHERE sn=:pid";
       
        $stmtbsss = $dbs->prepare($sqlsssa);  
        $stmtbsss->bindParam("pid", $planId);
        
                $stmtbsss->execute();
                $resultsass = $stmtbsss->fetch();
   $plans_id = $resultsass['sn'];              
  $plan_name = $resultsass['plan_name'];
 $savings_amount = $resultsass['plan_amount'];
 $days = $resultsass['days'];
 $percentage_commission = $resultsass['percentage_commission'];
 $money_commission = $resultsass['flat_commision'];
$billing_type = $resultsass['billing_type'];
 
$refs= getTransactionRef();


 echo 'prod script<br>';

//       $d=strtotime("+1 Months");
// $chargedt= date("Y-m-d", $d) ;  
             $today=date("Y-m-d");    
             
              $sqlupd = "SELECT * FROM `mosave_customer_savings_plan` where plan_id=:pid and next_charge_date=:today"; 
              
              $planwaldb = getConnection();
        $plastmtss = $planwaldb->prepare($sqlupd);  
        
        
         $plastmtss->bindParam(":pid", $planId,PDO::PARAM_STR);
           $plastmtss->bindParam(":today", $today,PDO::PARAM_STR);  
		   $plastmtss->execute();
	while( $redtmt = $plastmtss->fetch()){
$planId=$redtmt['plan_id']; 
 $charge_flag=$redtmt['charge_flag']; 
  $savings_count=$redtmt['savings_count'];
 $customerId=$redtmt['cust_id']; 
$next_charge_date=$redtmt['next_charge_date']; 

		   
		   
		   if($savings_count!=0 && $charge_flag!=0){

 $k= $savings_count-($charge_flag*$days);
for ($j=0; $j<=$k; $j++){
 $tt= $j % $days;

if($tt==1){
    
    $wal_flag='check';
//increment charge_flag by 1
$charge_flag=$charge_flag+1;


$sqlupd = "UPDATE `mosave_customer_savings_plan` SET `charge_flag`=:cflag WHERE plan_id=:pid and cust_id=:cid";
$db = getConnection();
        $stmtupd = $db->prepare($sqlupd);  
        
        $stmtupd->bindParam(":cflag", $charge_flag,PDO::PARAM_STR);
        
          $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
        $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
$stmtupd->execute();


// do an insert into admin_ledger.admin_charge


 //do an insert into admin_ledger.admin_charge
 if($billing_type=='P'){
$admin_charge= ($savings_amount * $days * $percentage_commission)/100;
$charge_type='P';
}
 if($billing_type=='F'){
   $admin_charge= $money_commission; 
   $charge_type='F';
 }
 
 
$transtype='commission';
$trans_mode='AC';
// $smsmsg     = 'Dear MoLoyal Customer, you have been charged commission for the month.  \nAcct: '.$accountNo.'\nPlan: '.$plan_name.'\nCommission Amt: N'.$admin_charge.' CR'.'\nAvailable Bal: N'.$avail_bal.'\nDate '.$dateCreated.' '.$time.'';
                 
//                  //$whatsappchk=sendWhatsApp($phone,$smsmsg);
//               $smscheck=sendSMS($phone,$smsmsg);


$sqla = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
                    `accountType`, `accountCode`,`trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:accountCode,:trans_mode,:datecreated,:time,:ip)";
     
$db = getConnection();
        $stmta = $db->prepare($sqla);  
        
        $stmta->bindParam(":customerId", $customerId,PDO::PARAM_STR);
         $stmta->bindParam(":agentId", $agentId,PDO::PARAM_STR);
          $stmta->bindParam(":actids", $accountId,PDO::PARAM_STR);
           $stmta->bindParam(":pid", $planId,PDO::PARAM_STR);
         $stmta->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
         $stmta->bindParam(":transAmount", $admin_charge,PDO::PARAM_STR);
          $stmta->bindParam(":transtype", $transtype,PDO::PARAM_STR);
           $stmta->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
           $stmta->bindParam(":transref", $refs,PDO::PARAM_STR);
        $stmta->bindParam(":accountType", $accountType,PDO::PARAM_STR);
         $stmta->bindParam(":accountCode", $accountCode,PDO::PARAM_STR);
         

      
       
       $stmta->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
       $stmta->bindParam(":time", $time,PDO::PARAM_STR);
       $stmta->bindParam(":ip", $ip,PDO::PARAM_STR);

                //$stmt->execute();
                $resultas=$stmta->execute();


$sqlwa="INSERT INTO `mosave_admin_ledger`( `plan_id`, `cust_id`, `admin_charge`, `date`, `charge_type`) VALUES (:pId,:cId,:adcharge,:datecreated,:charge_type)";
     
$db = getConnection();
        $stmtsqlwa = $db->prepare($sqlwa);  
        
        $stmtsqlwa->bindParam(":cId", $customerId,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":pId", $planId,PDO::PARAM_STR);
          $stmtsqlwa->bindParam(":adcharge", $admin_charge,PDO::PARAM_STR);
           $stmtsqlwa->bindParam(":datecreated", $date_time,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":charge_type", $charge_type,PDO::PARAM_STR);
         
         

      
       
      
       
                //$stmt->execute();
                $resultsqf=$stmtsqlwa->execute();
				
				}
				
				}