<?php
date_default_timezone_set('Africa/Lagos');
//connect to db

 $dbs = getConnection();
    //$planId=4; 
    
    $dateCreated=date("Y-m-d");
  $ip='';  
 $time=date("H:i:s");
$date_time=$dateCreated.' '.$time;

 $today=date("Y-m-d");   
echo '<br>';

	
	
	
	
 echo 'test script<br>';

//       $d=strtotime("+1 Months");
// $chargedt= date("Y-m-d", $d) ;  
              
             
             //echo $today.'  $today<br>';
              $sqlupd = "SELECT * FROM `mosave_customer_savings_plan` where next_charge_date=:today"; 
              
              $planwaldb = getConnection();
        $plastmtss = $planwaldb->prepare($sqlupd);  
        
        
        
           $plastmtss->bindParam(":today", $today,PDO::PARAM_STR);  

 $plastmtss->execute();
echo $plastmtss->rowCount();
	while($redtmt = $plastmtss->fetch()){
$planId=$redtmt['plan_id']; 
 $charge_flag=$redtmt['charge_flag']; 
 $customerId=$redtmt['cust_id']; 
 
 //echo $customerId.'  $customerId<br>';
 
$next_charge_date=$redtmt['next_charge_date']; 

$last_charge_date=$redtmt['last_charge_date']; 

$last_charge_date = date('Y-m-d', strtotime( $last_charge_date . " +1 days"));

//echo $next_charge_date.'  $next_charge_date<br>';

//echo $last_charge_date.'  $last_charge_date<br>';

$sqsa = "SELECT * FROM `mosave_savingtransaction` WHERE customerId=:cid and transType='S' AND `transDate` BETWEEN '$last_charge_date' AND '$next_charge_date'";
       
        $sdss = $dbs->prepare($sqsa);  
        $sdss->bindParam("cid", $customerId);
        
                $sdss->execute();
                $resultbss = $sdss->fetch();
                
             if($sdss->rowCount() != 0){   
                 
                 //customer has transacted within the month, deduct commision
   $refs= getTransactionRef();             
                
                
$sqlsssa = "SELECT * FROM `savings_plan` WHERE sn=:pid";
       
        $stmtbsss = $dbs->prepare($sqlsssa);  
        $stmtbsss->bindParam("pid", $planId);
        
                $stmtbsss->execute();
                $resultsass = $stmtbsss->fetch();
   $plans_id = $resultsass['sn'];              
  $plan_name = $resultsass['plan_name'];
 $savings_amount = $resultsass['plan_amount'];
 $days = $resultsass['days'];
 $percentage_commission = $resultsass['percentage_commission'];
 $money_commission = $resultsass['flat_commision'];
$billing_type = $resultsass['billing_type'];









    
               
$m=1;

                      
               $plqry="SELECT `agentId`, `accountId`, `accountNo`, `customerId`, `plan_id`, `account_bal`, `available_bal`  FROM `mosave_plan_wallet` WHERE  plan_id=:pid  and customerId=:cid ";
   
   $planwaldb = getConnection();
        $plastmt = $planwaldb->prepare($plqry);  
        
        
         $plastmt->bindParam(":pid", $planId,PDO::PARAM_STR);
             $plastmt->bindParam(":cid", $customerId,PDO::PARAM_STR);

 $plastmt->execute();
	while( $redsplastmt = $plastmt->fetch()){
$accountId=$redsplastmt['accountId']; 
$accountNo=$redsplastmt['accountNo']; 
 $customerId=$redsplastmt['customerId']; 
$planId=$redsplastmt['plan_id']; 
$agentId=$redsplastmt['agentId']; 

// echo $customerId;
// echo '<br><br>';

$plan_ac_bal=$redsplastmt['account_bal']; 
  $vailBalance=$redsplastmt['available_bal']; 
  
   echo $vailBalance.'initplan_available_bal <br>';
// echo '<br><br>';
  
$walrys="SELECT `sn`, `agentId`, `accountId`, `accountNo`, `customerId`, `account_bal` FROM `mosave_wallet`  WHERE  customerId=:cid   ";
   
   $paldb = getConnection();
        $walmts = $paldb->prepare($walrys);  
        
        
         $walmts->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
            

 $walmts->execute();
	 $redsa_dd = $walmts->fetch();
	 

 
 $wal_acco_bl=$redsa_dd['account_bal'];
echo $wal_acco_bl.'initwal_acc_bal';

  echo '<br><br>';
  
   $planwaltqry="SELECT * FROM `mosave_account_type` WHERE `sn`=:acid  ";
   
  
        $unt_type = $planwaldb->prepare($planwaltqry);  
        
        
         $unt_type->bindParam(":acid", $accountId,PDO::PARAM_STR);
            

 $unt_type->execute();
	 $redssa = $unt_type->fetch();
	$minimum_bal=$redssa['minimum_bal']; 
	
echo	$minimum_bal.'$minimum_bal';
	
echo '<br><br>';
  if($vailBalance>$minimum_bal){
      echo 'got';
      echo '<br><br>';
      
      if($billing_type=='P'){
     
     if($vailBalance!=''){
 //do an insert into admin_ledger.admin_charge
$admin_charge= ($vailBalance * $percentage_commission)/100;
}else{
  $admin_charge=0;  
}


$charge_type='P';
}
if($billing_type=='F'){
 //do an insert into admin_ledger.admin_charge
$admin_charge=  $money_commission;
$charge_type='F';
}


// echo $admin_charge.'admi_char';
// echo '<br><br>';
  $transtype='commission';
$trans_mode='AC';


 
  $sqla = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
                    `accountType`, `trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:trans_mode,:datecreated,:time,:ip)";
     
$db = getConnection();
        $stmta = $db->prepare($sqla);  
        
        $stmta->bindParam(":customerId", $customerId,PDO::PARAM_STR);
         $stmta->bindParam(":agentId", $agentId,PDO::PARAM_STR);
          $stmta->bindParam(":actids", $accountId,PDO::PARAM_STR);
           $stmta->bindParam(":pid", $planId,PDO::PARAM_STR);
         $stmta->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
         $stmta->bindParam(":transAmount", $admin_charge,PDO::PARAM_STR);
          $stmta->bindParam(":transtype", $transtype,PDO::PARAM_STR);
           $stmta->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
           $stmta->bindParam(":transref", $refs,PDO::PARAM_STR);
        $stmta->bindParam(":accountType", $accountType,PDO::PARAM_STR);
        
         

      
       
       $stmta->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
       $stmta->bindParam(":time", $time,PDO::PARAM_STR);
       $stmta->bindParam(":ip", $ip,PDO::PARAM_STR);

                
                $resultas=$stmta->execute();
  
$sqlwa="INSERT INTO `mosave_admin_ledger`( `plan_id`, `cust_id`, `admin_charge`, `date`, `charge_type`) VALUES (:pId,:cId,:adcharge,:datecreated,:charge_type)";
     
$db = getConnection();
        $stmtsqlwa = $db->prepare($sqlwa);  
        
        $stmtsqlwa->bindParam(":cId", $customerId,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":pId", $planId,PDO::PARAM_STR);
          $stmtsqlwa->bindParam(":adcharge", $admin_charge,PDO::PARAM_STR);
           $stmtsqlwa->bindParam(":datecreated", $date_time,PDO::PARAM_STR);
         $stmtsqlwa->bindParam(":charge_type", $charge_type,PDO::PARAM_STR);
         
         
                $resultsqf=$stmtsqlwa->execute(); 
                
$wal_avail_bal=$wal_acco_bl-$admin_charge;
  $updwalqry="UPDATE `mosave_wallet` SET `account_bal`=:newBalance  WHERE accountNo=:actid and customerId=:custid ";
        $waldbs = getConnection();
        $walstmt = $waldbs->prepare($updwalqry);  
        
        $walstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmt->bindParam(":actid", $accountNo,PDO::PARAM_STR);
          $walstmt->bindParam(":newBalance", $wal_avail_bal,PDO::PARAM_STR);

 $walstmt->execute();
                            
                             $avail_bal=$vailBalance-$admin_charge;
                               $cur_bal=$plan_ac_bal-$admin_charge;
                            // echo $avail_bal.'pla_rem_bal_after_chargededuct';
                            // echo '<br><br>';
                            
                             $updwalqry11="UPDATE `mosave_plan_wallet` SET  `available_bal`=:avbal,`account_bal`=:cur_bal   WHERE  plan_id=:pid and customerId=:cid  ";
        $waldbs11 = getConnection();
        $plnwalstmt1 = $waldbs11->prepare($updwalqry11);  
         $plnwalstmt1->bindParam(":pid", $planId,PDO::PARAM_STR);
        $plnwalstmt1->bindParam(":cid", $customerId,PDO::PARAM_STR);
$plnwalstmt1->bindParam(":avbal", $avail_bal,PDO::PARAM_STR);   
$plnwalstmt1->bindParam(":cur_bal", $cur_bal,PDO::PARAM_STR);   

 $r=$plnwalstmt1->execute();
 
 $sqlsass1 = "SELECT `sn`, `userId`, `BVN_num`, `firstName`, `mname`, `lastName`, `email`, `mobilenetwork`, `lastResetDate`, `pic`, `locked` FROM `config_user` WHERE sn=:custid";
       
        $stmtb1ss = $dbs->prepare($sqlsass1);  
        $stmtb1ss->bindParam("custid", $customerId);
        
                $stmtb1ss->execute();
                $resultsa1 = $stmtb1ss->fetch();
                $phone= $resultsa1['userId'];
                $email= $resultsa1['email'];
                $fname=$resultsa1['firstName'];
                $name= $resultsa1['firstName'].' '.$resultsa1['lastName'];
 
 $smsmsg     = 'Dear '.$fname.', you have been charged commission for the month.  \nAcct: '.$accountNo.'\nCommission Amt: N'.$admin_charge.' CR'.'\nDate '.$dateCreated.' '.$time.'';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
 echo '<br>';
 
//   $avail_balss=$wal_acco_bl-$admin_charge;
 
// //   echo $avail_balss.'wal_rem_bal_after_chargededuct';
// //                             echo '<br><br>';
                            
                            
                            
//                              $updwalqry11ss="UPDATE `mosave_wallet` SET  `account_bal`=:avbal  WHERE  customerId=:cid ";
       
//         $plnwalstmt1ss = $waldbs11->prepare($updwalqry11ss);  
//          $plnwalstmt1ss->bindParam(":cid", $customerId,PDO::PARAM_STR);
        
// $plnwalstmt1ss->bindParam(":avbal", $avail_balss,PDO::PARAM_STR);   

 //$plnwalstmt1ss->execute();
 
  }
 
if($r){
          
          $lastchargedt= $today ;
          echo  'success';
}else{
           $lastchargedt= '' ;
           echo  'no plans';
                                    }

                                   
                                   
                $m++;        
                    }



      $d=strtotime("+1 Months");
$chargedt= date("Y-m-d", $d) ; 
$lastchargedt=$today;
$charge_flag=$charge_flag+1;


   $sqlupdas = "UPDATE `mosave_customer_savings_plan` SET `charge_flag`=:cflag, `next_charge_date`=:chargedt, `last_charge_date`=:lastchargedt WHERE plan_id=:pid and cust_id=:cid";
$db = getConnection();
        $stmtupdas = $db->prepare($sqlupdas);  
        
       
          $stmtupdas->bindParam(":pid", $planId,PDO::PARAM_STR);
        $stmtupdas->bindParam(":cid", $customerId,PDO::PARAM_STR);
         $stmtupdas->bindParam(":cflag", $charge_flag,PDO::PARAM_STR);
         $stmtupdas->bindParam(":chargedt", $chargedt,PDO::PARAM_STR);
         $stmtupdas->bindParam(":lastchargedt", $lastchargedt,PDO::PARAM_STR);
          
    



$stmtupdas->execute();


}

}





function sendSMS($phone,$msg)
{
   
   $msg=urlencode($msg);
   $url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to='.$phone.'&body='.$msg.'&dnd=2';
    
    $curl = curl_init();
//$url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to=09096456814&body=testing messgae lummy&dnd=2';
curl_setopt_array($curl, array(
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  
));

$response = curl_exec($curl);

curl_close($curl);
return $response;
}








function getTransactionRef(){
     $characters = 3;
    $letters    = '23456789';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
     $ref=date("Ymdgis");
     $k=$ref.$str;
     return $k;
     
}
function getConnection()
{
    $dbhost = "localhost";
    $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    
    $dbname = "moloyalc_mosave_master_test";
    //  $dbhost="localhost";
    //  $dbuser="root";
    //  $dbpass="";
    //  $dbname="moloyalc_master";
    $dbh    = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}

?>
