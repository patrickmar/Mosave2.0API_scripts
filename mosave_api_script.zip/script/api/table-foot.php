<?php 

$output3 .= ' </table>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" style="padding-top: 20px;">
                            <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                <tr>
                                    <td width="75%" align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 800; line-height: 24px; padding: 10px; border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                        TOTAL
                                    </td>
                                    <td width="25%" align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 800; line-height: 24px; padding: 10px; border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                        '.$currency.' '.$amount.'
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                </td>
            </tr>
             <tr>
                <td align="center" height="100%" valign="top" width="100%" style="padding: 0 35px 35px 35px; background-color: #ffffff;" bgcolor="#ffffff">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:660px;">
                    <tr>
                        <td align="center" valign="top" style="font-size:0;">

                            <div style="display:inline-block; max-width:50%; min-width:240px; vertical-align:top; width:100%;">

                                <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
                                    <tr>
                                        <td align="left" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px;">
                                            <p style="font-weight: 800;">Personal Information</p>
                                            <p> '.$firstname.' '.$lastname.' <br>'.$customerid.'<br>'.$email.'</p>

                                        </td>
                                    </tr>
                                </table>
                            </div>

                            <div style="display:inline-block; max-width:50%; min-width:240px; vertical-align:top; width:100%; color: #000;">
                                <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
                                    <tr>
                                        <td align="left" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px;">
                                            <p style="font-weight: 800;">Event Information</p>
                                            <p>'.$from_date.' <br> '.$venue.' <br> '.$from_time.'</p>
                                        </td>
                                    </tr>
                                </table>
                            </div>

                        </td>
                    </tr>
                </table>

                </td>
            </tr>
            <tr>
                <td align="center" style=" padding: 35px; background-color: #1b9ba3;" bgcolor="#1b9ba3">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                    <tr>
                        <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
                            <h2 style="font-size: 24px; font-weight: 800; line-height: 30px; color: #ffffff; margin: 0;">
                                <!--Get 15% off your next order.-->
                                Don\'t you have the Mobile App!
                            </h2>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 25px 0 15px 0;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="center" style="border-radius: 5px;" bgcolor="#66b3b7">
                                      <a href="https://moloyal.com/test/ticketing" target="_blank" style="font-size: 18px; font-family: Open Sans, Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; background-color: #66b3b7; padding: 15px 30px; border: 1px solid #66b3b7; display: block;">Download</a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                </td>
            </tr>
            <tr>
                <td align="center" style="padding: 35px; background-color: #ffffff;" bgcolor="#ffffff">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                    <tr>
                        <td align="center" >
                         <a href="https://www.facebook.com/moloyalapp/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/facebook.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://bit.ly/hellomoloyal">   <img src="https://moloyal.com/test/loyaluserscript/api/images/whatsapp.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://www.twitter.com/moloyalapp/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/twitter.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://www.instagram.com/moloyal_app/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/instagram.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                        </td>
                    </tr>
                   <!-- <tr>
                        <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; padding: 5px 0 10px 0;">
                            <p style="font-size: 14px; font-weight: 800; line-height: 18px; color: #333333;">
                                11 Kayode Otitoloju Street,<br>
                                Lekki Phase one, Lagos state. 
                            </p>
                        </td>
                    </tr>-->
                    <tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px;">
                            <p style="font-size: 14px; font-weight: 400; line-height: 20px; color: #777777;">
                                If you didn\'t receive the PDF attachment, please raise a support ticket <a href="https://moloyal.com" target="_blank" style="color: #777777;">here</a>.
                            </p>
                        </td>
                    </tr>
                </table>

                </td>
            </tr>
        </table>

        </td>
    </tr>
</table>
    
</body>
</html>

';