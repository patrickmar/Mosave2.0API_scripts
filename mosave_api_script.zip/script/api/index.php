<?php
ini_set('display_errors',1);
date_default_timezone_set('Africa/Lagos');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PasswordHash.php';
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();


$app = new \Slim\Slim();
$app->get('/hello', function()
{
    echo "Hello, World";
});

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    
    exit(0);
}


// Search Customer
$app->get('/customer/search/:query', function($query) use ($app){
    $response   = array();
//              $sql = "SELECT  `userId` as phone, C.`sn` as custid,`firstName`,`mname`,`lastName`,C.`BVN_num`,`gender`,`city`, W.account_num, W.account_typeId,  M.`plan_id` ,
// 		(SELECT A.account_name FROM mosave_account_type A WHERE A.sn = W.account_typeId) as account_type, (SELECT J.`account_bal` FROM `mosave_wallet` J WHERE J.accountNo = W.account_num) as account_bal   
// 		FROM config_user C  left join `mosave_customer_savings_plan` M ON C.sn= M.cust_id  join config_customer_account_info W  WHERE  (C.sn= W.customerId) and (C.BVN_num = '$query'  or W.account_num ='$query' or C.userId = '$query' or  C.firstName like '%$query%' or C.lastName like '%$query%' OR email LIKE '%$query%') ORDER BY firstName"; 
    
    
     $sql = "SELECT  `userId` as phone, C.`sn` as custid,`firstName`,`mname`,`lastName`,C.`BVN_num`,`gender`,`city`, W.account_num, W.account_typeId, 
		(SELECT A.account_name FROM mosave_account_type A WHERE A.sn = W.account_typeId) as account_type 
		FROM config_user C   join config_customer_account_info W  WHERE  (C.sn= W.customerId) and (C.BVN_num = '$query'  or W.account_num ='$query' or C.userId = '$query' or  C.firstName like '%$query%' or C.lastName like '%$query%' OR email LIKE '%$query%') ORDER BY firstName"; 
        
            
       // $ssql2="SELECT    M.`plan_id`  FROM config_user C join `mosave_customer_savings_plan` M WHERE (C.sn= M.cust_id)";
          try {
         $db = getConnection();
        
        
        
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $wines = $stmt->fetchAll(PDO::FETCH_OBJ);
        //$custid = $wines[0]->userId;
        //$gg=array_merge($wines, $plan);
        //array_push($wines,$plan );
         //=array_push($response,...$plan );
        $db = null;
                //echo  json_encode($wines) ;
        echo '{"customer": ' . json_encode($wines) . '}';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
    
    
});

// Search Customer
$app->get('/customer/test/:query', function($query) use ($app){
    
        try{
            echo '{"error":{"fff":'.'}}'; 
        
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
    
    
});

//Get Sum of Saving Transactions per Agent


  $app->get('/agent/sumsavingstrans/:agentid', function($agentid) use ($app){
     $response   = array();
    
    $today = date("Y-m-d");
    
  
  try {
      $db = getConnection();
       $sql2 = "SELECT * FROM `config_agent` WHERE agentId=:agentid";
      $stmt2 = $db->prepare($sql2);  
      $stmt2->bindParam("agentid", $agentid);
      $stmt2->execute();
      $res    = $stmt2->fetch();
$sn =$res['sn'];
       $sql = "SELECT IFNULL(sum(`transAmount`),0) as savings_sum FROM `mosave_savingtransaction` WHERE agentId=:id and `transType`='S' and `transDate`='$today' ";
 
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("id", $sn);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
        // $result=$today;
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});


//Get Sum of Saving Transactions per Agent


  $app->get('/agent/sumwithtrans/:agentid', function($agentid) use ($app){
     $response   = array();
    
    $today = date("Y-m-d");
    
    
    
  
  try {
      $db = getConnection();
      
      $sql2 = "SELECT * FROM `config_agent` WHERE agentId=:agentid";
      $stmt2 = $db->prepare($sql2);  
      $stmt2->bindParam("agentid", $agentid);
      $stmt2->execute();
      $res    = $stmt2->fetch();
$sn =$res['sn'];
      
        $sql = "SELECT IFNULL(SUM(`transAmount`),0) as withdrawals_sum FROM `mosave_savingtransaction` WHERE agentId=:id and `transType`='W' and `transDate`='$today' ";

      $stmt = $db->prepare($sql);  
      $stmt->bindParam("id", $sn);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
        // $result=$today;
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});


//GEt customer sum Savings and Withdrawal
 $app->get('/customer/sumtrans/:custid', function($custid) use ($app){
     $response   = array();
    
    $today = date("Y-m-d");
    
  
  try {
      $db = getConnection();
//       $sql2 = "SELECT * FROM `config_agent` WHERE agentId=:agentid";
//       $stmt2 = $db->prepare($sql2);  
//       $stmt2->bindParam("agentid", $agentid);
//       $stmt2->execute();
//       $res    = $stmt2->fetch();
// $sn =$res['sn'];
       $sql = "SELECT IFNULL(sum(`transAmount`),0) as savings_sum FROM `mosave_savingtransaction` WHERE customerId=:id and `transType`='S'  ";
 
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("id", $custid);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
       $sql2 = "SELECT IFNULL(sum(`transAmount`),0) as withdraw_sum FROM `mosave_savingtransaction` WHERE customerId=:id and `transType`='W'  ";
 
      $stmt2 = $db->prepare($sql2);  
      $stmt2->bindParam("id", $custid);
      $stmt2->execute();
       $result2     = $stmt2->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result || $result2) {
           array_push($response, $result);
          array_push($response, $result2);
        // $result=$today;
            
           echo json_encode($response); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

//Get 50 last Transactions per Agent


  $app->get('/agenttransactionhistory/:agentid', function($agentid) use ($app){
    
     $response   = array();
    
    
  $sql = "SELECT ST.`sn`,ST.`customerId`,ST.`planId`, ST.`agentId`, ST.`accountId`, ST.`accountNo`, ST.`transAmount`, ST.`transType`,ST.`transref`,
   ST.`accountType`, ST.`accountCode`, ST.`status`, ST.`createdDate`, ST.`transDate`, ST.`time`, ST.`ip`, (SELECT J.`plan_name` FROM `savings_plan` J WHERE J.sn =ST.`planId`) as plan_name, C.`userId`, C.`BVN_num`, 
   C.`firstName`, C.`mname`, C.`lastName`, C.`email`, C.`city`, C.`state`, C.`gender` 
  FROM `mosave_savingtransaction` ST JOIN `config_user` C ON ST.customerId=C.sn   
  WHERE ST.agentId=:agentid order by ST.`createdDate` Desc limit 50";
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("agentid", $agentid);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
         
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

//Get customer plans balance
 $app->get('/getcustomer_planbalance/:planid', function($planid) use ($app){
     $response   = array();
//     $planwalletqry="SELECT `account_bal` as planwBalance, `available_bal` as planavailBalance FROM `mosave_plan_wallet` WHERE  customerId=:custid ";
   
//   $planwaldb = getConnection();
//         $planwalstmt = $planwaldb->prepare($planwalletqry);  
        
//         $planwalstmt->bindParam(":custid", $customerid,PDO::PARAM_STR);
        

//  $planwalstmt->execute();
// 	 $reds = $planwalstmt->fetch();
	 

//  $planwBalance=$reds['planwBalance'];
 
//   if($planwalstmt->rowCount() == 0)
//                     {
                      
    
    $sql = "SELECT ST.`plan_name`, ST.`plan_amount`, ST.`sn`,  C.`cust_id`, C.`plan_id`
   
  FROM `savings_plan` ST JOIN `mosave_customer_savings_plan` C ON ST.sn=C.plan_id
  WHERE C.`cust_id`=:cid  ";
//                     }else{
  
//   $sql = "SELECT ST.`plan_name`, ST.`plan_amount`, ST.`sn`,  C.`cust_id`, C.`plan_id`, W.`available_bal`,  W.`account_bal` as ledger_bal
   
//   FROM `savings_plan` ST JOIN `mosave_customer_savings_plan` C ON ST.sn=C.plan_id   JOIN `mosave_plan_wallet` W  ON W.customerId=C.cust_id 
//   WHERE C.`cust_id`=:cid  ";
//                     }
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("cid", $customerid);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
         
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No plans existing for customer";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

//Get customer saving plan



  $app->get('/getcustomer_savingplans/:customerid', function($customerid) use ($app){
    $response   = array();
   // $res   = array();
//     $planwalletqry="SELECT `account_bal` as planwBalance, `available_bal` as planavailBalance FROM `mosave_plan_wallet` WHERE  customerId=:custid ";
   
//   $planwaldb = getConnection();
//         $planwalstmt = $planwaldb->prepare($planwalletqry);  
        
//         $planwalstmt->bindParam(":custid", $customerid,PDO::PARAM_STR);
        

//  $planwalstmt->execute();
// 	 $reds = $planwalstmt->fetch();
	 

//  $planwBalance=$reds['planwBalance'];
 
//   if($planwalstmt->rowCount() == 0)
//                     {
                      
    
    $sql = "SELECT ST.`plan_name`, ST.`plan_amount`, ST.`plan_duration`,ST.`days`, ST.`sn`,  C.`cust_id`, C.`plan_id`, C.`savings_count`, C.`charge_flag`
   
  FROM `savings_plan` ST JOIN `mosave_customer_savings_plan` C ON ST.sn=C.plan_id
  WHERE C.`cust_id`=:cid  ";
//                     }else{
  
//   $sql = "SELECT ST.`plan_name`, ST.`plan_amount`, ST.`sn`,  C.`cust_id`, C.`plan_id`, W.`available_bal`,  W.`account_bal` as ledger_bal
   
//   FROM `savings_plan` ST JOIN `mosave_customer_savings_plan` C ON ST.sn=C.plan_id   JOIN `mosave_plan_wallet` W  ON W.customerId=C.cust_id 
//   WHERE C.`cust_id`=:cid  ";
//                     }
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("cid", $customerid);
      $stmt->execute();
       //$result     = $stmt->fetch(PDO::FETCH_OBJ);
      while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            //$res['name'] = $result['name']; 
             $res['savings_count']=$result['savings_count'];
              $res['charge_flag']=$result['charge_flag'];
      $res['plan_name']=$result['plan_name'];
       $res['plan_amount']=$result['plan_amount'];
        $res['plan_duration']=$result['plan_duration'];
          $res['plan_no_of_days']=$result['days'];
         $res['cust_id']=$result['cust_id'];
         $res['plan_id']=$result['plan_id'];
         $cid=$res['cust_id'];
       $pid=$res['plan_id'];
      //echo json_encode($res); 
      
      $qlt="SELECT  `available_bal`,   `account_bal` as ledger_bal FROM   `mosave_plan_wallet` WHERE customerId=:cid and plan_id=:pid ";
         $stmtqlt = $db->prepare($qlt);  
      $stmtqlt->bindParam("cid",  $cid);
      $stmtqlt->bindParam("pid",  $pid);
      $stmtqlt->execute();
      
      
        $pasw    = $stmtqlt->fetch(PDO::FETCH_ASSOC);
       
      $res['available_bal'] = $pasw['available_bal'];
        $res['ledger_bal'] = $pasw['ledger_bal'];
         
        
        if($res['available_bal']=='' || $res['available_bal']==0){
          $res['available_bal']=0; 
        }
        if($res['ledger_bal']=='' || $res['ledger_bal']==0){
          $res['ledger_bal']=0; 
        }
        
        array_push($response, $res);
        
        //$res['plan_id']='';
      }
      if ($response) {
          
          
         
            
           echo json_encode($response); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No plans existing for customer";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});



//Get last 50 Customer Withdraw Transactions 

$app->get('/customerwithdrawhistory/:custid', function($custid) use ($app){

  $sql = "SELECT ST.`customerId`, ST.`agentId`, ST.`accountId`, ST.`accountNo`, ST.`transAmount`, ST.`transType`, ST.`accountType`, ST.`accountCode`, ST.`status`, ST.`createdDate`, 
  ST.`transDate`, ST.`time`, ST.`ip`,C.`sn`, C.`userId`, C.`BVN_num`, C.`firstName`, C.`mname`, C.`lastName`, C.`email`, C.`city`, C.`state`, C.`gender`
  FROM `mosave_savingtransaction` ST JOIN `config_user` C 
  ON ST.customerId=C.sn WHERE ST.transType='W' and ST.`customerId`=:custid order by ST.`createdDate` Desc  limit 50";
  
   
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("custid", $custid);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
         
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
            echo json_encode($response);
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});



//Get last 50 Customer Withdraw Transactions 

// $app->get('/customerwithdrawhistory/:custid', function($custid) use ($app){

//   $sql = "SELECT ST.`customerId`, ST.`agentId`, ST.`accountId`, ST.`accountNo`, ST.`transAmount`, ST.`transType`, ST.`accountType`, ST.`accountCode`, ST.`status`, ST.`createdDate`, 
//   ST.`transDate`, ST.`time`, ST.`ip`,C.`sn`, C.`userId`, C.`BVN_num`, C.`firstName`, C.`mname`, C.`lastName`, C.`email`, C.`city`, C.`state`, C.`gender`
//   FROM `mosave_savingtransaction` ST JOIN `config_user` C 
//   ON ST.customerId=C.sn WHERE ST.transType='W' and ST.`customerId`=:custid order by ST.`createdDate` Desc  limit 50";
  
   
//   try {
//       $db = getConnection();
//       $stmt = $db->prepare($sql);  
//       $stmt->bindParam("custid", $custid);
//       $stmt->execute();
//       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
//       if ($result) {
          
          
         
            
//           echo json_encode($result); 
          
           
//       } else {
//           $response['error']   = true;
//           $response['message'] = "No Transactions";
          
//       }
      
//       $db = null;
      
//   } catch(PDOException $e) {
//       echo '{"error":{"text":'. $e->getMessage() .'}}'; 
//   }
// });


//Get last 50 Customer Savings Transactions 

$app->get('/customersavingshistory/:custid', function($custid) use ($app){

  $sql = "SELECT ST.`customerId`, ST.`agentId`, ST.`accountId`, ST.`accountNo`, ST.`transAmount`, ST.`transType`, ST.`accountType`, ST.`accountCode`, ST.`status`, ST.`createdDate`, 
  ST.`transDate`, ST.`time`, ST.`ip`,C.`sn`, C.`userId`, C.`BVN_num`, C.`firstName`, C.`mname`, C.`lastName`, C.`email`, C.`city`, C.`state`, C.`gender`
  FROM `mosave_savingtransaction` ST JOIN `config_user` C 
  ON ST.customerId=C.sn WHERE ST.transType='S' and ST.`customerId`=:custid order by ST.`createdDate` Desc limit 50";
  
   
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("custid", $custid);
      $stmt->execute();
       $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
      
      if ($result) {
          
          
         
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
           echo json_encode($response);
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});


//Get all Customer Transactions limit 50 

$app->get('/customertransactions/:custid', function($custid) use ($app){
  
  //$id=1;
  
  $sql = " SELECT ST.`customerId`, ST.`agentId`, ST.`planId`, ST.`accountId`, ST.`accountNo`, ST.`transAmount`, ST.`transref`,ST.`transType`, ST.`accountType`, ST.`accountCode`, ST.`status`, ST.`createdDate`, (SELECT J.`plan_name` FROM `savings_plan` J WHERE J.sn =ST.`planId`) as plan_name,
  ST.`transDate`, ST.`time`, ST.`ip`,C.`sn`, C.`userId`, C.`BVN_num`, C.`firstName`, C.`mname`, C.`lastName`, C.`email`, C.`city`, C.`state`, C.`gender`
  FROM `mosave_savingtransaction` ST JOIN `config_user` C 
  ON ST.customerId=C.sn WHERE  ST.`customerId`=:custid order by ST.`createdDate` Desc limit 50";
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("custid", $custid);
      $stmt->execute();
       //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      $result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
     
      
      if ($result) {
          
          
         
            
           echo json_encode($result); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Transactions";
          echo json_encode($response);
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

//get agent pics
$app->get('/getagentpics/:agentid', function($agentid) use ($app){
    
    
    
    
  $sql = "SELECT   `img` FROM `config_agent` where agentId=:agentid";
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("agentid", $agentid);
      $stmt->execute();
       $result     = $stmt->fetch();
      
      $img=$result['img'];
      if ($img!='') {
          
          
          $response['error']   = false;
          $response['message'] = "Image Available";
            $response['image']=$img;
           echo json_encode($response); 
          
           
      } else {
          $response['error']   = true;
          $response['message'] = "No Image";
           echo json_encode($response); 
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});


//Get Total Wallet Balance

$app->get('/customertotalbalance/:custid', function($custid) use ($app){
  
  //$id=1;

 $sql="SELECT sum(`available_bal`) as wBalance FROM `mosave_plan_wallet` WHERE  customerId=:custid";
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("custid", $custid);
      $stmt->execute();
      $red = $stmt->fetch();
	 

 $wBalance=$red['wBalance'];
       //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
     
      
      if ($wBalance) {
          
          
         
            
           echo json_encode($wBalance); 
          
           
      } else {
        
          $message = "0";
          echo json_encode($message);
          
      }
      
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});


//Get Agent Sum Daily withdrawal Transaction





//Get Agent Daily trasaction



$app->get('/agentdailytrans/:agentid', function($agentid) use ($app){
$response   = array();
  //$id=1;
  
  //$agentid='09096456814';
  	$newunix=date("U");
		$transDate = date("Y-m-d",$newunix);
$db = getConnection();



//$sqlagent="SELECT  `savings`, `savings_limit`, `withdrawal`, `withdrawal_limit` FROM `config_agent_permissions` WHERE agent_id=:agt ";


 

  


// $sqlpayment="SELECT SUM(`amount`) as paidamount FROM  `agent_bankpay_evidence` WHERE agentid=:agt and date(`date`) = '$transDate'  ";

//  $sql_s="SELECT sum(transAmount) as sBalance
// FROM mosave_savingtransaction
// WHERE agentid=:agentid and transType='S' and date(`transDate`) = '$transDate'";
//   $sql_w="SELECT sum(transAmount) as wBalance
// FROM mosave_savingtransaction
// WHERE agentid=:agentid and transType='W' and date(`transDate`) = '$transDate'";
  

  
  try {
      $sql2="SELECT `sn`, `agentId`, `email`, `branchId` FROM `config_agent` WHERE agentId=:agentide";
      $db = getConnection();
      $stmt2 = $db->prepare($sql2);  
      $stmt2->bindParam("agentide", $agentid);
      $stmt2->execute();
      $red2 = $stmt2->fetch();
	 
	 

 $agentIds=$red2['sn'];
 
 
 
  
 if($agentIds==''){
  $response['error']   = true;
                $response['message'] = "agent id not available"; 
         
          echo json_encode($response); 
          return;  
 }else{
     $sqlagent="SELECT `config_name`, `value` FROM `config_agentpermission_settings` WHERE `agent_id`=:agt and `config_name`='Savings_limit'";

     $stmt2agent = $db->prepare($sqlagent);  
      $stmt2agent->bindParam("agt", $agentIds);
      $stmt2agent->execute();
      $red2agent = $stmt2agent->fetch();
	 
	 

 $balance_limit=$red2agent['value'];
 
 $sqlpayment="SELECT SUM(`amount`) as paidamount FROM  `agent_bankpay_evidence` WHERE agentid=:agt   ";

   $stmtpayment = $db->prepare($sqlpayment);  
      $stmtpayment->bindParam("agt", $agentIds);
      $stmtpayment->execute();
      $red2payment= $stmtpayment->fetch();
	 
	 

 $paidamount=$red2payment['paidamount'];
 if($paidamount==''){
     $paidamount=0;
 }
 
 
 $sql_s="SELECT sum(transAmount) as sBalance
FROM mosave_savingtransaction
WHERE agentid=:agentid and transType='S' ";
      $stmt = $db->prepare($sql_s);  
      $stmt->bindParam("agentid", $agentIds);
      $stmt->execute();
      $red = $stmt->fetch();
	 

 $sBalance=$red['sBalance'];
 if($sBalance==''){
     $sBalance=0;
 }
 
 
   $sql_w="SELECT sum(transAmount) as wBalance
FROM mosave_savingtransaction
WHERE agentid=:agentid and transType='W' ";
  $stmts = $db->prepare($sql_w);  
      $stmts->bindParam("agentid", $agentIds);
      $stmts->execute();
      $reds = $stmts->fetch();
	 

 $wBalance=$reds['wBalance'];
 if($wBalance==''){
     $wBalance=0;
 }
      //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
     $netBalance=$sBalance-$wBalance;
     if($netBalance==0){
       
        $netBalance=0;
     }else{
     $netBalance  =$netBalance-$paidamount;  
     }
     
     
        //   $response['paidamount']   =  $paidamount;
        //   $response['balance']   = $netBalance;
        //         $response['sBalance'] = $sBalance; 
        //   $response['wBalance']=$wBalance;
        //   $response['balance_limit']=$balance_limit;
        //   echo json_encode($response); 
        //   return;
          
          
          
          
          
         // if ($netBalance>=$balance_limit) {
          
      if ($netBalance) {
          
         $response['error']   =  false;
          $response['balance']   = $netBalance;
                $response['message'] = "There's a transaction"; 
           //$response['limitcheck']=true;
           $response['limitcheck']=false;
          echo json_encode($response); 
            
         // echo json_encode($wBalance); 
          
           
      }elseif ($netBalance==0) {
          
          
         $response['error']   = false;
          $response['balance']   = 0;
                $response['message'] = "There's no transaction"; 
         
          echo json_encode($response); 
            
         // echo json_encode($wBalance); 
          
           
      }elseif ($netBalance<0) {
          
          
         $response['error']   = true;
          $response['balance']   = $netBalance;
          $response['limitcheck']=true;
                $response['message'] = "There's no transaction"; 
         $response['agent_limit']=$balance_limit;
          echo json_encode($response); 
            
         // echo json_encode($wBalance); 
          
           
      } else {
          $response['error']   = false;
          $response['balance']   = $netBalance;
                $response['message'] = "There's a transaction"; 
        $response['limitcheck']=false;
         $response['agent_limit']=$balance_limit;
          echo json_encode($response); 
          
          
      }
 }
//  $response['agt']= $agentid;
//   $response['sbalance']   = $sBalance;
//           $response['balance']   = $netBalance;
//           $response['wbalance']   = $wBalance;
//                 $response['message'] = $balance_limit; 
         
//           echo json_encode($response); 
          
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

$app->post('/agent/updatepic2', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    //$agentid       = $request->agentid;
    //$pin      = $request->pic_path;
    
    
    if ( !empty( $_FILES ) ) {

$target_path = "img_uploads/";
 
$target_path = $target_path . basename( $_FILES['file']['name']);
 
if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
    header('Content-type: application/json');
    $data = ['success' => true, 'message' => 'Upload and move success'];
    echo json_encode( $data );
} else{
    header('Content-type: application/json');
    $data = ['success' => false, 'message' => 'There was an error uploading the file, please try again!'];
    echo json_encode( $data );
}
}



/*
   $agentId='08090963549';
   
    $pin =2345;
   */
    $updateUserquery = "UPDATE `config_agent` SET `img`= '$pin' WHERE `agentId` = '$agentid' ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    try {

		
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
        
        
      
        $result=$stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        }
         if ($pin=='' || $agentid=='') {
            $response['error']   = true;
            $response['message'] = 'Enter correct values';
            echo json_encode($response);
        }else if($result){
            $response['error'] = false;
             $response['message'] = 'Pic has been updated successfully';
              $response['source'] = 'Pic';
             $response['response'] = 'You have successfully updated image';
              echo json_encode($response);
        }
        
    
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});

$app->post('/agent/updatepics', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    $agentid = $_POST['agentid']; 
    //$pin      = $request->pic_path;
    
    
 


$sql="UPDATE `config_agent` SET `img`=:path WHERE agentId=:agentid";
    
    try {

		
           if ( !empty( $_FILES ) ) {

$target_path = "img_uploads/";
 
$target_path = $target_path . basename( $_FILES['file']['name']);
 
if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
      $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":agentid", $agentid);
                $stmt->bindParam(":path", $target_path);
    
    $result2=$stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        if($result2){
            
            $response['success']   = true;
        $response['message'] = 'Picture uploaded successfully';
         $response['path']= $target_path;
        echo json_encode($response);
    
} else{
    
     $response['success']   = false;
        $response['message'] = 'There was an error uploading the file, please try again!';
        
        echo json_encode($response);
   
}
}
}

        
    
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});

//Receive Bank payment Evidence

$app->post('/agent/bankpayevidence', function() use ($app)
{
    // $postdata   = file_get_contents("php://input");
    // $request    = json_decode($postdata);
    $response   = array();
   //$myCart=$request->params;
   //$agentid=$request->agentid;
//   $agentid = $_POST['agentid']; 
//   $pin = $_POST['pin']; 
//   $tellerno = $_POST['tellerno']; 
//   $amount = $_POST['amount']; 
   
    $agentid = $app->request()->params('agentid');
if($agentid==null || $agentid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$agentid    = $request->agentid;
	}
	
	$pin = $app->request()->params('pin');
if($pin==null || $pin==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$pin    = $request->pin;
	}
	
	
	$tellerno = $app->request()->params('tellerno');
if($tellerno==null || $tellerno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$tellerno    = $request->tellerno;
	}
	
	$amount = $app->request()->params('amount');
if($amount==null || $amount==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$amount    = $request->amount;
	}
 $date=date("Y-m-d");
    
 $time=date("H:i:s");

 $ip=$_SERVER['REMOTE_ADDR'];
 
	
// 	$agentid       = '09096456814';
//     $pin      = 1011;
// 	$tellerno      = 234525;
// 	$amount      =100000;
// 	$imgurl      = 'testing';
	
/*
CURRENT_DATE
   $agentId='08090963549';
   
    $pin =2345;
  */
   
 try {

		  $sql = "INSERT INTO agent_bankpay_evidence (agentid,tellerno,amount,imgurl,date,time,ip) VALUES(:agentid,:tno,:amt,:url,:date,:time,:ip) ";
   
      $updateUserquery = "SELECT * FROM `config_agent` WHERE `agentId` = '$agentid' ";
   	
 if($amount==''){
      $response['error']   = true;
            $response['message'] = 'amount cannot be empty';
             echo json_encode($response); 
             return;
    }
	else if($pin==''){
	    $response['error']   = true;
            $response['message'] = 'pin cannot be empty';
             echo json_encode($response); 
             return;
	}
		else if($agentid==''){
	    $response['error']   = true;
            $response['message'] = 'agentid cannot be empty';
             echo json_encode($response); 
             return;
	}
	 $db = getConnection();
        $stmtpin = $db->prepare($updateUserquery);
        
        
      
        $stmtpin->execute();
         $resultss = $stmtpin->fetch();
         $aid=$resultss['sn'];
         
               
          
         $enc_pin= $resultss['pin'];
              
             $getsettings="SELECT * FROM `config_agentpermission_settings` WHERE `agent_id`='$aid' AND `config_name`='Savings_limit'";
              
               $stmtval = $db->prepare($getsettings);
        
        
      
        $stmtval->execute();
         $resulta = $stmtval->fetch();
         $val=$resulta['value'];
         if($amount>$val){
      $response['error']   = true;
            $response['message'] = 'amount cannot be more than limit';
             echo json_encode($response); 
             return;
    }
         
         
    if($enc_pin==''){
        
         $response['success']   = false;
        $response['message'] = 'No pin value in database';
        echo json_encode($response);
        
    return;
    }        
    $auth = password_verify($pin, $enc_pin);
if($auth=='1'){
            
           if ( !empty( $_FILES ) ) {

$target_path = "teller_uploads/";
 
$target_path = $target_path . basename( $_FILES['file']['name']);
 
if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
    
     $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":agentid", $aid);
                $stmt->bindParam(":tno", $tellerno);
                $stmt->bindParam(":amt", $amount);
                $stmt->bindParam(":url", $target_path);
                $stmt->bindParam(":date", $date,PDO::PARAM_STR);
$stmt->bindParam(":time", $time,PDO::PARAM_STR);
$stmt->bindParam(":ip", $ip,PDO::PARAM_STR);

        
      
        $result2=$stmt->execute();
        
        
        $errorInfo = $stmt->errorInfo();
        if($result2){
       $response['success']   = true;
        $response['message'] = 'Payment / Picture uploaded successfully';
         $response['path']   = $target_path;
        $response['agtid'] = $agentid;
        echo json_encode($response);
        
    // header('Content-type: application/json');
    // $data = ['success' => true, 'message' => 'Payment / Picture uploaded successfully','path' => $target_path,'param' => $myCart,'agtid'=>$agentid];
    // echo json_encode( $data );
} else{
    
     $response['success']   = false;
        $response['message'] = 'There was an error uploading the information, please try again!';
        echo json_encode($response);
    // header('Content-type: application/json');
    // $data = ['success' => false, 'message' => 'There was an error uploading the file, please try again!'];
    // echo json_encode( $data );

}
}

           }else{
               $response['success']   = false;
        $response['message'] = 'there is no file passed for upload, please try again!';
        echo json_encode($response);
              
           }
              
          } else{
              
               $response['success']   = false;
        $response['message'] = 'pin is not valid, please try again!';
        echo json_encode($response);
              
              
          }
    
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
    
});



//Get agent pin
$app->post('/agent/recievepin', function() use ($app)
{
    // $postdata   = file_get_contents("php://input");
    // $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    // $agentid       = $request->agentid;
    // $pin      = $request->pin;
    $agentid = $app->request()->params('agentid');
if($agentid==null || $agentid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$agentid    = $request->agentid;
	}
	
	$pin = $app->request()->params('pin');
if($pin==null || $pin==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$pin    = $request->pin;
	}
	
	
    
    
/*
   $agentId='08090963549';
   
    $pin =2345;
   */
   try {
   if($pin=='' || $agentid==''){
       $response['error']   = true;
            $response['message'] = 'no value supplied for pin or agent id';
             echo json_encode($response); 
    }else{
   
    $pin    = password_hash($pin,PASSWORD_BCRYPT);
    $updateUserquery = "UPDATE `config_agent` SET `pin`= '$pin' WHERE `agentId` = '$agentid' ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    

		
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
        
        
      
        $result=$stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        }
         if($result){
            $response['error'] = false;
             $response['message'] = 'Pin has been updated successfully';
              $response['source'] = 'Pin';
              $response['pinbool']=true; 
             $response['response'] = 'You have successfully completed your account activation.';
              echo json_encode($response);
        }
        
    }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});

//verify Agent Pin

$app->post('/agent/verifypin', function() use ($app)
{
    // $postdata   = file_get_contents("php://input");
    // $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    // $agentid       = $request->agentid;
    // $pin      = $request->pin;
   /*
    $agentid='08090963549';
   
    $pin ='2345';
    
    */
    
    $agentid = $app->request()->params('agentid');
if($agentid==null || $agentid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$agentid    = $request->agentid;
	}
	
	$pin = $app->request()->params('pin');
if($pin==null || $pin==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$pin    = $request->pin;
	}
	
	
    
    $updateUserquery = "SELECT `pin` FROM `config_agent` WHERE `agentId` = '$agentid'  ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    try {

		
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
        
        
      
        $stmt->execute();
         $result = $stmt->fetch();
         
          
          
          //echo json_encode($response);
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            
        } else { 
            
    $enc_pin= $result['pin'];
    if($enc_pin==''){
       $response['error']   = true;
            $response['message'] = 'no pin value in database';
             echo json_encode($response); 
    }else{
    $auth = password_verify($pin, $enc_pin);
if($auth=='1'){
            
            
            
                 $response['verified']=1;
                  $response['message'] ='pin verified successfully';
            }else{
                $response['verified']=0;
                 $response['message'] ='pin verification failed';
            }
          echo json_encode($response);
        }
        
        }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});

//Agent Change pin


$app->post('/agent/changepin', function() use ($app)
{
    // $postdata = file_get_contents("php://input");
    // $request  = json_decode($postdata);
    $response = array();
    //$userid   = $request->userid;
    // $phoneno    = $request->agentid;
    //  $oldpassword = $request->oldpin;
    // $newpassword = $request->newpin;
    
    //  $phoneno    ='09096456814';
    //  $oldpassword = 'P@ss1234';
    // $newpassword = 'P@ss12345';
    
    $phoneno = $app->request()->params('agentid');
if($phoneno==null || $phoneno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$phoneno    = $request->agentid;
	}
	
	$oldpassword = $app->request()->params('oldpin');
if($oldpassword==null || $oldpassword==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$oldpassword    = $request->oldpin;
	}
	
	$newpassword = $app->request()->params('newpin');
if($newpassword==null || $newpassword==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$newpassword    = $request->newpin;
	}
	
	
    
   if (!isAgentPhoneExist($phoneno)) {
        $response['error']   = true;
        $response['message'] = "Agent Id does not exist in our records";
        echo json_encode($response);
        return;
    }
     try {
         
          
   
        
         
    
         $dbs=getConnection();
     $sqlsa1 = "SELECT `sn`, `pin`, `agentId`, `img`, `programId`, `merchantId`, `firstname`, `lastname`, `email`,`password` FROM config_agent WHERE agentId=:agentid";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam(":agentid", $phoneno);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                 $agentId= $resultsa1['agentId'];
                $email= $resultsa1['email'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                $enc_pin= $resultsa1['pin'];
     
     
     // $enc_pin= $result['pin'];
    if($enc_pin==''){
       $response['error']   = true;
            $response['message'] = 'no pin value in database';
             echo json_encode($response); 
             return;
    }else{
    $auth = password_verify($oldpassword, $enc_pin);
if($auth==1){
            
          
          
          
    
   
    

    
    $newpwd = password_hash($newpassword,PASSWORD_BCRYPT);
    $def       = '0';
   
    
                
  $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1       = 'Your pin have been changed successfully. <br> If you did not initiate this request, Please contact the admin';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                   
                
   
    $subject   = "MoLoyal Pin Changed";
    
    $sql2 = "Update config_agent SET `pin`=:newpwd WHERE `agentId`=:agentId";
   
        $type = "MoLoyal change pin";
        if (isAgentEmailExist($email)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } 
            $db2   = getConnection();
            $stmt2 = $db2->prepare($sql2);
            $stmt2->bindParam(":newpwd", $newpwd, PDO::PARAM_STR);
           
            $stmt2->bindParam(":agentId", $agentId, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
           $jj= $stmt2->execute();
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($jj) {
                $response['error']   = false;
                $response['message'] ="pin change successful";
               // $response['message2'] = $email;
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
      
      
    
          
            
     
   
    
}else{
    
     $response['error']   = true;
            $response['message'] = 'wrong old password supplied';
             echo json_encode($response); 
             return;
    
}
     }
}
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});


//Agent Reset Pin



$app->post('/agent/resetpin', function() use ($app)
{
    // $postdata = file_get_contents("php://input");
    // $request  = json_decode($postdata);
    $response = array();
    //$userid   = $request->userid;
    // $agentphone    = $request->agentphone;
    // $pin = $request->newpin;
    
    
     
    $agentphone = $app->request()->params('agentphone');
if($agentphone==null || $agentphone==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$agentphone    = $request->agentphone;
	}
	
	$pin = $app->request()->params('newpin');
if($pin==null || $pin==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$pin    = $request->newpin;
	}
	
	
    
    $dbs=getConnection();
    
    $newpwd = password_hash($pin,PASSWORD_BCRYPT);
    $def       = '0';
    
     $sqlsa1 = "SELECT `sn`, `pin`, `agentId`, `img`, `programId`, `merchantId`, `firstname`, `lastname`, `email` FROM config_agent WHERE agentId=:agentphone";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam(":agentphone", $agentphone);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                 $agentId= $resultsa1['agentId'];
                $email= $resultsa1['email'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                
 $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1       = 'You have requested for a pin reset on MoLoyal. <br> If you did not initiate this request, you can let us know here:
support@moloyal.com.
<br>';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                   
                
   
    $subject   = "MoLoyal Pin Reset";
    
    $sql2 = "Update config_agent SET `pin`=:newpwd WHERE `agentId`=:agentId";
    try {
        $type = "Moloyal reset password";
        if (isAgentEmailExist($email)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } 
            
            $stmt2 = $dbs->prepare($sql2);
            $stmt2->bindParam(":newpwd", $newpwd, PDO::PARAM_STR);
            
           
            
            $stmt2->bindParam(":agentId", $agentId, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
            $res=$stmt2->execute();
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($res) {
                $response['error']   = false;
                $response['message'] = "Your pin reset is successful";
                
                
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//Agent Forgot Pin



$app->post('/agent/forgotpin', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
   // $userid   = $request->userid; 	
//$userid='08051125927';
    //$agentid    = $request->agentphone;
    $agentid = $app->request()->params('agentphone');
     
    if($agentid==null || $agentid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$agentid    = $request->agentphone;
	if($agentid==null || $agentid==''){
		$response['error']   = true;
        $response['message'] = "agent phone is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
    // $response['error']   = $userid;
    //     $response['message'] = "User id does not exist in our records";
    //     echo json_encode($response);
        
        
        
     //$userid='09023674562';
     //$email='oluodebiyi@gmail.com';
    // if (!isEmailExist($email)) {
    //     $response['error']   = true;
    //     $response['message'] = "Email does not exist in our records";
    //     echo json_encode($response);
    //     return;
    // }
    if (!isAgentPhoneExist($agentid)) {
        $response['error']   = true;
        $response['message'] = "Agent id does not exist in our records";
        echo json_encode($response);
        return;
    }
    
    //$randompwd=random();
    $rando = random();
     
    
    
   
    try { 
         $db2   = getConnection();
   // $randompwd = md5($rando);
    //$randompwd    = password_hash($rando,PASSWORD_BCRYPT);
   // $userid="051125927";
    
  
   
     $sqlsa1 = "SELECT  `firstname`,  `lastname`, `email`,`agentId` FROM `config_agent` WHERE agentId='$agentid'";
       
        $stmtb1 = $db2->prepare($sqlsa1);  
       // $stmtb1->bindParam("custid", $userid);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $email= $resultsa1['email'];
                 $phone= $resultsa1['agentId'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                //$response['errors']   = $email;
                //$response['errors1']   = $userid;
 $from    = "noreply@moloyal.com";
                $to      = $email;
               $msg1      = 'We received a forgot pin request for your MoLoyal account.  Your new temporary token is ' . $rando . ' <br>kindly use reset to a new pin. <br>If you did not request a pin reset assistance, you can let us know here:
support@moloyal.com.
 ';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                   
                
    
    $subject   = "MoLoyal Forgot Pin";
   
        $type = "Moloyal forgot pin";
         $mi=sendEmail($from, $to, $msg, $subject, $type);
         $kk=$mi;
         
          $smsmsg     = 'Your forgot pin request is received. Your new temporary token is \n'.$rando.'\nPlease use to reset';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
        // $response['error']   = $mi;
                //$response['message'] = "A temporary password has been sent to your email";
       // if ($kk==1) {
        
           
            // $sql2 = "Update config_agent SET `password`=:rand, `default`=:def WHERE `email`=:userid ";
            // $stmt2 = $db2->prepare($sql2);
            
            // $stmt2->bindParam(":userid", $email, PDO::PARAM_STR);
            // // $stmt2->bindParam(":email", $email, PDO::PARAM_STR);
            // $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            // $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
           
            
            
            // $errorInfos = $stmt2->errorInfo();
            // if (isset($errorInfos[2])) {
            //     $response['error']   = true;
            //     $response['message'] = $errorInfos[2];
            //     echo json_encode($response);
            // }
           if ($kk==1) {
                $response['error']   = false;
                $response['message'] = "A temporary token has been sent to your email and phone number";
                 $response['code'] = $rando;
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error sending  the email";
                
                
                
            }
            //$response= $stmt2->fetch();
           
       
         echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//OTP Sender




$app->get('/otp/sender/:custid', function($custid) use ($app){
  
   
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    //$customerId       =$request->customerId;
   
   /*
    $agentid='08090963549';
   
    $pin ='2345';
    
    */
    //$custid=10;
    
    $otp=generateotp();
   // $otp=444;
    $updateUserquery = "UPDATE `config_user` SET `tp_checker`=$otp WHERE `sn` =:custid ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    try {

		
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
         $stmt->bindParam("custid", $custid);
        
      
        $stmt->execute();
         //$result = $stmt->fetch();
         
          
          
          //echo json_encode($response);
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            
        } else {
             $sqlsa1 = "SELECT `sn`, `userId`, `BVN_num`, `firstName`, `mname`, `lastName`, `email`, `mobilenetwork`, `lastResetDate`, `pic`, `locked` FROM `config_user` WHERE sn=:custid";
       
        $stmtb1 = $db->prepare($sqlsa1);  
        $stmtb1->bindParam("custid", $custid);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $email= $resultsa1['email'];
                 $phone= $resultsa1['userId'];
                $name= $resultsa1['firstName'].' '.$resultsa1['lastName'];
                 $smsmsg     = 'Find below MoSave One Time Token(OTT) for your withdrawal transaction.\nOTT: '.$otp.' \nThank you';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
               
                
              
  //$response['url']=$url;

 $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1     = 'Your MoSave One Time Token(OTT) for your withdrawal transaction is below.
                
               <br>
 

OTP	:	' . $otp . '<br>




<br>(Note: The OTP will expire after 3 hours.)';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                    $subject = "MoSave OTT [ ".$otp." ]";
                $type    = $name;
                
                //$emailsent=1;
                $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                if($emailsent){
                   $response['error']   = false;
            $response['message'] = 'sms or email sent';
             $response['otp']=$otp;
                }else{
                    
                     //$response['$emailsent']   = $emailsent;
                   $response['error']   = true;
            $response['message'] = 'sms or email not sent';
                }
                  echo json_encode($response);
        
        }
    
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});


//Update Customer
$app->post('/customer/update', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    $email       = $request->email;
    $userId      = $request->userId;
    $street1    = $request->street1;
    // $street2    = $request->street2;
    $mobilenetwork    = $request->mobilenetwork;
    $city    = $request->city;
    $state    = $request->state;
    $country    = $request->country;
    $dateOfBirth    = $request->dateOfBirth;
    $gender    = $request->gender;
    $pic    = $request->pic;
    $bvn    = $request->bvn;
    
    $updateUserquery = "UPDATE `config_user` SET `mobilenetwork`= '$mobilenetwork',`BVN_num`= '$bvn', `street1`= '$street1',`street2`= '$street2', `city`= '$city', `state`= '$state',
    `country`= '$country', `dateOfBirth`= '$dateOfBirth', `gender`= '$gender', `lastResetDate`= '$lastResetDate', `pic`= '$pic' WHERE `userId` = '$userId' AND `email` = '$email' ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    try {

		if (isEmailExist($email) && isPhoneExist($userId)) {
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
        
        
      
        $stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        } else {
            $response['error'] = false;
             $response['message'] = 'Profile has been updated successfully';
        }
        
    }else{
        $response['error']   = true;
        $response['message'] = "The user does not exist";
        echo json_encode($response);
        return;
        
		}
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});





$app->post('/users/register', function() use ($app)
{
    
    
    $response   = array();
    $expiryDate = date('Y-m-d', strtotime('+50 years'));
    // $firstname  = $request->firstname;
    // $phoneno    = $request->phoneno;
    //$mobilenetwork    = $request->mobilenetwork;
    // $lastname    = $request->lastname;
    // $email       = $request->email;
    
    
     $firstname = $app->request()->params('firstname');
	 
     
    if($firstname==null || $firstname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$firstname    = $request->firstname;

	}
	
	 $bvn = $app->request()->params('bvn');
	 
     
//     if($bvn==null || $bvn==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$bvn    = $request->bvn;

// 	}
	
			
	
	 $agentsn = $app->request()->params('sn');
	 
     
    if($agentsn==null || $agentsn==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$agentsn    = $request->sn;
	}
	 $agentId = $app->request()->params('agentId');
	 
     
    if($agentId==null || $agentId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$agentId    = $request->agentId;
	}
	
	 $referralId = $app->request()->params('referralId');
	 
     
//     if($referralId==null || $referralId==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$referralId    = $request->referralId;
// 	}
	
	
	$parentphone=$referralId;
	 $phoneno = $app->request()->params('phoneno');
	   $lastname = $app->request()->params('lastname');
	    $email = $app->request()->params('email');
	    //$pass1 = $app->request()->params('password');
	if($phoneno==null || $phoneno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$phoneno    = $request->phoneno;
	if($phoneno==null || $phoneno==''){
		$response['error']   = true;
        $response['message'] = "phone number is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($lastname==null || $lastname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$lastname    = $request->lastname;
	if($lastname==null || $lastname==''){
		$response['error']   = true;
        $response['message'] = "lastname is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	 $gender = $app->request()->params('gender');
		if($gender==null || $gender==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$gender    = $request->gender;
	
	}
	 $rando = random();
	 $pass1='Mo'. $rando.'*';
    // //$merchantId  = $request->merchantId;
    //  //$referno  = $request->referno;
       $password    = password_hash($pass1,PASSWORD_BCRYPT);

    //  $phoneno='0'.$phoneno;
     //      $firstname  = 'lums';
//     $phoneno    = '08090963549';
//     $mobilenetwork    = 'mtn';
//     $lastname    = 'dde';
//   $email       = 'oodexxbdsiyi@avante-cs.com';
//     $email       = 'oluodebiyi@gmail.com';
//     $merchantId  = 201501;
//      $referno  = '0906355466';
     
   $mobilenetwork=getMobileNetwork($phoneno);
    $merchantId = 2015;
    $accountype=1;


	$dateCreated=date("Y-m-d H:i:s");
    
  $co="SELECT bank_code FROM bank_settings";
  $dbs = getConnection();
              $cons = $dbs->prepare($co);
   $cons->execute();
  
   $resulta = $cons->fetch();
          
          
          if ($resulta){
               $bkcode=$resulta['bank_code'];
          } 
   
  
  $format = "%1$07d";
  $i=1;
   $go=sprintf($format,$i);
  
  $bank_act=$bkcode.$go;
  
  //$checkacc_no="SELECT * FROM customer WHERE account_num='$bank_act'";
  $stmta = $dbs->prepare("SELECT * FROM config_customer_account_info order by sn desc ");
  // $stmta->bindParam(":bank_act", $bank_act,PDO::PARAM_STR);
  
  
   $stmta->execute();
   $results = $stmta->fetch();
   
   $acc=$results['account_num'];
   
   if($results){
  
      $account_num=$acc+1;
  }else{
  $account_num=$bank_act;
  
  }
  
   $date=date("Y-m-d");
    
 $time=date("H:i:s");

 $ip=$_SERVER['REMOTE_ADDR'];
    
   
    
    
    
    
    
    
//$getif=mysqli_fetch_array($checkes);
//$pserial=$getif[serialNo];
    
    
    try {
        //auto assign SerialNo
		if (isEmailExist($email)) {
        $response['error']   = true;
        $response['message'] = "This email already exist";
        echo json_encode($response);
        return;
    }elseif (isPhoneExist($phoneno)) {
        $response['error']   = true;
        $response['message'] = "This phone number already exist";
        echo json_encode($response);
        return;
    }elseif ($bvn!='' && isBvnExist($bvn) ) {
        $response['error']   = true;
        $response['message'] = "This bvn number already exist for another customer";
        echo json_encode($response);
        return;
    }else{
        
        
      //auto assign SerialNo
    $qrydbname = "SELECT * FROM `config_program` where programId=:merchantId limit 1";
    
        $db = getConnection();
        $stmtdbname = $db->prepare($qrydbname);
        $stmtdbname->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
        $stmtdbname->execute();
        $res    = $stmtdbname->fetch();
        $dbname = $res['programDb'];
        
        //auto assign SerialNo
    $qrySerialNo = "SELECT * FROM `code_carddetails` where status='I' and printed=0 and merchantId=:merchantId limit 1";
    
        $stmtSerialNo = $db->prepare($qrySerialNo);
        $stmtSerialNo->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
        $stmtSerialNo->execute();
        $res      = $stmtSerialNo->fetch();
        $cserialno = $res['serialNo'];
        
        if ($cserialno != "") {
            
           if (!empty( $_FILES ) ) {

$target_path = "customer_pics/";
 
$target_path = $target_path . basename( $_FILES['photo']['name']);
 
if(move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
    
    

                
           
    $sql = "INSERT INTO config_user(`firstname`,`lastname`,`email`,`img`,`password`,`BVN_num`,
    `mobilenetwork`,`userId`,`agentId`,`dateCreated`,`locked`,`date`,`time`,`ip`)
    VALUES (:firstname,:lastname,:email,:img,:password,:bvn,:mobilenetwork,:phoneno,:agentid,:datecreated,'0',:date,:time,:ip)";
       
                $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
                $stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
                $stmt->bindParam(":email", $email, PDO::PARAM_STR);
                $stmt->bindParam(":mobilenetwork", $mobilenetwork, PDO::PARAM_STR);
                 $stmt->bindParam(":bvn", $bvn, PDO::PARAM_STR);
                $stmt->bindParam(":password", $password);
                $stmt->bindParam(":img", $target_path);
                 $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":agentid", $agentsn, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
                
$stmt->bindParam(":date", $date,PDO::PARAM_STR);
$stmt->bindParam(":time", $time,PDO::PARAM_STR);
$stmt->bindParam(":ip", $ip,PDO::PARAM_STR);


                $stmt->execute();
                
                
                $custid= $db->lastInsertId();
                
                $sql3 = "INSERT INTO `config_customer_account_info`(`customerId`, `account_typeId`,  `account_num`) 
        VALUES (:custid,:accountype,:account_num)";
 
         $db2 = getConnection();
         $stmt3 = $db2->prepare($sql3);  
         
         $stmt3->bindParam(":custid", $custid,PDO::PARAM_STR);
          $stmt3->bindParam(":accountype", $accountype,PDO::PARAM_STR);
         
         
         $stmt3->bindParam(":account_num", $account_num,PDO::PARAM_STR);
                 $result3=$stmt3->execute(); 


//$planid=4;
//   $sqlplan = "INSERT INTO `mosave_customer_savings_plan`( `cust_id`, `plan_id`, `user_starting_date`, `system_starting_date`, `savings_amount`)
//     VALUES (:cid,:pid,:user_starting_date,:system_starting_date,0)";
       
//                 $db   = getConnection();
//                 $stmtplan = $db->prepare($sqlplan);
//                 $stmtplan->bindParam(":pid", $planid, PDO::PARAM_STR);
//                 $stmtplan->bindParam(":cid", $custid, PDO::PARAM_STR);
               
                
                  
              
//                 $stmtplan->bindParam(":user_starting_date", $dateCreated, PDO::PARAM_STR);
//                 $stmtplan->bindParam(":system_starting_date", $dateCreated, PDO::PARAM_STR);
                



//                 $res=$stmtplan->execute();
        //         	$addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`,`tierLevel`, `comment`)
				// 					VALUES ('001','2015','201506','$cserialno','0','0','0','1','autopost from mobile signup')";
							
        //          $ds1sas   =  getDynamicConnection($dbname);
        // $sff1sas = $ds1sas->prepare($addpoint_qry);
        // $sff1sas->execute();
                
           

            //post info in conig_user_merchant_info
    $qrypostinfo = "INSERT INTO `config_user_merchant_info`(`userId`,`merchantId`, `serialNo`,`tierLevel`,`registered_from`)
    VALUES(:phone,:merchantId,:serialno,'1',:channel)";
            $stmtpostinfo = $db->prepare($qrypostinfo);
            $stmtpostinfo->bindParam(":phone", $phoneno, PDO::PARAM_STR);
            $stmtpostinfo->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
            $stmtpostinfo->bindParam(":serialno", $cserialno, PDO::PARAM_STR);
            $stmtpostinfo->bindParam(":channel", $channel, PDO::PARAM_STR);
           $stmtpostinfo->execute();
            
            if ($stmt->rowCount()) {
               
                $qryupdatecard  = "UPDATE `code_carddetails` SET dateActivated=:dateCreated, status='A' WHERE `serialNo`=:serialno";
                $stmtupdatecard = $db->prepare($qryupdatecard);
                $stmtupdatecard->bindParam(":dateCreated", $dateCreated, PDO::PARAM_STR);
                
                $stmtupdatecard->bindParam(":serialno", $cserialno, PDO::PARAM_STR);
                $stmtupdatecard->execute();
                
                // $db2    = getDynamicConnection($dbname);
                // $qry10  = "INSERT INTO `subscription`(`userId`, `merchantId`, `serialNo`, `dateCreated`, `lastSubscriptionDate`, `expiryDate`, `status`) VALUES ('$phoneno','$merchantId','$cserialno','$dateCreated','$dateCreated','$expiryDate','A')";
                // $qry10s = $db2->prepare($qry10);
                
                // $qry10s->execute();
                 $smsmsg     = 'Hi  '. $firstname . ', Welcome to MoSave. You have been registered successfully \nYour Acct No: '.$account_num.'';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phoneno,$smsmsg);
               
               
                $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1     = 'Your MoLoyal Registration is now complete. <br>

You have been assigned serial number <strong>' . $cserialno . '</strong> and your MoSave account number is <strong>' . $account_num . '</strong> . <br>This will be used for all future transactions.<br>
<br><br>
Yours sincerely,
<br>
MoLoyal Team
';
    
                $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Hi ' . $firstname . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                $subject = "MoLoyal Registration";
                $type    = $firstname;
                //$gender='';
                
                $sqlsa = "SELECT  `account_code`, `account_name`, `minimum_bal`, `desc` FROM `mosave_account_type` WHERE sn=:actid";
       
        $stmtb =$dbs->prepare($sqlsa);  
        $stmtb->bindParam("actid", $accountype);
        
                $stmtb->execute();
                $resultsa = $stmtb->fetch();
               
                        
$accountCode = $resultsa['account_code'];
$account_name = $resultsa['account_name'];
        
                     $sqlsa2 = "SELECT  `value`  FROM `config_agentpermission_settings` WHERE agent_id=:aid and  config_name='Referral'";
       
        $stmtb2 =$dbs->prepare($sqlsa2);  
        $stmtb2->bindParam("aid", $agentsn);
        
                $stmtb2->execute();
                $resultsa2 = $stmtb2->fetch();
               
                        
$refersetting = $resultsa2['value'];

          if($parentphone!=''){
               if($refersetting==1){
              $chekpar = "SELECT * FROM `config_user` where userId=:ch";
     
    
	$qrySerialNoa = $dbs->prepare($chekpar);
               
                $qrySerialNoa->bindParam(":ch", $parentphone, PDO::PARAM_STR);
                 $qrySerialNoa->execute();
    $resultsas = $qrySerialNoa->fetch();
    $parent_id = $resultsas['sn'];
    
    if($parent_id==''){
        
       
      $response['error']   = true;
                $response['message'] = "The Referrer is not registered on the platform";
  echo json_encode($response);
        return;
    }else{
        //checj child emailif available
    $chek = "SELECT * FROM `multilevel` where child_email=:childemail";
     
    
	$qrySerialNo = $dbs->prepare($chek);
               
                $qrySerialNo->bindParam(":childemail", $email, PDO::PARAM_STR);
                 $qrySerialNo->execute();
    $results = $qrySerialNo->fetch();
    $child_email = $results['child_email'];
    
    
                $chek2 = "SELECT * FROM `multilevel` where child_phone=:childphone";
                $qrySerphone = $dbs->prepare($chek2);
                
                $qrySerphone->bindParam(":childphone", $phoneno, PDO::PARAM_STR);
                
   
     $qrySerphone->execute();
    $rest = $qrySerphone->fetch();
     $child_phone = $rest['child_phone'];
         
    if ($child_email!='') {
     $response['error']   = true;
              $response['message'] = 'Email has been referred before';
              echo json_encode($response);
              
        return;
    }elseif ($child_phone!='') {
     $response['error']   = true;
              $response['message'] = 'Phone number has been referred before';
              echo json_encode($response);
        return;
    }else{
              $db   = getConnection();
			    $sql = "INSERT INTO  `multilevel`( `parent_id`,`child_id`, `child_phone`, `child_email`, `submerchantId`, `activated`,`datecreated`)
 VALUES (:parid,:childid,:childphone,:childemail,:merchantId,0,:datecreated)";
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":parid", $parent_id, PDO::PARAM_STR);
                $stmt->bindParam(":childid", $custid, PDO::PARAM_STR);
                $stmt->bindParam(":childemail", $email, PDO::PARAM_STR);
                 $stmt->bindParam(":childphone", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
               
                               
                $stmt->execute();
				
				}
    }
               }else{
      $response['error']   = true;
                $response['message'] = "Agent has been diasbled from referral";
                echo json_encode($response);
        return;
 }
              
          } 
          
         
                
                $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                $response['error2']   =  $emailsent;
                $response['error']   =  false;
                $response['message'] = "You have registered a new user";
                $response['error']   = false;
                $response['serialno'] = $cserialno;
                $response['account_num'] = $account_num;
                  $response['firstname'] = $firstname;
                $response['lastname'] = $lastname;
                $response['gender'] = $gender;
                $response['phone'] = $phoneno;
                $response['custid'] = $custid;
                  $response['account_typeId'] = $accountype;
                $response['account_type'] = $account_name;
                $response['account_bal'] = 0;
                $response['BVN_num'] = '';
                
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
            }
			
            echo json_encode($response);
            
} else{
    
    $response['success']   = false;
        $response['message'] = 'file available but upload failed, please try again!';
        echo json_encode($response);
}
           }else{
               $response['success']   = false;
        $response['message'] = 'there is no file passed for upload, please try again!';
        echo json_encode($response);
              
           }
        }
		
        
        
        
        
        
        
        
        
        
    }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});





//register agent


$app->post('/agent/register', function() use ($app)
{
   
    $response   = array();
    $expiryDate = date('Y-m-d', strtotime('+20 years'));
    // $firstname  = $request->firstname;
    // $phoneno    = $request->agentphone;
    // $mobilenetwork    = $request->mobilenetwork;
    // $lastname    = $request->lastname;
    // $email       = $request->email;
    // $password= $request->password;
    
    
    
     $firstname = $app->request()->params('firstname');
	  
     
    if($firstname==null || $firstname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$firstname    = $request->firstname;
	
	}
	

	   $lastname = $app->request()->params('lastname');
	    $email = $app->request()->params('email');
	    $phoneno = $app->request()->params('agentphone');
	    //$mobilenetwork = $app->request()->params('mobilenetwork');
	    $pass1 = $app->request()->params('password');
	if($phoneno==null || $phoneno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$phoneno    = $request->agentphone;
	if($phoneno==null || $phoneno==''){
		$response['error']   = true;
        $response['message'] = "phone number is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($lastname==null || $lastname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$lastname    = $request->lastname;
	if($lastname==null || $lastname==''){
		$response['error']   = true;
        $response['message'] = "lastname is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	

// 	if($mobilenetwork==null || $mobilenetwork==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$mobilenetwork    = $request->mobilenetwork;
// 	if($mobilenetwork==null || $mobilenetwork==''){
// 		$response['error']   = true;
//         $response['message'] = "mobile network is required";
		
//         echo json_encode($response);
		
// 		return;
// 	}
// 	}
	
	if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	 $pass1 = $app->request()->params('password');
		if($pass1==null || $pass1==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$pass1    = $request->password;
	
	}
    
    //$merchantId  = $request->merchantId;
    // $referno  = $request->referno;
     $mobilenetwork=getMobileNetwork($phoneno);
    $password    = password_hash($pass1,PASSWORD_BCRYPT);
    $merchantId = 2015;
    $accountype=1;
//$phoneno='0'.$phoneno;

	$dateCreated=date("Y-m-d H:i:s");
 
  $date=date("Y-m-d");
    
 $time=date("H:i:s");

 $ip=$_SERVER['REMOTE_ADDR'];
  
  
  
    
   
    // $email ='oluodebiyi@gmail.com'; 
    // $phoneno='09077364646';
    
    
    
    
//$getif=mysqli_fetch_array($checkes);
//$pserial=$getif[serialNo];
    
    
    try {
        //auto assign SerialNo
	if (isAgentPhoneExist($phoneno)) {
        $response['error']   = true;
        $response['message'] = "This phone number already exist";
        echo json_encode($response);
        return;
    }else{
      //auto assign SerialNo
    
    
            
            
                
    $sql = "INSERT INTO `config_agent`(`agentId`, `firstname`, `lastname`, `email`,  
    `dateCreated`, `password`,  `locked`,`date`,`time`,`ip`)
    VALUES (:phoneno,:firstname,:lastname,:email,:datecreated,:password,'1',:date,:time,:ip)";
       
                $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
                $stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
                $stmt->bindParam(":email", $email, PDO::PARAM_STR);
               
                $stmt->bindParam(":password", $password);
                
                $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
                  $stmt->bindParam(":date", $date,PDO::PARAM_STR);
       $stmt->bindParam(":time", $time,PDO::PARAM_STR);
       $stmt->bindParam(":ip", $ip,PDO::PARAM_STR);
                
                $stmt->execute();
                $agtid= $db->lastInsertId();
                
                $sql2 = "SELECT * FROM `configagent_initial_permissions`";
            $stmt2 = $db->prepare($sql2);
                $stmt2->bindParam(":agtid", $agtid, PDO::PARAM_STR);
               
                
                $stmt2->execute();
           while ($result = $stmt2->fetch(PDO::FETCH_ASSOC)) {  
$name = $result['config_name'];
$val = $result['value'];
$sql2s = "INSERT INTO `config_agentpermission_settings`( `agent_id`, `config_name`, `value`)  VALUES ( :agtid, '$name', '$val')";
            $stmt2s = $db->prepare($sql2s);
                $stmt2s->bindParam(":agtid", $agtid, PDO::PARAM_STR);
               
                
                $stmt2s->execute();
           }
                
                $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1     = 'You are now a MoLoyal Agent. <br>Please log into your app to begin transacting.<br>
Yours sincerely,
<br>
MoLoyal Team';

                $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Hi, ' . $firstname . '</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                $subject = "MoLoyal Agent Registration";
                $type    = $firstname;
                
                $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                $response['error']   =  false;
                $response['message'] = "Welcome to Moloyal.";
                $response['error']   = false;
                
                
            
            echo json_encode($response);
        }
		
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});





$app->post('/post/test', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);

	
 $response = array();
  $customerid = $app->request()->params('customerid');
 if($customerid==null || $customerid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$customerid    = $request->customerid;
	if($customerid==null || $phoneno==''){
		$response['error']   = true;
        $response['message'] = "customer id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
   $response['error']   = false;
        //$response['message'] = 'plan registered successfully';
         $response['message']=$customerid;
        echo json_encode($response);   
    
}); 

//Agent Dashboard Module
$app->get('/agent_dashboardmodule/:agentid', function($agentid) use ($app){
// $agentid=72;   
    
   $response = array(); 
   
//   modules = [
//     {
//       iconName: 'card-outline',
//       name: 'Savings',
//       route: '/app/savings',
//       disable: false
//     },
//     {
//       iconName: 'wallet-outline',
//       name: 'Withdrawal',
//       route: '/withdrawal/options',
//       disable: false
//     },
//     {
//       iconName: 'stats-chart-outline',
//       name: 'Airtime/data',
//       route: '/data-airtime',
//       disable: false
//     },
//     {
//       iconName: 'newspaper-outline',
//       name: 'Ticket',
//       route: '/app/categories/tickets',
//       disable: true,
//     }
// ]
 //(SELECT A.savings FROM config_agent_permissions A WHERE A.agent_id =:agentid ) as Savings, (SELECT B.withdrawal FROM config_agent_permissions B WHERE B.agent_id :agentid) as Withdraw   
  $sql = "SELECT `iconName`,`name`,`route`  FROM config_agentapp_dashboard_icons ";
  
  try {
      $db = getConnection();
      $stmt = $db->prepare($sql);  
      $stmt->bindParam("agentid", $agentid);
      $stmt->execute();
 while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $res['name'] = $result['name'];
            $res['iconName'] = $result['iconName'];
            $res['route'] = $result['route'];
          $kk=$res['name'];
            
            $sql2= "SELECT value  FROM config_agentpermission_settings  WHERE agent_id ='$agentid' and config_name='$kk'";
             $stmt2 = $db->prepare($sql2); 
            $stmt2->execute();
            $red = $stmt2->fetch();
			
	 

 $val=$red['value'];
 
//  if($kk=='Savings'){
 
// $agentIds= $agentid;
 
//  $sqlagent="SELECT `config_name`, `value` FROM `config_agentpermission_settings` WHERE `agent_id`=:agt and `config_name`='Savings_limit'";


//   $stmt2agent = $db->prepare($sqlagent);  
//       $stmt2agent->bindParam("agt", $agentIds);
//       $stmt2agent->execute();
//       $red2agent = $stmt2agent->fetch();
	 
	 

//  $balance_limit=$red2agent['value'];
 
//  $sqlpayment="SELECT SUM(`amount`) as paidamount FROM  `agent_bankpay_evidence` WHERE agentid=:agt   ";

 
//   $stmtpayment = $db->prepare($sqlpayment);  
//       $stmtpayment->bindParam("agt", $agentIds);
//       $stmtpayment->execute();
//       $red2payment= $stmtpayment->fetch();
	 
	 

//  $paidamount=$red2payment['paidamount'];
 
//  $sql_s="SELECT sum(transAmount) as sBalance
// FROM mosave_savingtransaction
// WHERE agentid=:agentid and transType='S' ";
  
//       $stmt = $db->prepare($sql_s);  
//       $stmt->bindParam("agentid", $agentIds);
//       $stmt->execute();
//       $red = $stmt->fetch();
	 

//  $sBalance=$red['sBalance'];
 
//  $sql_w="SELECT sum(transAmount) as wBalance
// FROM mosave_savingtransaction
// WHERE agentid=:agentid and transType='W' ";
//   $stmts = $db->prepare($sql_w);  
//       $stmts->bindParam("agentid", $agentIds);
//       $stmts->execute();
//       $reds = $stmts->fetch();
	 

//  $wBalance=$reds['wBalance'];
//       //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
//       //$result     = $stmt->fetchAll(PDO::FETCH_OBJ);
      
//      $netBalance=$sBalance-$wBalance;
//      $netBalance  =$netBalance-$paidamount; 
     
     
     
//       if ($netBalance>=$balance_limit) {
          
//          	$res['disable']=true;
            
//          // echo json_encode($wBalance); 
          
           
//       }elseif ($netBalance==0) {
          
          
//         	$res['disable']=false;
         
         
          
           
//       } else {
//          	$res['disable']=false;
          
          
//       } 
//       array_push($response, $res);
         
// }else{

if($val==0 || $val==null){
			$res['disable']=true;
			}else{
			$res['disable']=false;
			}
            array_push($response, $res);
          }
 
	  echo  json_encode($response); 
	  
     
      $db = null;
      
  } catch(PDOException $e) {
      echo '{"error":{"text":'. $e->getMessage() .'}}'; 
  }
});

//login agent


$app->post('/agent/login', function() use ($app)
{
    
   $userid = $app->request()->params('userid');
if($userid==null || $userid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$userid    = $request->userid;
	}
	
	$password = $app->request()->params('password');
if($password==null || $password==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$password    = $request->password;
	}
    $response = array();
    $userData = array();
    $userno   = $userid;
    $passw = $password;
   
    // $userno   = '09096456814';
    // $password = 'West@123';
      try {
    // $password = md5($passw);
    $sql = "SELECT `sn`, `pin`, `agentId`, `img`, `programId`, `merchantId`, `firstname`, `lastname`, `email`, `branchId`, `dateCreated`, `password`, `gender`, `birthdate`, `bvn`, `bank`, `bankCode`, `accountNo`, `accountName`, `city`, `state`, `default`, `locked`, `airtime_flag`, `deactivate`, `reasons`, `date`, `time`, `ip` FROM config_agent WHERE agentId=:userno ";
 
     $db = getConnection();
    $stmt = $db->prepare($sql);
    $stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch();
    $enc_pass= $result['password'];
    $locked= $result['locked'];
    if($locked=='1'){
       $response['error']   = true;
            $response['message'] = 'your account have been suspended, kindly contact the admin';
             echo json_encode($response); 
    }else if($enc_pass==''){
       $response['error']   = true;
            $response['message'] = 'wrong user id or password';
             echo json_encode($response); 
    }else{
    $auth = password_verify($password, $enc_pass);
if($auth=='1'){
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    // $response['err']=$enc_pass;
    // $response['error']   = $auth;
    // echo json_encode($response);
   
//     $sql2 = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
// 	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
// 								FROM `config_user_merchant_info` UM
//                   JOIN 

// `config_user` U ON U.UserId=UM.UserId 
//  JOIN `config_program` CM ON CM.programId=UM.merchantId

// 	WHERE U.`userId` =:usernos
            
// 								LIMIT 1";
    
    
    
// $sql2 = "SELECT `sn`, `pin`, `agentId`, `programId`,`merchantId`, `firstname`, `lastname`,
// `email`, `branchId`, `dateCreated`, `password`, `default`, `locked`, `airtime_flag`, `deactivate`, `reasons`  FROM `config_agent` 

// 	WHERE agentId =:usernos and password=:password
            
// 								LIMIT 1";
    
    
//     //             $sql2="Select * from config_user where userId=:usernos and password=:password";
  
//         $db2   = getConnection();
//         $stmt2 = $db2->prepare($sql2);
//         $stmt2->bindParam(":usernos", $userno, PDO::PARAM_STR);
//         $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
//         //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
        
//         $stmt2->execute();
//         $errorInfos = $stmt2->errorInfo();
//         if (isset($errorInfos[2])) {
//             $response['error']   = true;
//             $response['message'] = $errorInfos[2];
//             echo json_encode($response);
//         }
//         $result     = $stmt2->fetch();
//         $programDB = $result['programDb'];
        
        
            
            
            
                if($result['pin']==''){
                  $response['pinbool']=false;  
                }else{
                   $response['pinbool']=true;  
                }
                 
                $response['id']         = $result['sn'];
                $response['email']      = $result['email'];
                 $response['image']      = $result['img'];
                $response['submerchantId']    = $result['merchantId'];
                $response['firstname'] = $result['firstname'];
                $response['lastname'] = $result['lastname'];
                $response['agentId'] = $result['agentId'];
                $response['branchId'] = $result['branchId'];
                
   $response['accountNo'] =  $result['accountNo'];    
    $response['city'] = $result['city'];    
    $response['state'] = $result['state'];   
    $response['accountName'] = $result['accountName'];    
    $response['dateOfBirth'] = $result['birthdate'];    
   $response['gender'] =  $result['gender'];    
    $response['bank'] =$result['bank'];   
     $response['bankcode'] = $result['bankCode'];  
   $response['bvn'] =  $result['bvn'];   
                $response['message'] = 'login successful';
                // $response['serialNo']   = $result['serialNo'];
                //  $response['mobilenetwork']   = $result['mobilenetwork'];
           //array_push($userData, $response);
            
             //echo 'userData: ' . json_encode($response) ;
             
             echo json_encode($response) ;
        } else {
           // $response['enc']   = $enc_pass;
           // $response['message'] = 'wrong user id or password';
            $response['error']   = true;
            $response['message'] = 'wrong user id or password';
             echo json_encode($response);
        }
      
    }  
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
  
//echo json_encode($response);
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});

//Post customer Savings Plan



$app->post('/customer_sav', function() use ($app)
{
     
	
 $response = array();
  $customerid = $app->request()->params('customerid');
 if($customerid==null || $customerid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$customerid    = $request->customerid;
	if($customerid==null || $customerid==''){
		$response['error']   = true;
        $response['message'] = "customer id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
   $response['error']   = false;
        //$response['message'] = 'plan registered successfully';
         $response['message']=$customerid;
        echo json_encode($response);   
});



$app->post('/post/customer_savings_plan', function() use ($app)
{
    
 
  
     
    $response = array();
  $customerid = $app->request()->params('customerid');
 if($customerid==null || $customerid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$customerid    = $request->customerid;
	if($customerid==null || $customerid==''){
		$response['error']   = true;
        $response['message'] = "customer id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
    
     $savings_plan = $app->request()->params('savings_plan');
	 
     
    if($savings_plan==null || $savings_plan==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$savings_plan   = $request->savings_plan;

	}

 



	 
// 	 $savings_amt = $app->request()->params('savings_amt');
// 	if($savings_amt==null || $savings_amt==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$savings_amt    = $request->savings_amt;
// 	if($savings_amt==null || $savings_amt==''){
// 		$response['error']   = true;
//         $response['message'] = "savings_amt is required";
		
//         echo json_encode($response);
		
// 		return;
// 	}
// 	}

  
     
   


 	$dateCreated=date("Y-m-d H:i:s");
    
 
  
  
  
   
    
    
    
    
    

    
    
     try {
        $length=count($savings_plan);
        //check if customer is already enrolled for same plan here - where `cust_id`, `plan_id`,amount is same
	$status='Active';
                   
  for ($i = 0; $i < $length; $i++) {
        
        $planid[$i]=$savings_plan[$i]->planid;
        $amt[$i]=$savings_plan[$i]->amount;
        
      
     
        
         
         
    $sql = "INSERT INTO `mosave_customer_savings_plan`( `cust_id`, `plan_id`, `user_starting_date`, `system_starting_date`, `savings_amount`,`status`)
    VALUES (:cid,:pid,:user_starting_date,:system_starting_date,:samount,:status)";
       
                $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":pid", $planid[$i], PDO::PARAM_STR);
                $stmt->bindParam(":cid", $customerid, PDO::PARAM_STR);
               
                 $stmt->bindParam(":samount", $amt[$i], PDO::PARAM_STR);
                  $stmt->bindParam(":status", $status, PDO::PARAM_STR);
              
                $stmt->bindParam(":user_starting_date", $dateCreated, PDO::PARAM_STR);
                $stmt->bindParam(":system_starting_date", $dateCreated, PDO::PARAM_STR);
                



                $res=$stmt->execute();
                
  }

             if($res) {  
 $response['error']   = false;
        $response['message'] = 'plan registered successfully';
        // $response['message']=$customerid;
        echo json_encode($response);
             }else{
                 
                  $response['error']   = true;
                  //$response['message']=$customerid;
        $response['message'] = 'plan not registered pls retry';
          echo json_encode($response);
             }          
              
        
		
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//customer Savings

$app->post('/customer/savings', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
//      $customerId = $_POST['customerId'];
//     $agentId = $_POST['agentId'];
//     $transAmount = $_POST['transAmount'];
//      $accountId = $_POST['accountTypeId'];
// 	 $accountNo = $_POST['account_num'];


	 $planId = $app->request()->params('planId');
	 $customerId = $app->request()->params('customerId');
	 $agentId = $app->request()->params('agentId');
	 $transAmount = $app->request()->params('transAmount');
	 $accountId = $app->request()->params('accountTypeId');
	 $accountNo = $app->request()->params('account_num');
	 
     
    if($planId==null || $planId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$planId    = $request->planId;
	if($planId==null || $planId==''){
		$response['error']   = true;
        $response['message'] = "plan id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($customerId==null || $customerId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$customerId    = $request->customerId;
	if($customerId==null || $customerId==''){
		$response['error']   = true;
        $response['message'] = "customer id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	    
    if($agentId==null || $agentId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$agentId   = $request->agentId;
	if($agentId==null || $agentId==''){
		$response['error']   = true;
        $response['message'] = "agent id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	    
    if($transAmount==null || $transAmount==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$transAmount    = $request->transAmount;
	if($transAmount==null || $transAmount==''){
		$response['error']   = true;
        $response['message'] = "transaction amount is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	     
    if($accountNo==null || $accountNo==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountNo    = $request->account_num;
	if($accountNo==null || $accountNo==''){
		$response['error']   = true;
        $response['message'] = "account no  is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	     
    if($accountId==null || $accountId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountId    = $request->accountTypeId;
	if($accountId==null || $accountId==''){
		$response['error']   = true;
        $response['message'] = "account type id is required";
		
        echo json_encode($response);
		
		return;
	}
	}



	
   
      $refs= getTransactionRef();
      $transtype='S';
   
    
    //  $customerId = 1;
    // $agentId = '72';
    // $transAmount = 2000;
    //  $accountId = 1;
    //   $accountNo=1540000058;
     /*
     
   
   
     $accountId = $_POST['accountId']; */
     
    
    

    //$passw = md5($request->password);
$work = str_pad(8, 2, '0', STR_PAD_LEFT);

    $dateCreated=date("Y-m-d");
    
 $time=date("H:i:s");
$date_time=$dateCreated.' '.$time;
 $ip=$_SERVER['REMOTE_ADDR'];
  $tt=''; 
 $wal_flag='';

  $admin_charge=0; 
   
    //echo json_encode($userno);
      try {
         $dbs = getConnection();
         
         
//   $sqlsb = "SELECT  `account_num` FROM `config_customer_account_info` WHERE customerId=:custid and account_typeId=:actid";
//            
//                 $stmtc = $dbs->prepare($sqlsb);  
//         $stmtc->bindParam("custid", $customerId);
//         $stmtc->bindParam("actid", $accountId);
//                 $stmtc->execute();
//                 $resb = $stmtc->fetch();

//                 //$response=$email;
//                  if($resb){

// $accountNo = $resb['account_num'];



// }else{
//                 $response['error']=true;
//                 $response['message']="Cannot find Customer account number";

//             }

 $sqlsssa = "SELECT * FROM `savings_plan` WHERE sn=:pid";
       
        $stmtbsss = $dbs->prepare($sqlsssa);  
        $stmtbsss->bindParam("pid", $planId);
        
                $stmtbsss->execute();
                $resultsass = $stmtbsss->fetch();
   $plans_id = $resultsass['sn'];              
 $plan_name = $resultsass['plan_name'];
 $plan_amount = $resultsass['plan_amount'];
 $days = $resultsass['days'];
 $percentage_commission = $resultsass['percentage_commission'];
 $money_commission = $resultsass['flat_commision'];
$billing_type = $resultsass['billing_type'];
 $sqlsngs = "SELECT * FROM `mosave_customer_savings_plan` WHERE cust_id=:cid and plan_id=:pid";
       
        $stmtgs = $dbs->prepare($sqlsngs);  
        $stmtgs->bindParam("cid", $customerId);
        $stmtgs->bindParam("pid", $planId);
        
                $stmtgs->execute();
                $resustmtgs = $stmtgs->fetch();
               //$response['ch']= $resultsa;
                //echo json_encode($response);
               // $response['message']="Cannot find Customer account type";
                
                
                //$response=$email;
                 if(!$resustmtgs){
 $response['error']= true;
                $response['message']="Cannot find Customer Savings plan";
                json_encode($response);


}else{
               
$maturity_date =  $resustmtgs['maturity_date'];
$savings_amount =  $resustmtgs['savings_amount'];
$savings_count =  $resustmtgs['savings_count'];
$charge_flag =  $resustmtgs['charge_flag'];
$savings_count_t=$savings_count;
$charge_flag_t=$charge_flag;


//Calcualate Admin commission from here
if ($plans_id!=4){
if(($transAmount % $savings_amount)!=0){

$response['error']= true;
                $response['message']="payment must be in multiples of ".$savings_amount;
               echo json_encode($response);
                return;

}else{
$savings_count_t=$savings_count;
$charge_flag_t=$charge_flag;


if($savings_count==0 && $charge_flag==0){
   
 $sefss = " SELECT `sn`, `merchantName`, `merchantId`, `refer_amount`,`referral` FROM `mosave_settings` WHERE 1";
 $sffss = $dbs->prepare($sefss);
        $sffss->execute();
         $resultsddd = $sffss->fetch();
    $referral_amt = $resultsddd['refer_amount'];
     $referral = $resultsddd['referral'];
   
   
   if($referral=='1'){
      
       
     
    
       $totalairtime=$referral_amt;
       $se = "SELECT * from multilevel where child_id='$customerId' and activated=0";
 $sff = $dbs->prepare($se);
        $sff->execute();
         $results = $sff->fetch();
    $child_id = $results['child_id'];
     $parent_id = $results['parent_id'];
     //e.g parent_id= 201500000243, child_id=201500000290
//       $response['child_id']=$child_id;
//       $response['parent_id']=$parent_id;
//   echo json_encode($response);
//   return;



     //if referral is available
if($parent_id!='' && $child_id!=''){
    $db5   = getConnection();
	
	$sql5 = "SELECT  `userId`,`mobilenetwork`,`sn` FROM	 `config_user` 
	WHERE `sn` =:usernos LIMIT 1";
	
        $stmt5 = $db5->prepare($sql5);
        $stmt5->bindParam(":usernos", $parent_id, PDO::PARAM_STR);
       
        $stmt5->execute();
        $result     = $stmt5->fetch();
       
         $parentPhoneno = $result['userId'];
        
         $mobilenetwork= $result['mobilenetwork'];
		   if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='GLO'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9MOBILE'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='AIRTEL'){
	  $billid=20;
	  $itemcode='A05';
	  }
		 
		 
		 
		 
		
        //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount)  && ($chargeCurrency == $currency)) {
            
             //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount) ) {
                 $chargeResponsecode;
                
                 $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];

  curl_close($curl);
$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$referral_amt&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$parentPhoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
  // $session=$das["session_id"];
   //$code=$das["ex_resp_code"];
  //$ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);




//$get_me2=mysqli_query($con,"INSERT INTO `airtime_manual_push`( `phoneno`, `network`, `transAmount`, `transref`, `comment`, `status`, `createdDate`, `transtime`) VALUES('$phoneno','$mobilenetwork','$amount','$ref','$totalairtime','S','$dateCreated','$transtime')");





        $sed = "UPDATE `multilevel` SET `activated`=1 where child_id='$customerId' ";
 $sffd = $dbs->prepare($sed);
        $sffd->execute();
   }
   
   }
       
          $wal_flag2='check2';
$charge_flag=0;
//$new_count=$transAmount / $savings_amount;


$savings_count=$transAmount / $savings_amount;

 $charge_type='';            
       $d=strtotime("+1 Months");
$chargedt= date("Y-m-d", $d) ;  
             $dateCre=date("Y-m-d");   
           
$sqlupd = "UPDATE `mosave_customer_savings_plan` SET `savings_count`=:scount, `user_starting_date`=:startdate,`last_charge_date`=:lastchargedt,`next_charge_date`=:chargedt WHERE plan_id=:pid and cust_id=:cid";
$db = getConnection();
        $stmtupd = $db->prepare($sqlupd);  
        
        
         $stmtupd->bindParam(":scount", $savings_count,PDO::PARAM_STR);
          $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
        $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         $stmtupd->bindParam(":lastchargedt", $dateCre,PDO::PARAM_STR);
         $stmtupd->bindParam(":startdate", $dateCre,PDO::PARAM_STR);
         $stmtupd->bindParam(":chargedt", $chargedt,PDO::PARAM_STR);
         
$stmtupd->execute();          
                


}else{


$new_count=$transAmount / $savings_amount;

//35=18+5
$savings_count=$savings_count+$new_count;


$sqlupd = "UPDATE `mosave_customer_savings_plan` SET `savings_count`=:scount WHERE plan_id=:pid and cust_id=:cid";
$db = getConnection();
        $stmtupd = $db->prepare($sqlupd);  
        
       
         $stmtupd->bindParam(":scount", $savings_count,PDO::PARAM_STR);
          $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
        $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
$stmtupd->execute();

$k= $savings_count-($charge_flag*$days);
// for ($j=0; $j<=$k; $j++){
//  $tt= $j % $days;

// if($tt==1){
    
//     $wal_flag='check';
// //increment charge_flag by 1
// $charge_flag=$charge_flag+1;


// $sqlupd = "UPDATE `mosave_customer_savings_plan` SET `charge_flag`=:cflag WHERE plan_id=:pid and cust_id=:cid";
// $db = getConnection();
//         $stmtupd = $db->prepare($sqlupd);  
        
//         $stmtupd->bindParam(":cflag", $charge_flag,PDO::PARAM_STR);
        
//           $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
//         $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
// $stmtupd->execute();


// // do an insert into admin_ledger.admin_charge


//  //do an insert into admin_ledger.admin_charge
//  if($billing_type=='P'){
// $admin_charge= ($savings_amount * $days * $percentage_commission)/100;
// $charge_type='P';
// }
//  if($billing_type=='F'){
//   $admin_charge= $money_commission; 
//   $charge_type='F';
//  }
 
 
// $transtype='commission';
// $trans_mode='AC';

// $sqla = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
//                     `accountType`, `accountCode`,`trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:accountCode,:trans_mode,:datecreated,:time,:ip)";
     
// $db = getConnection();
//         $stmta = $db->prepare($sqla);  
        
//         $stmta->bindParam(":customerId", $customerId,PDO::PARAM_STR);
//          $stmta->bindParam(":agentId", $agentId,PDO::PARAM_STR);
//           $stmta->bindParam(":actids", $accountId,PDO::PARAM_STR);
//           $stmta->bindParam(":pid", $planId,PDO::PARAM_STR);
//          $stmta->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
//          $stmta->bindParam(":transAmount", $admin_charge,PDO::PARAM_STR);
//           $stmta->bindParam(":transtype", $transtype,PDO::PARAM_STR);
//           $stmta->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
//           $stmta->bindParam(":transref", $refs,PDO::PARAM_STR);
//         $stmta->bindParam(":accountType", $accountType,PDO::PARAM_STR);
//          $stmta->bindParam(":accountCode", $accountCode,PDO::PARAM_STR);
         

      
       
//       $stmta->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
//       $stmta->bindParam(":time", $time,PDO::PARAM_STR);
//       $stmta->bindParam(":ip", $ip,PDO::PARAM_STR);

//                 //$stmt->execute();
//                 $resultas=$stmta->execute();


// $sqlwa="INSERT INTO `mosave_admin_ledger`( `plan_id`, `cust_id`, `admin_charge`, `date`, `charge_type`) VALUES (:pId,:cId,:adcharge,:datecreated,:charge_type)";
     
// $db = getConnection();
//         $stmtsqlwa = $db->prepare($sqlwa);  
        
//         $stmtsqlwa->bindParam(":cId", $customerId,PDO::PARAM_STR);
//          $stmtsqlwa->bindParam(":pId", $planId,PDO::PARAM_STR);
//           $stmtsqlwa->bindParam(":adcharge", $admin_charge,PDO::PARAM_STR);
//           $stmtsqlwa->bindParam(":datecreated", $date_time,PDO::PARAM_STR);
//          $stmtsqlwa->bindParam(":charge_type", $charge_type,PDO::PARAM_STR);
         
         

      
       
      
       
//                 //$stmt->execute();
//                 $resultsqf=$stmtsqlwa->execute(); 

// }
// }

}

}

}

    
if ($plans_id==4){

// $savings_count_t=$savings_count;
// $charge_flag_t=$charge_flag;


if($savings_count==0 && $charge_flag==0){
   
 $sefss = " SELECT `sn`, `merchantName`, `merchantId`, `refer_amount`,`referral` FROM `mosave_settings` WHERE 1";
 $sffss = $dbs->prepare($sefss);
        $sffss->execute();
         $resultsddd = $sffss->fetch();
    $referral_amt = $resultsddd['refer_amount'];
     $referral = $resultsddd['referral'];
   
   if($referral=='1'){
      
       
     
    
       $totalairtime=$referral_amt;
       $se = "SELECT * from multilevel where child_id='$customerId' and activated=0";
 $sff = $dbs->prepare($se);
        $sff->execute();
         $results = $sff->fetch();
    $child_id = $results['child_id'];
     $parent_id = $results['parent_id'];
     //e.g parent_id= 201500000243, child_id=201500000290
     
     //if referral is available
if($parent_id!='' && $child_id!=''){
    $db5   = getConnection();
	
	$sql5 = "SELECT  `userId`,`mobilenetwork`,`sn` FROM	 `config_user` 
	WHERE `sn` =:usernos LIMIT 1";
	
        $stmt5 = $db5->prepare($sql5);
        $stmt5->bindParam(":usernos", $parent_id, PDO::PARAM_STR);
       
        $stmt5->execute();
        $result     = $stmt5->fetch();
       
         $parentPhoneno = $result['userId'];
        
         $mobilenetwork= $result['mobilenetwork'];
		   if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='GLO'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9MOBILE'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='AIRTEL'){
	  $billid=20;
	  $itemcode='A05';
	  }
		 
		 
		 
		 
		
        //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount)  && ($chargeCurrency == $currency)) {
            
             //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount) ) {
                 $chargeResponsecode;
                
                 $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];

  curl_close($curl);
$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$referral_amt&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$parentPhoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
  // $session=$das["session_id"];
   //$code=$das["ex_resp_code"];
  //$ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);



$dateCreated = date("Y-m-d g:i:s");
 $transtime = date("g:i:s");

//$get_me2=mysqli_query($con,"INSERT INTO `airtime_manual_push`( `phoneno`, `network`, `transAmount`, `transref`, `comment`, `status`, `createdDate`, `transtime`) VALUES('$phoneno','$mobilenetwork','$amount','$ref','$totalairtime','S','$dateCreated','$transtime')");

        $sed = "UPDATE `multilevel` SET `activated`=1 where child_id='$customerId' ";
 $sffd = $dbs->prepare($sed);
        $sffd->execute();
   }
   
   }
       
       $wal_flag2='check2';
$charge_flag=0;
//$new_count=$transAmount / $savings_amount;


$savings_count=1;

 $charge_type='';
 
//  if($billing_type=='P'){
//  //do an insert into admin_ledger.admin_charge
// $admin_charge= ($transAmount * $percentage_commission)/100;
// $charge_type='P';
// }

 //do an insert into admin_ledger.admin_charge
// $admin_charge=  $money_commission;
// $charge_type='F';

// $transtype='commission';
// $trans_mode='AC';

// $sqla = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
//                     `accountType`, `accountCode`,`trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:accountCode,:trans_mode,:datecreated,:time,:ip)";
     
// $db = getConnection();
//         $stmta = $db->prepare($sqla);  
        
//         $stmta->bindParam(":customerId", $customerId,PDO::PARAM_STR);
//          $stmta->bindParam(":agentId", $agentId,PDO::PARAM_STR);
//           $stmta->bindParam(":actids", $accountId,PDO::PARAM_STR);
//           $stmta->bindParam(":pid", $planId,PDO::PARAM_STR);
//          $stmta->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
//          $stmta->bindParam(":transAmount", $admin_charge,PDO::PARAM_STR);
//           $stmta->bindParam(":transtype", $transtype,PDO::PARAM_STR);
//           $stmta->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
//           $stmta->bindParam(":transref", $refs,PDO::PARAM_STR);
//         $stmta->bindParam(":accountType", $accountType,PDO::PARAM_STR);
//          $stmta->bindParam(":accountCode", $accountCode,PDO::PARAM_STR);
         

      
       
//       $stmta->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
//       $stmta->bindParam(":time", $time,PDO::PARAM_STR);
//       $stmta->bindParam(":ip", $ip,PDO::PARAM_STR);

//                 //$stmt->execute();
//                 $resultas=$stmta->execute();

// $sqlwa="INSERT INTO `mosave_admin_ledger`( `plan_id`, `cust_id`, `admin_charge`, `date`, `charge_type`) VALUES (:pId,:cId,:adcharge,:datecreated,:charge_type)";
     
// $db = getConnection();
//         $stmtsqlwa = $db->prepare($sqlwa);  
        
//         $stmtsqlwa->bindParam(":cId", $customerId,PDO::PARAM_STR);
//          $stmtsqlwa->bindParam(":pId", $planId,PDO::PARAM_STR);
//           $stmtsqlwa->bindParam(":adcharge", $admin_charge,PDO::PARAM_STR);
//           $stmtsqlwa->bindParam(":datecreated", $date_time,PDO::PARAM_STR);
//          $stmtsqlwa->bindParam(":charge_type", $charge_type,PDO::PARAM_STR);
         
                    // $resultsqf=$stmtsqlwa->execute(); 
                
                 $d=strtotime("+1 Months");
$chargedt= date("Y-m-d", $d) ;  
             $dateCre=date("Y-m-d");   
           
$sqlupd = "UPDATE `mosave_customer_savings_plan` SET `savings_count`=:scount, `user_starting_date`=:startdate,`last_charge_date`=:lastchargedt,`next_charge_date`=:chargedt WHERE plan_id=:pid and cust_id=:cid";
$db = getConnection();
        $stmtupd = $db->prepare($sqlupd);  
        
        
         $stmtupd->bindParam(":scount", $savings_count,PDO::PARAM_STR);
          $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
        $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         $stmtupd->bindParam(":startdate", $dateCre,PDO::PARAM_STR);
          $stmtupd->bindParam(":lastchargedt", $dateCre,PDO::PARAM_STR);
         $stmtupd->bindParam(":chargedt", $chargedt,PDO::PARAM_STR);
         
$stmtupd->execute();
                
// $sqlupd = "UPDATE `mosave_customer_savings_plan` SET `savings_count`=:scount,`charge_flag`=:cflag WHERE plan_id=:pid and cust_id=:cid";
// $db = getConnection();
//         $stmtupd = $db->prepare($sqlupd);  
        
//         $stmtupd->bindParam(":cflag", $charge_flag,PDO::PARAM_STR);
//          $stmtupd->bindParam(":scount", $savings_count,PDO::PARAM_STR);
//           $stmtupd->bindParam(":pid", $planId,PDO::PARAM_STR);
//         $stmtupd->bindParam(":cid", $customerId,PDO::PARAM_STR);
         
// $stmtupd->execute();

}

}




            $sqlsa = "SELECT  `account_code`, `account_name`, `minimum_bal`, `desc` FROM `mosave_account_type` WHERE sn=:actid";
       
        $stmtb = $dbs->prepare($sqlsa);  
        $stmtb->bindParam("actid", $accountId);
        
                $stmtb->execute();
                $resultsa = $stmtb->fetch();
               //$response['ch']= $resultsa;
                //echo json_encode($response);
               // $response['message']="Cannot find Customer account type";
                
                
                //$response=$email;
                 if(!$resultsa){
 $response['error']= true;
                $response['message']="Cannot find Customer account type";
echo json_encode($response);

}else{
               
$accountCode = $resultsa['account_code'];
$accountType = $resultsa['account_name'];
$bal = $resultsa['minimum_bal'];

$walletqry="SELECT account_bal as wBalance FROM `mosave_wallet` WHERE  customerId=:custid and accountId=:actid";
   
   $waldb = getConnection();
        $walstmt = $waldb->prepare($walletqry);  
        
        $walstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmt->bindParam(":actid", $accountId,PDO::PARAM_STR);     

 $walstmt->execute();
	 $red = $walstmt->fetch();
	 

 $wBalance=$red['wBalance'];
 
 //if(is_null($wBalance) || $wBalance==0)
 if($walstmt->rowCount() == 0)
                    {
                      
                      
                      //$test='lummy';
                      //insert into wallet if account has no balance already
                       $insewalqry="INSERT INTO `mosave_wallet`( `agentId`, `accountId`,`accountNo`, `customerId`, `account_bal`) 
  VALUES  (:agentid,:actid,:accno,:custid,:amt)"; 
$waldb = getConnection();
        $walstmt1 = $waldb->prepare($insewalqry);  
        $walstmt1->bindParam(":agentid", $agentId,PDO::PARAM_STR);
         $walstmt1->bindParam(":actid", $accountId,PDO::PARAM_STR);    
		 $walstmt1->bindParam(":accno", $accountNo,PDO::PARAM_STR);
        
        $walstmt1->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmt1->bindParam(":amt", $transAmount,PDO::PARAM_STR);     

 $walstmt1->execute();
 $newBalance=$transAmount;
                                    }else{
                                        
                                       // $response['sav']=yes;
               // $response['m']=$wBalance;
                      //update wallet if account has balance already
 
                            //$wBalance=$red['wBalance']==""?0.00:$red['wBalance'];
                            $newBalance= $wBalance + $transAmount;
                            
                          $updwalqry="UPDATE `mosave_wallet` SET `account_bal`=:newBalance  WHERE accountId=:actid and customerId=:custid ";
        $waldbs = getConnection();
        $walstmt = $waldbs->prepare($updwalqry);  
        
        $walstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmt->bindParam(":actid", $accountId,PDO::PARAM_STR);
          $walstmt->bindParam(":newBalance", $newBalance,PDO::PARAM_STR);

 $walstmt->execute();

                    }


$planwalletqry="SELECT `account_bal` as planwBalance, `available_bal` as planavailBalance FROM `mosave_plan_wallet` WHERE  customerId=:custid and plan_id=:pid  and accountId=:actid";
   
   $planwaldb = getConnection();
        $planwalstmt = $planwaldb->prepare($planwalletqry);  
        
        $planwalstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $planwalstmt->bindParam(":pid", $planId,PDO::PARAM_STR);
         $planwalstmt->bindParam(":actid", $accountId,PDO::PARAM_STR);     

 $planwalstmt->execute();
	 $reds = $planwalstmt->fetch();
	 

 $planwBalance=$reds['planwBalance'];
  $planavailBalance=$reds['planavailBalance'];
 if($savings_count_t==0 && $charge_flag_t==0){
     
     $avail_bal=$transAmount-$admin_charge;
//      if($plans_id==4){
//          $avail_bal=$transAmount;
//      }else{
//  $avail_bal=$transAmount-$admin_charge;
//      }
 }
 if($planwalstmt->rowCount() == 0)
                    {
                      
                      
                      //$test='lummy';
                      //insert into wallet if account has no balance already
                       $planinsewalqry="INSERT INTO `mosave_plan_wallet`( `agentId`, `accountId`,`accountNo`, `customerId`,`plan_id`, `account_bal`,`available_bal`) 
  VALUES  (:agentid,:actid,:accno,:custid,:pid,:amt,:avbal)"; 
$planwaldb = getConnection();
        $plnwalstmt1 = $planwaldb->prepare($planinsewalqry);  
        $plnwalstmt1->bindParam(":agentid", $agentId,PDO::PARAM_STR);
         $plnwalstmt1->bindParam(":actid", $accountId,PDO::PARAM_STR);    
		 $plnwalstmt1->bindParam(":accno", $accountNo,PDO::PARAM_STR);
         $plnwalstmt1->bindParam(":pid", $planId,PDO::PARAM_STR);
        $plnwalstmt1->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $plnwalstmt1->bindParam(":amt", $transAmount,PDO::PARAM_STR);   
          $plnwalstmt1->bindParam(":avbal", $avail_bal,PDO::PARAM_STR);   

 $plnwalstmt1->execute();
 $plannewBalance=$transAmount;
                                    }else{
                                        
                                       // $response['sav']=yes;
               // $response['m']=$wBalance;
                      //update wallet if account has balance already
 
                            //$wBalance=$red['wBalance']==""?0.00:$red['wBalance'];
                            $plannewBalance= $planwBalance + $transAmount;
                         
                         
                             
                             $avail_bal=$planavailBalance+ $transAmount;
                          $updwalqry11="UPDATE `mosave_plan_wallet` SET `account_bal`=:newBalance,`available_bal`=:avbal  WHERE accountId=:actid and plan_id=:pid and  customerId=:custid ";
        $waldbs11 = getConnection();
        $plnwalstmt1 = $waldbs11->prepare($updwalqry11);  
         $plnwalstmt1->bindParam(":pid", $planId,PDO::PARAM_STR);
        $plnwalstmt1->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $plnwalstmt1->bindParam(":actid", $accountId,PDO::PARAM_STR);
          $plnwalstmt1->bindParam(":newBalance", $plannewBalance,PDO::PARAM_STR);
  $plnwalstmt1->bindParam(":avbal", $avail_bal,PDO::PARAM_STR);   

 $plnwalstmt1->execute();

                    }







//insert new $savings_count
//insert incremented $charge_flag




$transtype='S';      
$trans_mode='CS';

    $sql = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`,`planId`, `accountNo`, `transAmount`,`transType`,`transref`,
                    `accountType`, `accountCode`,`trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:accountCode,:trans_mode,:datecreated,:time,:ip)";
     
$db = getConnection();
        $stmt = $db->prepare($sql);  
        
        $stmt->bindParam(":customerId", $customerId,PDO::PARAM_STR);
         $stmt->bindParam(":agentId", $agentId,PDO::PARAM_STR);
          $stmt->bindParam(":actids", $accountId,PDO::PARAM_STR);
           $stmt->bindParam(":pid", $planId,PDO::PARAM_STR);
         $stmt->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
         $stmt->bindParam(":transAmount", $transAmount,PDO::PARAM_STR);
          $stmt->bindParam(":transtype", $transtype,PDO::PARAM_STR);
           $stmt->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
           $stmt->bindParam(":transref", $refs,PDO::PARAM_STR);
        $stmt->bindParam(":accountType", $accountType,PDO::PARAM_STR);
         $stmt->bindParam(":accountCode", $accountCode,PDO::PARAM_STR);
         

      
       
       $stmt->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
       $stmt->bindParam(":time", $time,PDO::PARAM_STR);
       $stmt->bindParam(":ip", $ip,PDO::PARAM_STR);

                //$stmt->execute();
                $result=$stmt->execute();
                //$result = $stmt->fetch();
                
                 if($result){
        
                             //$response['id'] = $test;
//                               $customerId = $request->customerId;
//     $agentId = $request->agentId;
//     $transAmount = $request->transAmount;
//      $accountId = $request->accountTypeId;
// 	 $accountNo = $request->account_num;
                   
                $response['error']=false;
                $response['message']= " Successful ";
                $response['source']="Savings";
                $response['agentId']=$agentId;
                $response['transAmount']= $transAmount;
                $response['accountId']=$accountId;
                $response['trxref']=$refs;
                 $response['plan_name']=$plan_name;
                $response['accountNo']=$accountNo;
                $response['timestamp']=$dateCreated;
                $response['time']=$time;
                
 $sqlsa1 = "SELECT `sn`, `userId`, `BVN_num`, `firstName`, `mname`, `lastName`, `email`, `mobilenetwork`, `lastResetDate`, `pic`, `locked` FROM `config_user` WHERE sn=:custid";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam("custid", $customerId);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $phone= $resultsa1['userId'];
                $email= $resultsa1['email'];
                $fname=$resultsa1['firstName'];
                $name= $resultsa1['firstName'].' '.$resultsa1['lastName'];
                
                 $smsmsg     = 'Dear '.$fname.', there is deposit on your MoSave account.  \nAcct: '.$accountNo.'\nPlan: '.$plan_name.'\nAmt: '.$transAmount.' CR'.'\nNet Bal: '.$newBalance.'';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
               //$response['error']=$smscheck;
            //$response['message']=$phone;
           //echo json_encode($response);
             $note="";   
 $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1     = 'NGN'.$transAmount.' has been credited into your MoSave Account.<br>
 
 <br> <strong><u> Here is what you need to know: </u></strong><br>
Transaction Ref.	:' . $refs . '<br>
Account Number	:' . $accountNo . '<br>

Account Name	:	' . $name . '<br>
Plan Name	:	' . $plan_name . '<br>
Amount	:	NGN' . $transAmount . '<br>
Note	:	' . $note . '<br>
Value Date	:	' . $dateCreated . '<br>

Time of Transaction	:	' . $time . '<br>


The balance on this account as at  '. $time .'  are as follows;<br>
Net Balance	:  NGN' . $newBalance . '<br>


';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                    $subject = "MoLoyal Credit Transaction [ ".$transAmount." ]";
                $type    = $name;
                
                $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                
                
            }else{
                $response['error']=true;
                $response['message']="There was an error contacting the server, please retry";

            }
             } 

}
        //$user->id = $db->lastInsertId();
        $db = null;
        echo json_encode($response); 
        

    } catch(PDOException $e) {
        //error_log($e->getMessage(), 3, '/var/tmp/php.log');
        $response['error']=true;
            $response['message']=$e->getMessage();
           echo json_encode($response);
    }
  });


//Email sending test
$app->post('/email/test', function() use ($app)
{
$from='care@moloyal.com';
$to='oluodebiyi@gmail.com';
$subject='subj';
$type='tes';

 $msg     = 'Your forgot login details request is received. Your new temporary token is. \n'.$rando.'\nPlease use to login';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
             $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                
               $response['error']=$emailsent;
            //$response['message']=$e->getMessage();
           echo json_encode($response);

});               


//SMS test
$app->post('/sms/test', function() use ($app)
{
$accountNo='te';
$transAmount=45;
$rando=23435320;
$phone='09096456814';
 $smsmsg     = 'Your forgot login details request is received. Your new temporary token is. \n'.$rando.'\nPlease use to login';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
               $response['error']=$smscheck;
            //$response['message']=$e->getMessage();
           echo json_encode($response);

});               
//customer Withdrawal

$app->post('/customer/withdrawal', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    // $customerId = $_POST['customerId'];
    // $agentId = $_POST['agentId'];
    // $transAmount = $_POST['transAmount'];
    //  $accountId = $_POST['accountTypeId'];
    //   $accountNo = $_POST['account_num'];
    //   $otp = $_POST['otp'];
      
      	 $customerId = $app->request()->params('customerId');
	 $agentId = $app->request()->params('agentId');
	 $planId = $app->request()->params('planId');
	 $transAmount = $app->request()->params('transAmount');
	 $accountId = $app->request()->params('accountTypeId');
	 $accountNo = $app->request()->params('account_num');
	  $otp = $app->request()->params('otp');
     
    if($customerId==null || $customerId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$customerId    = $request->customerId;
	if($customerId==null || $customerId==''){
		$response['error']   = true;
        $response['message'] = "customer id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	 if($planId==null || $planId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$planId    = $request->planId;
	if($planId==null || $planId==''){
		$response['error']   = true;
        $response['message'] = "plan id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	    
    if($agentId==null || $agentId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$agentId   = $request->agentId;
	if($agentId==null || $agentId==''){
		$response['error']   = true;
        $response['message'] = "agent id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	    
    if($transAmount==null || $transAmount==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$transAmount    = $request->transAmount;
	if($transAmount==null || $transAmount==''){
		$response['error']   = true;
        $response['message'] = "transaction amount is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	     
    if($accountNo==null || $accountNo==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountNo    = $request->account_num;
	if($accountNo==null || $accountNo==''){
		$response['error']   = true;
        $response['message'] = "account no  is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	     
    if($accountId==null || $accountId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountId    = $request->accountTypeId;
	if($accountId==null || $accountId==''){
		$response['error']   = true;
        $response['message'] = "account type id is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($otp==null || $otp==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$otp    = $request->otp;
	if($otp==null || $otp==''){
		$response['error']   = true;
        $response['message'] = "otp is required";
		
        echo json_encode($response);
		
		return;
	}
	}
    $refs= getTransactionRef();
    
    
     //$otp=939182;
     
     
    //   $customerId = 13;
    // $agentId = '75';
    // $transAmount = 1000;
    //  $accountId = 1;
    // $accountNo=1540000056;
    // $otp =732149;
    /*
     $customerId = '1';
    $agentId = '';
    $transAmount ='3000';
     $accountId = $request->accountId; */
     
     
    $transtype='W';
    

    //$passw = md5($request->password);
$work = str_pad(8, 2, '0', STR_PAD_LEFT);

$dateCreated=date("Y-m-d");
    
$time=date("H:i:s");

$ip=$_SERVER['REMOTE_ADDR'];
 

   
   
    //echo json_encode($userno);
      try {
           $dbs = getConnection();
        
  $sqlsb = "SELECT `sn`, `userId`,  `country`, `status`, `dateOfBirth`, `tp_checker` FROM `config_user`  WHERE tp_checker=:otp";
           
                $stmtc = $dbs->prepare($sqlsb);  
        $stmtc->bindParam("otp", $otp);
        
                $stmtc->execute();
                $resb = $stmtc->fetch();
$otps = $resb['tp_checker'];
//$response['errors']=$otps;
                //$response=$email;
                 if($otps==""){

 $response['error']=true;
                $response['message']="Inavlid Customer OTP or OTP expired";



}else{
               
$sqlsssa = "SELECT * FROM `savings_plan` WHERE sn=:pid";
       
        $stmtbsss = $dbs->prepare($sqlsssa);  
        $stmtbsss->bindParam("pid", $planId);
        
                $stmtbsss->execute();
                $resultsass = $stmtbsss->fetch();
   $plans_id = $resultsass['sn'];              
 $plan_name = $resultsass['plan_name'];
 $plan_amount = $resultsass['plan_amount'];
 $days = $resultsass['days'];
           



            $sqlsa = "SELECT  `account_code`, `account_name`, `minimum_bal`, `desc` FROM `mosave_account_type` WHERE sn=:actid";
       
        $stmtb = $dbs->prepare($sqlsa);  
        $stmtb->bindParam("actid", $accountId);
        
                $stmtb->execute();
                $resultsa = $stmtb->fetch();

                //$response=$email;
                 if(!$resultsa){
 //$response['error']=true;
                $response['message']="Cannot find Customer account type";


}else{
               
$accountCode = $resultsa['account_code'];
$accountType = $resultsa['account_name'];
$bal = $resultsa['minimum_bal'];

$walletqrys="SELECT `account_bal` as wBalances FROM `mosave_wallet` WHERE  customerId=:custid and accountId=:actid ";
   
   $waldb = getConnection();
        $walstmts = $waldb->prepare($walletqrys);  
        
        $walstmts->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmts->bindParam(":actid", $accountId,PDO::PARAM_STR); 
        
 $walstmts->execute();
	 $reds = $walstmts->fetch();
	 

 $wallet_balances=$reds['wBalances'];
 
 //get transactions done between last charge date and today
 $sqlupd = "SELECT * FROM `mosave_customer_savings_plan` where cust_id=:cust_id and plan_id=:pid"; 
              
              $planwaldb = getConnection();
        $plastmtss = $planwaldb->prepare($sqlupd);  
        
        
        
           $plastmtss->bindParam(":cust_id", $customerId,PDO::PARAM_STR);  
		   $plastmtss->bindParam(":pid", $planId,PDO::PARAM_STR);

 $plastmtss->execute();

	$redtmt = $plastmtss->fetch();

$next_charge_date=$redtmt['next_charge_date']; 

$last_charge_date=$redtmt['last_charge_date']; 

$last_charge_plus1day = date('Y-m-d', strtotime( $last_charge_date . " +1 days"));
 $today=date("Y-m-d"); 
$sqsa = "SELECT * FROM `mosave_savingtransaction` WHERE customerId=:cid and transType='S' AND `transDate` BETWEEN '$last_charge_plus1day' AND '$today'";
       
        $sdss = $dbs->prepare($sqsa);  
        $sdss->bindParam("cid", $customerId);
        
                $sdss->execute();
                $resultbss = $sdss->fetch();
                
                
                
$walletqry="SELECT `available_bal` as wBalance, `account_bal`  FROM `mosave_plan_wallet` WHERE  customerId=:custid and accountId=:actid and plan_id=:pid ";
   
   $waldb = getConnection();
        $walstmt = $waldb->prepare($walletqry);  
        
        $walstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
         $walstmt->bindParam(":actid", $accountId,PDO::PARAM_STR); 
         $walstmt->bindParam(":pid", $planId,PDO::PARAM_STR); 

 $walstmt->execute();
	 $red = $walstmt->fetch();
	 

 $wBalance=$red['wBalance'];
  $account_bal=$red['account_bal'];
 if($wBalance=="")
 {
   //insert into wallet if account has no balance already
   $response['error']=true;
$response['message']="No balance in the account";




                 }else{
   //update wallet if account has balance already

         //$wBalance=$red['wBalance']==""?0.00:$red['wBalance'];
         $amts=$transAmount;
$amt=$transAmount*(-1); 
         $newBalance= $wBalance + $amt;  
          $newBalancecheck= $newBalance*(-1);  
          
        $mosave_wal=$wallet_balances- $transAmount;
        $ac_bal=$account_bal- $transAmount;
          // $response['t']=$newBalancecheck;
         //$response['n']=$newBalance;
//$response['j']=$bal;



if($amts>$wBalance){

 $response['error']=true;
                $response['message']="Insufficient funds";
                                   
               
             }
             elseif(($sdss->rowCount() != 0) && $wBalance==$transAmount){


 $response['error']=true;
$response['message']="customer can not withdraw total amount, monthly commission needs to be deducted";


}			 
         
             // elseif($newBalance<$bal || $newBalancecheck>$bal  ){ 
                   
            //      $response['error']=true;
            //     $response['message']="Minimum account balance cannot be withdrawn";
            //   }
            
            else{

$available_bal=$newBalance-$bal;


$updwalqryplan="UPDATE `mosave_plan_wallet` SET `account_bal`=:ac_bal, `available_bal`=:newb  WHERE accountId=:actid and customerId=:custid and plan_id=:pid ";
$waldbs = getConnection();
$walstmtplan = $waldbs->prepare($updwalqryplan);  
$walstmtplan->bindParam(":ac_bal", $ac_bal,PDO::PARAM_STR);
$walstmtplan->bindParam(":newb", $newBalance,PDO::PARAM_STR); 
$walstmtplan->bindParam(":custid", $customerId,PDO::PARAM_STR);
$walstmtplan->bindParam(":actid", $accountId,PDO::PARAM_STR); 
$walstmtplan->bindParam(":pid", $planId,PDO::PARAM_STR); 

$walstmtplan->execute();

       $updwalqry="UPDATE `mosave_wallet` SET `account_bal`='$mosave_wal'  WHERE accountId=:actid and customerId=:custid ";
$waldb = getConnection();
$walstmt = $waldb->prepare($updwalqry);  

$walstmt->bindParam(":custid", $customerId,PDO::PARAM_STR);
$walstmt->bindParam(":actid", $accountId,PDO::PARAM_STR);     

$walstmt->execute();

 $trans_mode='CW';

   
$sql = "INSERT INTO `mosave_savingtransaction`(`customerId`, `agentId`,`accountId`, `planId`, `accountNo`, `transAmount`,`transType`,`transref`,
`accountType`, `accountCode`,`trans_mode`,  `transDate`,`time`,`ip`) VALUES (:customerId,:agentId,:actids,:pid,:accountNo,:transAmount,:transtype,:transref,:accountType,:accountCode,:trans_mode,:datecreated,:time,:ip)";

$db = getConnection();
$stmt = $db->prepare($sql);  

$stmt->bindParam(":customerId", $customerId,PDO::PARAM_STR);
$stmt->bindParam(":agentId", $agentId,PDO::PARAM_STR);
$stmt->bindParam(":actids", $accountId,PDO::PARAM_STR);
$stmt->bindParam(":pid", $planId,PDO::PARAM_STR);
$stmt->bindParam(":accountNo", $accountNo,PDO::PARAM_STR);
$stmt->bindParam(":transAmount", $transAmount,PDO::PARAM_STR);
$stmt->bindParam(":transtype", $transtype,PDO::PARAM_STR);
$stmt->bindParam(":transref", $refs,PDO::PARAM_STR);
$stmt->bindParam(":trans_mode", $trans_mode,PDO::PARAM_STR);
$stmt->bindParam(":accountType", $accountType,PDO::PARAM_STR);
$stmt->bindParam(":accountCode", $accountCode,PDO::PARAM_STR);




$stmt->bindParam(":datecreated", $dateCreated,PDO::PARAM_STR);
$stmt->bindParam(":time", $time,PDO::PARAM_STR);
$stmt->bindParam(":ip", $ip,PDO::PARAM_STR);

//$stmt->execute();
$result=$stmt->execute();
//$result = $stmt->fetch();

if($result){

         

                $response['error']=false;
                $response['message']=" Successful ";
                $response['source']="Withdrawal";
                $response['agentId']=$agentId;
                $response['customerId']= $customerId;
                $response['transAmount']= $transAmount;
               $response['trxref']=$refs;
                $response['plan_name']=$plan_name;
                $response['accountId']=$accountId;
                $response['accountNo']=$accountNo;
                $response['timestamp']=$dateCreated;
                $response['time']=$time;
                
                $sqlsa1 = "SELECT `sn`, `userId`, `BVN_num`, `firstName`, `mname`, `lastName`, `email`, `mobilenetwork`, `lastResetDate`, `pic`, `locked` FROM `config_user` WHERE sn=:custid";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam("custid", $customerId);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                 $phone= $resultsa1['userId'];
                $email= $resultsa1['email'];
                $name= $resultsa1['firstName'].' '.$resultsa1['lastName'];
                
                 $smsmsg     = 'Dear '.$name.', there is withdrawal on your account. MoSave Acct: '.$accountNo.'\nPlan: '.$plan_name.'\nAmt: '.$transAmount.' DR'.'\nNet Bal: '.$newBalance.'';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
               //$response['error']=$smscheck;
            //$response['message']=$e->getMessage();
           //echo json_encode($response);
               $note="";   
 $from    = "noreply@moloyal.com";
                $to      = $email;
              
              
              
                         $msg1     = 'NGN '.$transAmount.' has been debited from your MoSave Account.<br>
 
<br> <strong><u> Here is what you need to know: </u></strong><br>
Transaction Ref.	:  ' . $refs . '<br>
Account Number	:  ' . $accountNo . '<br>

Account Name	:	' . $name . '<br>
Plan Name	:	' . $plan_name . '<br>
Amount	:	NGN' . $transAmount . '<br>
Note	:	' . $note . '<br>
Value Date	:	' . $dateCreated . '<br>

Time of Transaction	:	' . $time . '<br>


The balance on this account as at  '. $time .'  are as follows;<br>

Available Balance	:  NGN' . $newBalance . '<br>


';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                    $subject = "MoLoyal Debit Transaction [ ".$transAmount." ]";
                $type    = $name;
                
                $emailsent=sendEmail($from, $to, $msg, $subject, $type);
                
                
}else{
$response['error']=true;
$response['message']="There was an error contacting the server, please retry";

}
}   
}
}		

}
//$user->id = $db->lastInsertId();
$dbs = null;
$db = null;
echo json_encode($response); 
} catch(PDOException $e) {
//error_log($e->getMessage(), 3, '/var/tmp/php.log');
$response['error']=true;
$response['message']=$e->getMessage();
echo json_encode($response);
}

});



//login user


$app->post('/user/login', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    
     $userno = $app->request()->params('userno');
if($userno==null || $userno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$userno    = $request->userno;
	}
	
	$password = $app->request()->params('password');
if($password==null || $password==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$password    = $request->password;
	}
    //$password = md5($password);
    // $userno   = '09028652543';
    // $password = 'test';
    
    $sql = "SELECT   `password` FROM config_user WHERE userId=:userno ";
 
     $db = getConnection();
    $stmt = $db->prepare($sql);
    $stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    $stmt->execute();
    $resulta = $stmt->fetch();
    $enc_pass= $resulta['password'];
    
    $auth = password_verify($password, $enc_pass);

    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    // $response['err']=$enc_pass;
    // $response['error']   = $auth;
    // echo json_encode($response);
    if($auth==1){
    $sql2 = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 
 JOIN `config_program` CM ON CM.programId=UM.merchantId

	WHERE U.`userId` =:usernos
            
								LIMIT 1";
    
    
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":usernos", $userno, PDO::PARAM_STR);
       
        //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $programDB = $result['programDb'];
        
        if ($result) {
            
            
            if ($programDB) {
                $response['error']=false;
                $response['id']         = $result['sn'];
                $response['email']      = $result['email'];
                $response['default']    = $result['default'];
                $response['programDb'] = $result['programDb'];
                $response['serialNo']   = $result['serialNo'];
                 $response['mobilenetwork']   = $result['mobilenetwork'];
                 $response['message'] = 'login successful';
            } else {
                $response['error']   = true;
                $response['message'] = "wrong user id or password";
            }
            
        } else {
            $response['error']   = true;
            $response['message'] = "wrong user id or password";
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
  } else {
    $response['error']   = true;
    $response['message'] = "wrong user id or password";
    
}
echo json_encode($response);
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});





//forgot password


$app->post('/agent/forgotpassemail', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
   // $userid   = $request->userid; 	
//$userid='08051125927';
   // $email    = $_POST['email'];
     $email = $app->request()->params('email');
     
    if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
    // $response['error']   = $userid;
    //     $response['message'] = "User id does not exist in our records";
    //     echo json_encode($response);
        
        
        
     //$userid='09023674562';
     //$email='oluodebiyi@gmail.com';
    // if (!isEmailExist($email)) {
    //     $response['error']   = true;
    //     $response['message'] = "Email does not exist in our records";
    //     echo json_encode($response);
    //     return;
    // }
    // if (!isPhoneExist($userid)) {
    //     $response['error']   = true;
    //     $response['message'] = "User id does not exist in our records";
    //     echo json_encode($response);
    //     return;
    // }
    
    //$randompwd=random();
    $rando = random();
     
    
    
   
    try { 
         $db2   = getConnection();
   // $randompwd = md5($rando);
    $randompwd    = password_hash($rando,PASSWORD_BCRYPT);
   // $userid="051125927";
    
  
   
     $sqlsa1 = "SELECT  `firstname`,  `lastname`, `email`,`agentId` FROM `config_agent` WHERE email='$email'";
       
        $stmtb1 = $db2->prepare($sqlsa1);  
       // $stmtb1->bindParam("custid", $userid);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $email= $resultsa1['email'];
                 $phone= $resultsa1['agentId'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                //$response['errors']   = $email;
                //$response['errors1']   = $userid;
 $from    = "noreply@moloyal.com";
                $to      = $email;
               $msg1      = 'We received a forgot password request for your MoLoyal account.  Your new temporary token is ' . $rando . ' <br>kindly use to reset to a new password. <br>If you did not request a password assistance, you can let us know here:
support@moloyal.com.
 ';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                   
                
    
    $subject   = "MoLoyal Forgot Password";
   
        $type = "Moloyal forgot password";
         $mi=sendEmail($from, $to, $msg, $subject, $type);
         $kk=$mi;
         
          $smsmsg     = 'Your forgot login details request is received. Your new temporary token is. \n'.$rando.'\nPlease use to login';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
        // $response['error']   = $mi;
                //$response['message'] = "A temporary password has been sent to your email";
       // if ($kk==1) {
        
           
            // $sql2 = "Update config_agent SET `password`=:rand, `default`=:def WHERE `email`=:userid ";
            // $stmt2 = $db2->prepare($sql2);
            
            // $stmt2->bindParam(":userid", $email, PDO::PARAM_STR);
            // // $stmt2->bindParam(":email", $email, PDO::PARAM_STR);
            // $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            // $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
           
            
            
            // $errorInfos = $stmt2->errorInfo();
            // if (isset($errorInfos[2])) {
            //     $response['error']   = true;
            //     $response['message'] = $errorInfos[2];
            //     echo json_encode($response);
            // }
           if ($kk==1) {
                $response['error']   = false;
                $response['message'] = "A temporary password has been sent to your email and phone number";
                 $response['code'] = $rando;
                 $response['email'] = $email;
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error sending  the email";
                
                
                
            }
            //$response= $stmt2->fetch();
           
       
         echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//forgot password Phone



$app->post('/agent/forgotpassphone', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
   // $userid   = $_POST['phone']; 	
 $userid = $app->request()->params('phone');
     
    if($userid==null || $userid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$userid    = $request->phone;
	if($userid==null || $userid==''){
		$response['error']   = true;
        $response['message'] = "phone no is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
    
    // $response['error']   = $userid;
    //     $response['message'] = "User id does not exist in our records";
    //     echo json_encode($response);
        
        
        
     //$userid='09023674562';
     //$email='oluodebiyi@gmail.com';
    // if (!isEmailExist($email)) {
    //     $response['error']   = true;
    //     $response['message'] = "Email does not exist in our records";
    //     echo json_encode($response);
    //     return;
    // }
    if (!isAgentPhoneExist($userid)) {
        $response['error']   = true;
        $response['message'] = "phone number does not exist in our records";
        echo json_encode($response);
        return;
    }
    
    //$randompwd=random();
    $rando = random();
     
    
    
   
    try { 
         $db2   = getConnection();
    //$randompwd = md5($rando);
     $randompwd    = password_hash($rando,PASSWORD_BCRYPT);
   // $userid="051125927";
    
  
   
     $sqlsa1 = "SELECT  `firstname`,  `lastname`, `email` FROM `config_agent` WHERE agentId='$userid'";
       
        $stmtb1 = $db2->prepare($sqlsa1);  
       // $stmtb1->bindParam("custid", $userid);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $email= $resultsa1['email'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                //$response['errors']   = $email;
                //$response['errors1']   = $userid;
 $from    = "noreply@moloyal.com";
                $to      = $email;
               $msg1      = 'We received a password reset request for your MoLoyal account.  Your new temporary token is ' . $rando . ' <br>kindly use to reset to a new password. <br>If you did not request a password assistance, you can let us know here:
support@moloyal.com.
<br>

 ';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: left;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                   
                
    
    $subject   = "MoLoyal Forgot Password";
   
        $type = "MoLoyal forgot password";
         $mi=sendEmail($from, $to, $msg, $subject, $type);
         $kk=$mi;
         $phone=$userid;
          $smsmsg     = 'Your forgot login details request is received. Your new temporary token is \n '.$rando.'\nPlease use to login';
                 
                 //$whatsappchk=sendWhatsApp($phone,$smsmsg);
               $smscheck=sendSMS($phone,$smsmsg);
        // $response['error']   = $mi;
                //$response['message'] = "A temporary password has been sent to your email";
        //if ($kk==1) {
           
            // $sql2 = "Update config_agent SET `password`=:rand, `default`=:def WHERE `agentId`=:userid ";
            // $stmt2 = $db2->prepare($sql2);
            
            // $stmt2->bindParam(":userid", $userid, PDO::PARAM_STR);
            // // $stmt2->bindParam(":email", $email, PDO::PARAM_STR);
            // $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            // $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
           
            
            
            // $errorInfos = $stmt2->errorInfo();
            // if (isset($errorInfos[2])) {
            //     $response['error']   = true;
            //     $response['message'] = $errorInfos[2];
            //     echo json_encode($response);
            // }
            if ($kk==1) {
                $response['error']   = false;
                $response['message'] = "A temporary password has been sent to your email and phone number";
                 $response['code'] = $rando;
                  $response['phone'] = $phone;
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error sending  the email";
                
                
                
            }
            //$response= $stmt2->fetch();
           
        
         echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});




//Agent Reset password


$app->post('/agent/resetpass', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    //$userid   = $request->userid;
    // $email    = $_POST['email'];
    // $password = $_POST['newpassword'];
    
    
    $email = $app->request()->params('email');
     
    if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	$password = $app->request()->params('newpassword');
     
    if($password==null || $password==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$password    = $request->newpassword;
	if($password==null || $password==''){
		$response['error']   = true;
        $response['message'] = "password is required";
		
        echo json_encode($response);
		
		return;
	}
	}
    //  $email    = 'oluodebiyi@gmail.com';
    //  $password='West@123@';
    // if (!isAgentEmailExist($email)) {
    //     $response['error']   = true;
    //     $response['message'] = "email does not exist in our records";
    //     echo json_encode($response);
    //     return;
    // }
    if ($email=='' || $email==null) {
                 //$response['new']   = $newpwd;
                $response['error']   = false;
                $response['message'] = "email or phone not supplied";
                 echo json_encode($response);
                return;
    }   
    $dbs=getConnection();
    
    $newpwd = password_hash($password,PASSWORD_BCRYPT);
    $def       = '0';
    $from      = "noreply@moloyal.com";
    $to        = $email;
    
     $sqlsa1 = "SELECT `sn`, `pin`, `agentId`, `img`, `programId`, `merchantId`, `firstname`, `lastname`, `email` FROM config_agent WHERE email=:email or agentId=:email";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam(":email", $email);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                 $agentId= $resultsa1['agentId'];
                $emails= $resultsa1['email'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
                
 $from    = "noreply@moloyal.com";
                $to      = $emails;
                $msg1       = 'You have requested for a password reset on Moloyal. <br> If you did not initiate this request, Please contact the admin';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                   
                
   
    $subject   = "MoLoyal Password Reset";
    
    $sql2 = "Update config_agent SET `password`=:newpwd WHERE `agentId`=:agentId";
    try {
        $type = "Moloyal reset password";
        if (isAgentEmailExist($emails)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } 
            
            $stmt2 = $dbs->prepare($sql2);
            $stmt2->bindParam(":newpwd", $newpwd, PDO::PARAM_STR);
            
           
            
            $stmt2->bindParam(":agentId", $agentId, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
            $res=$stmt2->execute();
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($res) {
                 //$response['new']   = $newpwd;
                $response['error']   = false;
                $response['message'] = "Your password reset is successful";
                
                
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});



//Agent Change password


$app->post('/agent/changepass', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    //$userid   = $request->userid;
   
    
     $phoneno = $app->request()->params('agentid');
if($phoneno==null || $phoneno==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$phoneno    = $request->agentid;
	}
	
	$oldpassword = $app->request()->params('oldpassword');
if($oldpassword==null || $oldpassword==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$oldpassword    = $request->oldpassword;
	}
	
	$newpassword = $app->request()->params('newpassword');
if($newpassword==null || $newpassword==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$newpassword    = $request->newpassword;
	}
	
    //  $phoneno    ='09096456814';
    //  $oldpassword = 'P@ss1234';
    // $newpassword = 'P@ss12345';
    
    
   if (!isAgentPhoneExist($phoneno)) {
        $response['error']   = true;
        $response['message'] = "Agent ID does not exist in our records";
        echo json_encode($response);
        return;
    }
     try {
         
         $dbs=getConnection();
     $sqlsa1 = "SELECT `sn`, `pin`, `agentId`, `img`, `programId`, `merchantId`, `firstname`, `lastname`, `email`,`password` FROM config_agent WHERE agentId=:agentid";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam(":agentid", $phoneno);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                 $agentId= $resultsa1['agentId'];
                $email= $resultsa1['email'];
                $name= $resultsa1['firstname'].' '.$resultsa1['lastname'];
     $enc_pass= $resultsa1['password'];
    if($enc_pass==''){
       $response['error']   = true;
            $response['message'] = 'agent has no password in our record';
             echo json_encode($response); 
    }else{
    $auth = password_verify($oldpassword, $enc_pass);
if($auth=='0'){
    $response['error']   = true;
            $response['message'] = 'wrong old password supplied';
             echo json_encode($response); 
    
}else{
    
    

    
    $newpwd = password_hash($newpassword,PASSWORD_BCRYPT);
    $def       = '0';
   
    
                
  $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1       = 'You have initaited  a change of password on MoLoyal. <br> If you did not initiate this request, Please contact the admin';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear ' . $name . ',</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                   
                
   
    $subject   = "MoLoyal Password Changed";
    
    $sql2 = "Update config_agent SET `password`=:newpwd WHERE `agentId`=:agentId";
   
        $type = "MoLoyal change password";
        if (isAgentEmailExist($email)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } 
            $db2   = getConnection();
            $stmt2 = $db2->prepare($sql2);
            $stmt2->bindParam(":newpwd", $newpwd, PDO::PARAM_STR);
            
           
            
            $stmt2->bindParam(":agentId", $agentId, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
           $jj= $stmt2->execute();
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($jj) {
                $response['error']   = false;
                $response['message'] ="password changed successful";
               // $response['message2'] = $email;
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
      }
      }
    }
    

    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});




//User Reset password


$app->post('/users/resetpass', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    // $userid   =  $_POST['userid'];
    // $email    =  $_POST['email'];
    // $password =  $_POST['password'];
     $email = $app->request()->params('userid');
     
     
     if($userid==null || $userid==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$userid    = $request->userid;
	if($userid==null || $userid==''){
		$response['error']   = true;
        $response['message'] = "userid is required";
		
        echo json_encode($response);
		
		return;
	}
	}
     
     $email = $app->request()->params('email');
    if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	$password = $app->request()->params('password');
     
    if($password==null || $password==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$password    = $request->password;
	if($password==null || $password==''){
		$response['error']   = true;
        $response['message'] = "password is required";
		
        echo json_encode($response);
		
		return;
	}
	}
    
    if (!isPhoneExist($userid)) {
        $response['error']   = true;
        $response['message'] = "User id does not exist in our records";
        echo json_encode($response);
        return;
    }
    
    
    
    $randompwd = password_hash($request->password,PASSWORD_BCRYPT);
    $def       = '0';
    $from      = "noreply@moloyal.com";
    $to        = $email;
    
     $sqlsa1 = "SELECT `sn`, `userId`, `BVN_num`, `firstName`, `mname`, `lastName`, `email`, `mobilenetwork`, `lastResetDate`, `pic`, `locked` FROM `config_user` WHERE userId=:custid";
       
        $stmtb1 = $dbs->prepare($sqlsa1);  
        $stmtb1->bindParam("custid", $userid);
        
                $stmtb1->execute();
                $resultsa1 = $stmtb1->fetch();
                $email= $resultsa1['email'];
                $name= $resultsa1['firstName'].' '.$resultsa1['lastName'];
                
 $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg1       = 'You have requested for a password reset on Moloyal. <br> If you did not initiate this request, Please contact the admin';
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear, ' . $name . '</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                   
                
   
    $subject   = "MoLoyal Password Reset";
    
    $sql2 = "Update config_user SET `password`=:rand, `default`=:def WHERE `userId`=:userid";
    try {
        $type = "Moloyal reset password";
        if (isEmailExist($email)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } {
            $db2   = getConnection();
            $stmt2 = $db2->prepare($sql2);
            $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
            $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            $stmt2->bindParam(":userid", $userid, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
            
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($stmt2->execute()) {
                $response['error']   = false;
                $response['message'] = "Your password reset is successful";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
        }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//agent update profile


$app->post('/agent/update', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $lastResetDate  = date('Y-m-d H:i:s');
    // $email       =  $_POST['email'];
    // $phone      =  $_POST['phone'];
    // $firstname    =  $_POST['firstname'];
    // $lastname     =  $_POST['lastname'];
    // $accountNo    =  $_POST['accountNo'];
    // $city    =  $_POST['city'];
    // $state    =  $_POST['state'];
    // $accountName    =  $_POST['accountName'];
    // $dateOfBirth    =  $_POST['birthdate'];
    // $gender    =  $_POST['gender'];
    // $bank   =  $_POST['bank'];
    //  $bankcode   =  $_POST['bankcode'];
    // $bvn    =  $_POST['bvn'];
    
    
    
    $firstname = $app->request()->params('firstname');
	  $phone = $app->request()->params('phone');
	   $lastname = $app->request()->params('lastname');
	    $email = $app->request()->params('email');
	    $accountNo = $app->request()->params('accountNo');
	    $city = $app->request()->params('city');
	    $state = $app->request()->params('state');
	    $accountName = $app->request()->params('accountName');
	    $dateOfBirth = $app->request()->params('birthdate');
	    
	    $gender = $app->request()->params('gender');
	    $bank = $app->request()->params('bank');
	    $bankcode = $app->request()->params('bankcode');
	    $bvn = $app->request()->params('bvn');
     
    if($firstname==null || $firstname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$firstname    = $request->firstname;
	if($firstname==null || $firstname==''){
		$response['error']   = true;
        $response['message'] = "firstname is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($phone==null || $phone==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$phone   = $request->phone;
	if($phone==null || $phone==''){
		$response['error']   = true;
        $response['message'] = "phone number is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($lastname==null || $lastname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$lastname    = $request->lastname;
	if($lastname==null || $lastname==''){
		$response['error']   = true;
        $response['message'] = "lastname is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	if($accountNo==null || $accountNo==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountNo    = $request->accountNo;
	if($accountNo==null || $accountNo==''){
		$response['error']   = true;
        $response['message'] = "account number is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
	
	if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	if($email==null || $email==''){
		$response['error']   = true;
        $response['message'] = "email is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
    if($city==null || $city==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$city    = $request->city;
	if($city==null || $city==''){
		$response['error']   = true;
        $response['message'] = "city is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	

    if($state==null || $state==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$state    = $request->state;
	if($state==null || $state==''){
		$response['error']   = true;
        $response['message'] = "state is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	

    if($accountName==null || $accountName==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$accountName    = $request->accountName;
	if($accountName==null || $accountName==''){
		$response['error']   = true;
        $response['message'] = "account name is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	

    if($dateOfBirth==null || $dateOfBirth==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$dateOfBirth    = $request->birthdate;
	if($dateOfBirth==null || $dateOfBirth==''){
		$response['error']   = true;
        $response['message'] = "date of birth is required";
		
        echo json_encode($response);
		
		return;
	}
	}
	
	
    if($gender==null || $gender==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$gender    = $request->gender;
	if($gender==null || $gender==''){
		$response['error']   = true;
        $response['message'] = "gender is required";
		
        echo json_encode($response);
		
		return;
	}
	}




    if($bank==null || $bank==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$bank    = $request->bank;
	if($bank==null || $bank==''){
		$response['error']   = true;
        $response['message'] = "bank is required";
		
        echo json_encode($response);
		
		return;
	}
	}



    if($bankcode==null || $bankcode==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$bankcode    = $request->bankcode;
	if($bankcode==null || $bankcode==''){
		$response['error']   = true;
        $response['message'] = "bankcode is required";
		
        echo json_encode($response);
		
		return;
	}
	}


    if($bvn==null || $bvn==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$bvn    = $request->bvn;
	if($bvn==null || $bvn==''){
		$response['error']   = true;
        $response['message'] = "bvn is required";
		
        echo json_encode($response);
		
		return;
	}
	}
    
    
    
    $updateUserquery = "UPDATE `config_agent` SET `firstname`='$firstname',`lastname`='$lastname',
    `email`='$email',`gender`='$gender',
    `birthdate`='$dateOfBirth',`bvn`='$bvn',`bank`='$bank',`bankcode`='$bankcode',`accountNo`='$accountNo',
    `accountName`='$accountName',`city`='$city',`state`='$state'
    WHERE `agentId` = '$phone' AND `email` = '$email' ";
    // $updateUser =  mysqli_query($con, $updateUserquery);
    
    try {

		if (isAgentEmailExist($email) && isAgentPhoneExist($phone)) {
        $db = getConnection();
        $stmt = $db->prepare($updateUserquery);
        
        
      
        $stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        } else {
            $response['error'] = false;
             $response['message'] = 'agent profile has been updated successfully';
              $response['email'] = $email;      
    $response['phone'] = $phone;      
   $response['firstname'] =  $firstname;   
   $response['lastname'] =  $lastname;    
   $response['accountNo'] =  $accountNo;    
    $response['city'] = $city;    
    $response['state'] = $state;   
    $response['accountName'] = $accountName;    
    $response['dateOfBirth'] = $dateOfBirth;    
   $response['gender'] =  $gender;    
    $response['bank'] = $bank;   
     $response['bankcode'] = $bankcode;  
   $response['bvn'] =  $bvn;   
              echo json_encode($response);
        }
        
    }else{
        $response['error']   = true;
        $response['message'] = "The agent record does not exist";
        echo json_encode($response);
        return;
        
		}
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    
    
});





//GEt about us
$app->get('/agent/aboutus', function()
{
   $response = array();
   
   $dtt= date("d/m/Y");
 $sql = "SELECT `sn`, `title`, `content` FROM `app_content` WHERE title='aboutus' 
          ";
    try {
            $db   = getConnection();
            $stmt = $db->query($sql);
            $stmt->execute();
             // while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $con = $result['content'];
          if($con!=''){
            $response['error']   = false;
        $response['content'] =  $con;
          }else{
                $response['error']   = true;
        $response['content'] = null;
              
          }
            
          
        $db   = null;
                 echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});


//GEt about us
$app->get('/agent/termsandconditions', function()
{
    $response = array();
   
   $dtt= date("d/m/Y");
 $sql = "SELECT `sn`, `title`, `content` FROM `app_content` WHERE title='terms' 
          ";
    try {
            $db   = getConnection();
            $stmt = $db->query($sql);
            $stmt->execute();
             // while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $con = $result['content'];
          if($con!=''){
            $response['error']   = false;
        $response['content'] =  $con;
          }else{
                $response['error']   = true;
        $response['content'] = null;
              
          }
            
          
        $db   = null;
                 echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});


//Get all classifications and Merchants

$app->get('/merchants/all', function()
{
   $response = array();
   
   $dtt= date("d/m/Y");
 $sql = "SELECT  `id`,`category_name`,`publish` FROM `merchant_category` 
          ";
    try {
            $db   = getConnection();
            $stmt = $db->query($sql);
            $stmt->execute();
              while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            $id = $result['id'];
            $res['sn'] = $result['id'];
            $res['category_name'] = $result['category_name'];
            $res['publish'] = $result['publish'];
           // $res['submerchantId'] = $result['submerchantId'];
            // $res['Paystack_Acct'] = $result['Paystack_Acct'];
            // $res['event_id'] = $result['event_id'];
            // $res['title'] = $result['title'];
            // $res['image'] = $result['image'];
            // $res['image2'] = $result['image2'];
            // $res['image3'] = $result['image3'];
            // $res['venue']    = $result['venue'];
            // $res['from_date']     = $result['from_date'];
            //  $res['from_time'] = $result['from_time'];
            // $res['to_date'] = $result['to_date'];
            // $res['to_time']    = $result['to_time'];
            // $res['des']     = $result['des'];
            // $res['status']     = $result['status'];
            
            $sql2= "SELECT   c.merchant_id, m.merchantName as name FROM `merchant_category_mapping` c join config_merchant m On c.merchant_id=m.merchantId where c.`cat_id`=$id ";
             $stmt2 = $db->query($sql2);
            $stmt2->execute();
            $res['subcat'] = $stmt2->fetchAll(PDO::FETCH_OBJ);
            array_push($response, $res);
          }
        $db   = null;
                 echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});

//GEt forms for each button
$app->get('/button/form', function()
{
   $response = array();
   
    $user     = array();
    //$req      = $app->request();
    //$formid       = $req->get('formid'); 
    $formid =1;
   $dtt= date("d/m/Y");
 $sql = "SELECT c.`id`, c.`merchantId`, c.`button_name`, c.`form_id`, m.`name`, m.`type`, m.`required`, m.`title`, m.`selected`, m.`options` FROM `merchant_buttons` c join merchant_forms m On m.form_id='$formid' where m.form_id='$formid'
          ";
    try {
            $db   = getConnection();
            $stmt = $db->query($sql);
            $stmt->execute();
              while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            $form_id = $result['form_id'];
            
            $res['form_id'] = $result['form_id'];
            $res['button_name'] = $result['button_name'];
            $res['merchantId'] = $result['merchantId'];
           $res['name'] = $result['name'];
            $res['type'] = $result['type'];
            $res['required'] = $result['required'];
            $res['title'] = $result['title'];
            $res['title'] = $result['title'];
            $res['selected'] = $result['selected'];
            $res['options'] = $result['options'];
            // $res['venue']    = $result['venue'];
            // $res['from_date']     = $result['from_date'];
            //  $res['from_time'] = $result['from_time'];
            // $res['to_date'] = $result['to_date'];
            // $res['to_time']    = $result['to_time'];
            // $res['des']     = $result['des'];
            // $res['status']     = $result['status'];
            
            // $sql2= "SELECT c.`cat_id`,  c.merchant_id, m.merchantName as name FROM `merchant_category_mapping` c join config_merchant m On c.merchant_id=m.submerchantId where c.`cat_id`=$id ";
            //  $stmt2 = $db->query($sql2);
            // $stmt2->execute();
            // $res['subcat'] = $stmt2->fetchAll(PDO::FETCH_OBJ);
            array_push($response, $res);
          }
        $db   = null;
                 echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});

//Support Email


$app->post('/users/support', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userid   = $_POST['userid'];
    $email    = $_POST['email'];
    $username = $_POST['username'];
    $message  = $_POST['message'];
    $title    = $_POST['title'];
    $phoneno  = $_POST['phoneno'];
     $rando = random();
   if ($email == ""){
        $email = "noreply@moloyal.com"; }
       
    
    
    $from    = $email;
    $to      = "care@moloyal.com";
    $msg2     = "Thank you  for contacting MoLoyal/MoSave Support.
 
This is to acknowledge receipt of your email with subject  ". $title." .<br> We have assigned this reference number ". $rando."  to your request, and you should hear from us within 24 hours.
<br>You can also make use of our self-service options to quickly resolve any of the following complaints:
<br>WhatsApp: +234 818 877 5534";
$msg3= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear, ' . $name . '</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg2 . '

  </p>
                        </td>
                    </tr>';
                    

    $msg1     = "A customer with phone number " . $phoneno . " sent the message below: <br>" . $message;
     
                
                
                
                  $msg= '<tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                <h4 style="color:#000;"> Dear, ' . $name . '</h4>
                            <p style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; color: #000000; text-align: center;">
     
                   
' . $msg1 . '

  </p>
                        </td>
                    </tr>';
                    
                   
    
    $subject = "MoLoyal App Support: " . $title;
    
    
    
    
       
        
       try {
        $type = "Moloyal App support";
        sendEmail($from, $to, $msg3, $subject, $type);
        
       if(sendEmail($from, $to, $msg, $subject, $type)){
        
        
        $response['error']   = false;
        $response['message'] = "Your message has been sent. Thanks for contacting us.";
       }else{
           
            $response['error']   = true;
        $response['message'] = "Your message not sent. ";
       }
        
        
        
        
        
        echo json_encode($response);
        
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

//get Subwallet Data


$app->post('/user/subwallet', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $_POST['dbname'];
    
   
    $serialnum = $_POST['serialnum'];
    
    $sql1 = "SELECT * FROM subwallet WHERE  `serialNo` =:serialnum";
    
    try {
        $db1   = getDynamicConnection($dbname);
    $stmt1 = $db1->prepare($sql1);
    $stmt1->bindParam(":serialnum", $serialnum, PDO::PARAM_STR);
    
    $stmt1->execute();
    
    $resulta    = $stmt1->fetch();
    $accruedairtime = $resulta['accruedairtime'];
        
        $db = null;
        
        echo $accruedairtime;
        
        
        
    }
    catch (PDOException $e) {
        echo '{"error":' . $e->getMessage() . '}}';
    }
    
});


//get Voucher Setup Data


$app->post('/voucher/getVoucherdata', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    //$dbname = $_POST['dbname'];
    
    $id        = $_POST['id'];
    $serialnum = $_POST['serialnum'];
    
    $dbname = 'moloyalc_master';
    
    // $id        = $_POST['id'];
    // $serialnum = '201500000300';
    
    $sql1 = "SELECT *
FROM config_user_merchant_info 
WHERE  `serialNo` =:serialnum";
    
    
    $db1   = getConnection();
    $stmt1 = $db1->prepare($sql1);
    $stmt1->bindParam(":serialnum", $serialnum, PDO::PARAM_STR);
    
    $stmt1->execute();
    
    $resulta    = $stmt1->fetch();
    $merchantId = $resulta['merchantId'];
    $tierLevel  = $resulta['tierLevel'];
    $userId     = $resulta['userId'];
    
    
    $sql = "SELECT  vou.merchantId, vou.submerchantId, vou.tierlevel, vou.percentageDiscount, vou.NoOfTimesUsed, vou.maxTimesUsage, vou.useFromDate, vou.useToDate,
	vou.vouchertype, vou.voucherFor, vou.createdDate, vou.expiryDate, vou.status,vou.activationDate, csub.merchantName,csub.merchantimage, ts.tierName
FROM voucher vou JOIN $dbname.config_merchant csub ON csub.merchantId = vou.submerchantId 
JOIN $dbname.tier_setup ts ON ts.tierLevel='$tierLevel'
WHERE  vou.tierlevel =  '$tierLevel'  AND  vou.merchantId = '$merchantId' AND date(vou.expiryDate) > CURRENT_DATE";
    
    
    try {
        //$db = getDynamicConnection($dbname);
        $db   = getConnection();
        $stmt = $db->query($sql);
        $stmt->execute();
        //$result = $stmt->fetchAll(PDO::FETCH_OBJ);
     while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
        //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            $res['NoOfTimesUsed'] = $result['NoOfTimesUsed'];
            
            $res['activationDate'] = $result['activationDate'];
            $res['createdDate']    = $result['createdDate'];
            $res['expiryDate']     = $result['expiryDate'];
            
            
            
            
            /*
            elseif($vouchertype==2 && $NoOfTimesUsed>=1)
            {
            $message="Your one time voucher has been used";
            $validUser=9;
            }
            elseif($vouchertype==3 && $NoOfTimesUsed>=$maxTimesUsage)
            {
            $message = "Maximum voucher usage exceeded";
            $validUser=9;
            }
            elseif($vouchertype==4 && (date("Y-m-d")<$useFromDate || date("Y-m-d")>$useToDate))
            {
            $message="Voucher can no longer be used on this date";
            $validUser=9;
            }
            */
            
            
            if (date("Y-m-d H:i:s") > $res['expiryDate']) {
                $res['expiry'] = "1";
                
                
            } else {
                $res['expiry'] = "0";
            }
            $res['status']             = $result['status'];
            $res['maxTimesUsage']      = $result['maxTimesUsage'];
            $res['merchantId']         = $result['merchantId'];
            $res['percentageDiscount'] = $result['percentageDiscount'];
            $res['submerchantId']      = $result['submerchantId'];
            $res['submerchantName']    = $result['submerchantName'];
            $res['submerchantimage']   = $result['submerchantimage'];
            $res['tierName']           = $result['tierName'];
            $res['tierlevel']          = $result['tierlevel'];
            $res['submerchantimage']   = $result['submerchantimage'];
            $res['tierName']           = $result['tierName'];
            $res['useToDate']          = $result['useToDate'];
            $res['useFromDate']        = $result['useFromDate'];
            $res['voucherFor']         = $result['voucherFor'];
            $res['vouchertype']        = $result['vouchertype'];
            $res['status']             = $result['status'];
            array_push($response, $res);
            
     }
        
        
        
        $db = null;
        
        echo json_encode($response);
        
        
        
        
        
        
        
        
        
    }
    catch (PDOException $e) {
        echo '{"error":' . $e->getMessage() . '}}';
    }
    
});

//get my Voucher record
$app->post('/voucher/getMyVrecord', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $_POST['dbname'];
    
    $id        = $_POST['id'];
    $serialnum = $_POST['serialnum'];
    //$id = $req->get('id');
    
    
    $sql = "SELECT  `submerchantId`, `serialno`, `tierlevel`, `NoOfTimesUsed`, `activationDate`, `status` FROM `voucher_records`
		WHERE `serialno`='$serialnum'";
    
    
    try {
        $db     = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"voucher": ' . json_encode($result) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});

//get all event tickets
$app->get('/tickets/all', function()
{
   $response = array();
     
   $dtt= date("d/m/Y");
 $sql = "SELECT `sn`, `merchantName`, `merchantId`, `submerchantId`, `Paystack_Acct`, `title`, `event_id`, `image`, `image2`, `image3`, `venue`, `from_date`, `from_time`, `to_date`, `to_time`, `des`, `date`, `time`, `ip`, `status` FROM `config_event_ticket` 
          ";
    try {
            $db   = getConnection();
            $stmt = $db->query($sql);
            $stmt->execute();
              while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            $id = $result['sn'];
            $res['sn'] = $result['sn'];
            $res['merchantName'] = $result['merchantName'];
            $res['merchantId'] = $result['merchantId'];
            $res['submerchantId'] = $result['submerchantId'];
            $res['Paystack_Acct'] = $result['Paystack_Acct'];
            $res['event_id'] = $result['event_id'];
            $res['title'] = $result['title'];
            $res['image'] = $result['image'];
            $res['image2'] = $result['image2'];
            $res['image3'] = $result['image3'];
            $res['venue']    = $result['venue'];
            $res['from_date']     = $result['from_date'];
             $res['from_time'] = $result['from_time'];
            $res['to_date'] = $result['to_date'];
            $res['to_time']    = $result['to_time'];
            $res['des']     = $result['des'];
            $res['status']     = $result['status'];
            
            $sql2= "SELECT `id`, `event_id`, `name`, `price`, `quantity`, `cat_Image`,  `currency` FROM `event_category` WHERE  event_id=$id order by id ASC";
             $stmt2 = $db->query($sql2);
            $stmt2->execute();
            $res['cat'] = $stmt2->fetchAll(PDO::FETCH_OBJ);
            array_push($response, $res);
          }
        $db   = null;
                 echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});

//get all faq
$app->get('/faq/all', function()
{
     $title = array();
    $content     = array();
    $response     = array();
   
         $res['title']= ["Coming Soon "];
            
            $res['content']=["Coming Soon"];
    array_push($response, $res);
    try {
       /* $db   = getConnection();
        $stmt = $db->query($sql);
        $jobs = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db   = null; */
         echo json_encode($response);
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});


//get all transaction
$app->get('/transactions/all', function()
{
    $sql = "SELECT jp.id,jp.job_title,jp.experience,jp.location,jp.skill_required,
          jp.job_description,DATE_FORMAT(jp.date_posted,'%M %d,  %Y') AS date_posted,
          DATE_FORMAT(jp.expiry_date,'%M %d,  %Y') AS expiry_date,
          sec.name,emp.company_name
          FROM job_postings jp JOIN sectors sec ON sec.id=jp.sector_id
          JOIN employers emp ON emp.id=jp.emp_id
          WHERE jp.status=1";
    try {
        $db   = getConnection();
        $stmt = $db->query($sql);
        $jobs = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db   = null;
        echo '{"jobs": ' . json_encode($jobs) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});




//get my transaction
$app->post('/transact/getMyTransaction', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $_POST['dbname'];
    
    $id        = $_POST['id'];
    $serialnum = $_POST['serialnum'];
    //$id = $req->get('id');
    
    
    $sql = "SELECT `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `transType`, `points`, `discount`, `priceTag`, `comment`, `status`, `createdDate`, `transDate` FROM `transaction`
				WHERE `serialNo`='$serialnum' order by transDate desc limit 50";
    
    
    try {
        $db     = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"transactions": ' . json_encode($result) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});


//banners

//get banners

$app->get('/home/banners', function() use ($app)
{
    $response = array();
    
    
   
    
    $sql = "SELECT  `hoe`, `spix`, `bpix`, `body`, `desc`, `web`, `date`, `time`, `ip`, `admin` FROM `ban`";
    
    
    try {
        $db     = getConnection();
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        { echo json_encode($response); };
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});



//get my Wallet Balance
$app->post('/wallet/getMybalance', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $_POST['dbname'];
    
    $id        = $_POST['id'];
    $serialnum = $_POST['serialnum'];
    
    
    $sql = "SELECT  wa.agentId, wa.merchantId, wa.submerchantId, wa.serialNo, wa.accruedpoints, wa.tierpoint, wa.redeemableamt, wa.tierLevel, wa.comment, csub.merchantName, csub.merchantimage  FROM $dbname.wallet wa JOIN moloyalc_master.config_merchant csub ON csub.submerchantId = wa.submerchantId   WHERE wa.serialNo='$serialnum' ";
    //$sql3 = "SELECT  wa.agentId, wa.merchantId, wa.submerchantId, wa.serialNo, wa.accruedpoints, wa.tierpoint, wa.redeemableamt, wa.tierLevel, wa.comment, csub.submerchantName, csub.submerchantimage  FROM $dbname.wallet wa JOIN moloyalc_master.config_submerchant csub ON csub.submerchantId = wa.submerchantId   WHERE wa.serialNo='$serialnum' or wa.serialNo=''  ";
        //$sql2 = "SELECT  wa.agentId, wa.merchantId, wa.submerchantId, wa.serialNo, wa.accruedpoints, wa.tierpoint, wa.redeemableamt, wa.tierLevel, wa.comment, csub.submerchantName, csub.submerchantimage  FROM $dbname.wallet wa JOIN moloyalc_master.config_submerchant csub ON csub.submerchantId = wa.submerchantId   WHERE wa.submerchantId='201506' ";

    /*SELECT jp.id,jp.job_title,jp.experience,jp.location,jp.skill_required,
    jp.job_description,DATE_FORMAT(jp.date_posted,'%M %d,  %Y') AS date_posted,
    DATE_FORMAT(jp.expiry_date,'%M %d,  %Y') AS expiry_date,
    sec.name,emp.company_name
    FROM job_postings jp JOIN sectors sec ON sec.id=jp.sector_id
    JOIN employers emp ON emp.id=jp.emp_id
    WHERE jp.status=1";*/
    
    // $sql = "SELECT wa.agentId, wa.merchantId, wa.submerchantId,  wa.serialNo,  wa.accruedpoints,  wa.tierpoint,  wa.redeemableamt,  //wa.tierLevel FROM wallet  WHERE `serialNo`='$serialnum'";
    
    
    try {
        $db   = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        
      
       
          
           $stmt = $db->query($sql);
        
        
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"wallet": ' . json_encode($result) . '}';
        
        
        //$stmt->execute();
        // $result = $stmt->fetch();
        //if($result){
        //$bal['id']=$result['sn'];
        // $bal['wBalance']=intval($result['wBalance']);
        
        // $response['error']=false;
        // $response['bal'] = $bal;
        
        // }else{
        //$response['error']=true;
        //$response['error']="No Points found";
        //}
        //$db = null;
        //echo json_encode($response);
        
        
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = getMessage();
    }
    
});






$app->post('/user/update', function() use ($app)
{
    
  
	  

	    
	    
	   
	   
	   
	   // $dateOfBirth = $app->request()->params('dateOfBirth');
	    
	   
	    
	   
	   
	    
      
   $firstname = $app->request()->params('firstname');
if($firstname==null || $firstname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$firstname    = $request->firstname;
	}
	
	$lastname = $app->request()->params('lastname');
if($lastname==null || $lastname==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$lastname    = $request->lastname;
	}
    
    
    	
	$id = $app->request()->params('id');
if($id==null || $id==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
	$id    = $request->id;
	}
    
    

//     if($firstname==null || $firstname==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$firstname    = $request->firstname;
// 	if($firstname==null || $firstname==''){
// 		$response['error']   = true;
//         $response['message'] = "firstname is required";
		
//         echo json_encode($response);
		
// 		return;
// 	}
// 	}
	
	
	
// 	if($lastname==null || $lastname==''){
// 		$postdata   = file_get_contents("php://input");
//     $request    = json_decode($postdata);
// 		$lastname    = $request->lastname;
// 	if($lastname==null || $lastname==''){
// 		$response['error']   = true;
//         $response['message'] = "lastname is required";
		
//         echo json_encode($response);
		
// 		return;
// 	}
// 	}
	

	$userId = $app->request()->params('phone');
	if($userId==null || $userId==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$userId   = $request->phone;;
	
	}
	$email = $app->request()->params('email');
	if($email==null || $email==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$email    = $request->email;
	
	}
	 $city = $app->request()->params('city');
    if($city==null || $city==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$city    = $request->city;
	
	}
	
 $state = $app->request()->params('state');
    if($state==null || $state==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$state    = $request->state;
	
	}
	
	$country = $app->request()->params('country');
	if($country==null || $country==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$country    = $request->country;
	
	}
	

	
$dateOfBirth = $app->request()->params('dateOfBirth');
    if($dateOfBirth==null || $dateOfBirth==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$dateOfBirth    = $request->dateOfBirth;
// 	if($dateOfBirth==null || $dateOfBirth==''){
// 		$response['error']   = true;
//         $response['message'] = "date of birth is required";
		
//         echo json_encode($response);
		
// 		return;
// 	}
	}
	
	 $gender = $app->request()->params('gender');
    if($gender==null || $gender==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$gender    = $request->gender;
	
	}


 $street1 = $app->request()->params('street1');

    if($street1==null || $street1==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$street1    = $request->street1;
	
	}
	$bvn = $app->request()->params('bvn');  
	 if($bvn==null || $bvn==''){
		$postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
		$bvn    = $request->bvn;
	
	}



    //  $postdata = file_get_contents("php://input");
    // $request  = json_decode($postdata);
    // $response = array();
    // $email = $_POST['email'];
    // $bvn = $_POST['bvn'];
    // $firstname = $_POST['firstname'];
    // $lastname  = $_POST['lastname'];
    //  $city  = $_POST['city'];
    // $state = $_POST['state'];
    // $userId    = $_POST['UserId'];
    // $street1   = $_POST['street1'];
    // $id        = $_POST['id'];
    //  $phone        = $_POST['phone'];
 
    //  $gender        = $_POST['gender'];
    //   $dateOfBirth        = $_POST['dateOfBirth'];
    
     $sql3 = "SELECT sn,street1, city, `state`, userId, firstName, lastName, email, mobilenetwork FROM config_user WHERE sn=$id";
    
    
        
    
    $sql = "UPDATE config_user SET `firstName`=:firstname, lastName=:lastname,email=:email,BVN_num=:bvn,
 userId=:userid,street1=:address,city=:city,state=:state,country=:country,gender=:gender,dateOfBirth=:dateOfBirth WHERE sn=:id";
    
    try {
        $db   = getConnection();
        $stmt = $db->prepare($sql);
        
        $stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
         
        $stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
         $stmt->bindParam(":gender", $gender, PDO::PARAM_STR);
        //$stmt->bindParam(":othername", $othername,PDO::PARAM_STR);
        $stmt->bindParam(":userid", $userId, PDO::PARAM_STR);
        $stmt->bindParam(":address", $street1, PDO::PARAM_STR);
        $stmt->bindParam(":city", $city, PDO::PARAM_STR);
        $stmt->bindParam(":state", $state, PDO::PARAM_STR);
        $stmt->bindParam(":dateOfBirth", $dateOfBirth,PDO::PARAM_STR);
        $stmt->bindParam(":country", $country, PDO::PARAM_STR);
        
         $stmt->bindParam(":bvn", $bvn, PDO::PARAM_STR);
          $stmt->bindParam(":id", $id, PDO::PARAM_STR);
        
        if($id==''){
            
             $response['error'] = true;
             $response['message'] = 'id not passed';
        }else{
            
        
        $stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        } else {
            $response['error'] = false;
             $response['message'] = 'profile has been updated';
        }
        
        $stmt3 = $db->query($sql3);
        $stmt3->execute();
        $result = $stmt3->fetch();
        if ($result) {
            $user['id']        = $result['sn'];
            $user['firstname'] = $result['firstName'];
            $user['lastname']  = $result['lastName'];
            $user['email']     = $result['email'];
            $user['mobilenetwork']     = $result['mobilenetwork'];
            $user['city']      = $result['city'];
            $user['state']     = $result['state'];
            $user['userId']    = $result['userId'];
            $user['street1']   = $result['street1'];
            $response['error'] = false;
            $response['user']  = $user;
            
        } else {
            $response['error'] = true;
            $response['message'] = "No profile found";
        }
        
        }
        // if($stmt->rowCount()){
        //   $response['error']=false;
        // }else{
        //   $response['error']=true;
        //   $response['message']="There was an error contacting the server";
        // }
        echo json_encode($response);
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});

$app->get('/all/savings_plan/:custid', function($custid) use ($app)
{
    $response = array();
    $res     = array();
    // $req      = $app->request();
    // $id       = $req->get('id');
    
    $sql ="SELECT sn, plan_name, plan_amount,days
FROM savings_plan
WHERE sn NOT IN
    (SELECT plan_id 
     FROM mosave_customer_savings_plan WHERE cust_id=:cid)";
    try {
        $db   = getConnection();
        $stmt = $db->prepare($sql);
         $stmt->bindParam(":cid", $custid, PDO::PARAM_STR);
        $stmt->execute();
        //$result = $stmt->fetch();
        
         while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $res['sn'] = $result['sn'];
            $res['amount'] = $result['plan_amount'];
            $res['plan_name'] = $result['plan_name'];
             $res['days'] = $result['days'];
            
               array_push($response, $res);
         }
         //$res = $stmt->fetchAll();
        
       
        $db = null;
        echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = $e->getMessage();
         echo json_encode($response);
    }
    
});


$app->get('/all/customers', function() use ($app)
{
    $response = array();
    $user     = array();
    // $req      = $app->request();
    // $id       = $req->get('id');
    
    $sql = "SELECT C.sn,C.street1,C.img as image, C.city, C.BVN_num, C.state, C.gender,C.country, C.userId, C.firstName, C.lastName,C.dateOfBirth, C.email, I.account_num, I.account_typeId,I.customerId FROM config_user C join config_customer_account_info I ON C.sn=I.customerId";
    
    try {
        $db   = getConnection();
        $stmt = $db->query($sql);
        $stmt->execute();
        //$result = $stmt->fetch();
         $response = $stmt->fetchAll();
        // if ($result) {
        //     $user['id']        = $result['sn'];
        //     $user['firstname'] = $result['firstName'];
        //     $user['lastname']  = $result['lastName'];
        //     $user['email']     = $result['email'];
        //     $user['city']      = $result['city'];
        //     $user['state']     = $result['state'];
        //     $user['userId']    = $result['userId'];
        //     $user['street1']   = $result['street1'];
        //      $user['mobilenetwork']     = $result['mobilenetwork'];
        //   // $response['error'] = false;
        //     //$response['user']  = $user;
             
       
            
        // } else {
        //     $response['error'] = true;
        //     $response['message'] = "No profile found";
        // }
        $db = null;
        echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = $e->getMessage();
         echo json_encode($response);
    }
    
});



$app->get('/user/profile', function() use ($app)
{
    $response = array();
    $user     = array();
    $req      = $app->request();
    $id       = $req->get('cust_id');
    
    $sql = "SELECT sn,street1, city, state, userId, firstName, lastName, email,mobilenetwork FROM config_user WHERE sn=$id";
    
    try {
        $db   = getConnection();
        $stmt = $db->query($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        if ($result) {
            $user['id']        = $result['sn'];
            $user['firstname'] = $result['firstName'];
            $user['lastname']  = $result['lastName'];
            $user['email']     = $result['email'];
            $user['city']      = $result['city'];
            $user['bvn']      = $result['bvn'];
           
            $user['state']     = $result['state'];
           
            $user['userId']    = $result['userId'];
            $user['street1']   = $result['street1'];
             $user['mobilenetwork']     = $result['mobilenetwork'];
            $response['error'] = false;
            $response['user']  = $user;
            
            
        } else {
            $response['error'] = true;
            $response['message'] = "No profile found";
        }
        $db = null;
        echo json_encode($user);
        echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = $e->getMessage();
         echo json_encode($response);
    }
    
});


//get User Line Graph Values
$app->post('/graph/getLineGraphdata', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $res      = array();
    if(isset($_POST['dbname'])){
    $dbname = $_POST['dbname'];
    }
    if(isset($_POST['id'])){
    $id        = $_POST['id'];
    }
    if(isset($_POST['serialnum'])){
    $serialnum = $_POST['serialnum'];
    }
    //$id = $req->get('id');
    
    $sql = "SELECT   `transAmount`,   `transDate` from transaction WHERE  `transType` =  'R' AND  `serialNo` = '$serialnum' order by transdate desc limit 14";
    
    $sql2 = "SELECT  `transAmount`,   `transDate` from transaction WHERE  `transType` =  'A' AND  `serialNo` = '$serialnum' order by transdate desc limit 14";
    
    
    
    
    try {
        $db               = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt             = $db->query($sql);
        $stmt2            = $db->query($sql2);
        //$stmt->execute();
        $result           = $stmt->fetchAll(PDO::FETCH_OBJ);
        $result2          = $stmt2->fetchAll(PDO::FETCH_OBJ);
        $res[graphredeem] = $result;
        $res[graphaccrue] = $result2;
        $db               = null;
        echo json_encode($res);
        // echo '{"graphaccrue": ' . json_encode($result2) . '}';
        
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});

//get Graph2 details
$app->post('/graph/getGraphdata', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $_POST['dbname'];
    
    $id        = $_POST['id'];
    $serialnum = $_POST['serialnum'];
    //$id = $req->get('id');
    
    
    $sql  = "SELECT COUNT(`transType`) AS RedemTrans
FROM transaction
WHERE  `transType` =  'R'  AND  `serialNo` = '$serialnum'";
    $sql2 = "SELECT COUNT(`transType`) AS AccuralTrans
FROM transaction
WHERE  `transType` =  'A' AND  `serialNo` = '$serialnum' ";
    //    $sql3 = "SELECT COUNT(`transType`) AS AccuralTrans
    //FROM transaction
    //WHERE  `transType` =  'A';
    //$sql ="SELECT * FROM applications where user_id=$id";
    try {
        $db    = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt  = $db->query($sql);
        $stmt2 = $db->query($sql2);
        $stmt->execute();
        $res[redeem] = $stmt->fetch();
        $stmt2->execute();
        $res[accrue] = $stmt2->fetch();
        //$stmt->execute();
        //$res[redeem] = $stmt->fetchAll(PDO::FETCH_OBJ);
        //$res[accrue] = $stmt2->fetchAll(PDO::FETCH_OBJ);
        $response[]  = $res;
        
        $db = null;
        echo json_encode($res);
        
        
        
        
        
        
        
        
        
    }
    catch (PDOException $e) {
        echo '{"error":' . $e->getMessage() . '}}';
    }
    
});



$app->post('/user/acctest', function() use ($app)
{
    $postdata       = file_get_contents("php://input");
    $request        = json_decode($postdata);
    $response       = array();
    $userno         = $_POST['email'];
    $serialNo         = $_POST['ref'];
    $password       = $_POST['password'];
     $response['error']   = $postdata;
        $response['message'] = $_POST['email'];
    
    echo json_encode($response);
    
    
});
//API SECTION


$app->post('/user/logintest', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userno   = $_POST['userno'];
    $password = $_POST['password'];
    $password = md5($password);
    
    
    //$sql = "SELECT   sn, email,password,userId FROM config_user WHERE userId=:userno and password=:password";
    //try {
    //  $db = getConnection();
    //$stmt = $db->prepare($sql);
    //$stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    
    
    
    
    $sql2 = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` ,CM.`tier_ratio` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` ,UM.`tierLevel` ,U.`userId`, U.`firstName` ,
	                           U.`lastName` ,U.`default` ,U.`email` , U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 

 JOIN `config_program` CM ON CM.programId=UM.merchantId
JOIN `config_merchant` SM ON SM.merchantId=:submerid

	WHERE SM.merchantId =:submerid
             AND SM.`password`=:password
								LIMIT 1";
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":submerid", $userno, PDO::PARAM_STR);
        $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
        //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $programDB = $result['programDb'];
        
        if ($result) {
            
            
            if ($programDB) {
                //$response['error']=$postdata;
                $response['id']         = $result['sn'];
                $response['email']      = $result['email'];
                $response['default']    = $result['default'];
                $response['programDb'] = $result['programDb'];
                $response['serialNo']   = $result['serialNo'];
                 $response['message']    = "user logged in";
            $response['status']     = "1";
            } else {
                $response['status']   = 0;
                $response['message'] = "wrong user id or password";
            }
            
        } else {
            $response['status']   = 0;
            $response['message'] = "wrong user id or password";
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['status']   = 0;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});



//get aLL MeRchants
$app->post('/refer/merchant', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    //$request  = json_decode($postdata);
    $response = array();
    
    
    
    //$sql = "SELECT   sn, email,password,userId FROM config_user WHERE userId=:userno and password=:password";
    //try {
    //  $db = getConnection();
    //$stmt = $db->prepare($sql);
    //$stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    
    $ttl=1;
    $sql2 = "SELECT CM.`merchantName` ,CM.`merchantId` ,  CM.`merchantImage` ,UM.`merchantId`,  UM.`referpoint`, UM.`referStatus`
								FROM `config_merchant` CM
                 
 JOIN `loyaltysettings` UM ON UM.submerchantId=CM.merchantId
WHERE UM.`referStatus` ='$ttl'
";
    
    
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
       
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
       // $result     = $stmt2->fetch();
        //$merchantDB = $result['merchantDb'];
         //echo json_encode($response);
       while ($result = $stmt2->fetch()) {
            
            
                //$response['error']=$postdata;
                $res['referStatus']         = $result['referStatus'];
                 $res['submerchantImage']  = $result['submerchantImage'];
                $res['submerchantId']      = $result['submerchantId'];
                $res['submerchantName']    = $result['submerchantName'];
                $res['merchantId'] = $result['merchantId'];
                //$response['serialNo']   = $result['serialNo'];
            
            
         array_push($response, $res);
            
        }
        
        echo json_encode($response);
        
       // $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});



//Do referal

$app->post('/users/referral', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $expiryDate = date('Y-m-d', strtotime('+20 years'));
    $senderid  = $_POST['senderid'];
   // $merchantIdarray  = $_POST['submerchantId'];
    $phoneno    = $_POST['phoneno'];
    
    //$senderid  = 201500000001;
    //$merchantIdarray  = ["201501", "201503"];
    //$phoneno    = 07011883388;
    
     //$email    = 'oluodebiyi@gmail.com';
    
   
    $email       = $_POST['email'];
    //$merchantId  = $_POST['merchantId'];
    //$merchantId  =$_POST['params('merchantId');
    $dateCreated = date("Y-m-d");
    
  

    $sql = "INSERT INTO  `multilevel`( `parent_id`, `child_phone`, `child_email`, `submerchantId`, `activated`,`datecreated`)
 VALUES (:parid,:childphone,:childemail,:merchantId,0,:datecreated)";
    
    //checj child emailif available
    $chek = "SELECT * FROM `multilevel` where child_email=:childemail";
     $chek2 = "SELECT * FROM `multilevel` where child_phone=:childphone"; 
    
     
    //auto assign SerialNo
     $getserialcode = "SELECT * FROM `config_user_merchant_info` where serialNo=:parent";
     $db2   = getConnection();
    $stmt2 = $db2->prepare($getserialcode);
    $stmt2->bindParam(":parent", $senderid);
     $stmt2->execute();
    
    $resultas    = $stmt2->fetch();
    
    $userId = $resultas['userId'];
    
    
    $getrefcode = "SELECT * FROM `config_user` where userId=:userid";
     $db1   = getConnection();
    $stmt1 = $db1->prepare($getrefcode);
    $stmt1->bindParam(":userid", $userId);
    
    $stmt1->execute();
    
    $resulta    = $stmt1->fetch();
   $str = $resulta['userId'];
    $firstname = $resulta['firstName'];
     $lastname = $resulta['lastName'];
    //post info in conig_user_merchant_info
   // $qrypostinfo = "INSERT INTO `config_user_merchant_info`(`userId`,`merchantId`, `serialNo`,`tierLevel`)
   // VALUES(:phone,:merchantId,:serialno,'1')";
    
    
    
    
    
    
   
            
            try {
                 
                $j='201506'; 
                 $db   = getConnection();
                $qrySerialNo = $db->prepare($chek);
               
                $qrySerialNo->bindParam(":childemail", $email, PDO::PARAM_STR);
                
               
                $qrySerphone = $db->prepare($chek2);
                
                $qrySerphone->bindParam(":childphone", $phoneno, PDO::PARAM_STR);
                
    $qrySerialNo->execute();
    $results = $qrySerialNo->fetch();
    $child_email = $results['child_email'];
     $qrySerphone->execute();
    $rest = $qrySerphone->fetch();
     $child_phone = $rest['child_phone'];
    if ($child_phone!='') {
     $response['error']   = true;
               $response['message'] = 'Phone number has been referred before';
    }else{

               $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":parid", $senderid, PDO::PARAM_STR);
                $stmt->bindParam(":childemail", $email, PDO::PARAM_STR);
                 $stmt->bindParam(":childphone", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":merchantId", $j, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
               
                
                $stmt->execute();
           $tt=0;


                $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg     = 'You have been referred by '. $firstname.' '.$lastname.' on the MoSave Savings Program. <br>';
                $subject = "MoLoyal Referral";
                $type    = "Moloyal Referral";
                sendEmail($from, $to, $msg, $subject, $type);
                
                 if ($tt==0) {
                $response['error']   = false;
                $response['message'] = "Your referral is successful";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
    }
               
                
            
            
            echo json_encode($response);
         }
            catch (PDOException $e) {
                $response['error']   = true;
                $response['message'] = $e->getMessage();
                echo json_encode($response);
                
            }
           
    
});

//get aLL stores
$app->get('/all/stores', function() use ($app)
{
  
   
    $response = array();
    
    
   
    
    $sql2 = "SELECT CM.`merchantName` ,CM.`merchantId` ,  CM.`merchantImage`
								FROM `config_merchant` CM";
                 

    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
       
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
       
       while ($result = $stmt2->fetch()) {
            
            
                //$response['error']=$postdata;
                $res['referStatus']         = $result['referStatus'];
                 $res['submerchantImage']  = $result['submerchantImage'];
                $res['submerchantId']      = $result['submerchantId'];
                $res['submerchantName']    = $result['submerchantName'];
                $res['merchantId'] = $result['merchantId'];
                //$response['serialNo']   = $result['serialNo'];
            
            
         array_push($response, $res);
            
        }
        
        echo json_encode($response);
        
       // $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});

//buy airtime



$app->post('/users/payment', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $phoneno   = $_POST['phoneno'];
    $reffnos   = $_POST['refno'];
    $email = $_POST['email'];
     $amount = $_POST['amount'];
      $mobilenetwork = $_POST['network'];
      $customerid = $_POST['customerid'];
     $merchantId  = $_POST['merchantId'];
     
     $submerchantIds='201506';
     //$dbname='moloyalc_avante_test';
 
  /*
     $phoneno   = '08051125927';
    $reffnos   = $_POST['refno'];
    $email = 'oluodebiyi@gmail.com';
     $amount = 200;
      $mobilenetwork = 'GLO';
     $merchantId  = 2015;
      $customerid = '07082996615';
    */ 
     
        if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='Glo'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9mobile'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
	  
   
 $dateCreated = date("Y-m-d g:i:s");
 
    // insert ref to $reffnos
    $sql2 = "INSERT INTO airtimepurchase(phoneno, network, transAmount)VALUES ('$phoneno','$mobilenetwork', '$amount')";
                    
       $se = "SELECT * from multilevel where child_phone='$phoneno' and activated=0";
                    
        $sql5 = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM JOIN `config_user` U ON U.UserId=UM.UserId  JOIN `config_program` CM ON CM.programId=UM.merchantId
	WHERE UM.`serialNo` =:usernos LIMIT 1";
	
	
	 $sqjser = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM JOIN `config_user` U ON U.UserId=UM.UserId  JOIN `config_program` CM ON CM.programId=UM.merchantId
	WHERE UM.`userId` ='$customerid' LIMIT 1";  
    
               //$sqjser = "SELECT * from config_user_merchant_info where userId='$customerid'";
    
    
    
    
   
    try {
         //$db         = getConnection();
       
         $getsettings = "SELECT * FROM `loyaltysettings` WHERE `submerchantId`='201506'";
   $ds1   =  getConnection();
        $sff1 = $ds1->prepare($getsettings);
        $sff1->execute();
         $resw = $sff1->fetch();
    $referpoint = $resw['referpoint'];
     $redemption_ratio = $resw['redemption_ratio'];
     $min_airtime = $resw['min_airtime'];
     
     
      //calculate redemption value to benefit      
$aredamt=$amount / $redemption_ratio;
							$nredamt = round($aredamt, 2);
          
           
        
        $db2   =  getConnection();
        $stmt9 = $db2->prepare($sql2);
      
                 /*   $stmt9->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
                    $stmt9->bindParam(":network", $mobilenetwork, PDO::PARAM_STR);
                    $stmt9->bindParam(":amount", $amount, PDO::PARAM_STR);
                    $stmt9->bindParam(":createddate", $datecreated, PDO::PARAM_STR);
                  */ 

        
       // $res=;
        $errorInfos = $stmt9->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = 'true';
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt9->fetch();
       // $merchantDB = $result['merchantDb'];
        
        if ($stmt9->execute()) {
             $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 50,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];

  curl_close($curl);
$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$amount&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$customerid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 50,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);


               
 $ds11   =  getConnection();
        $sffg = $ds11->prepare($sqjser);
        $sffg->execute();
         $resu = $sffg->fetch();
          $custserial = $resu['serialNo'];
           $custdb = $resu['programDb'];
           $merchantId = $resu['merchantId'];
          
         
         $qr = "SELECT * FROM `wallet` WHERE serialNo='$custserial' and submerchantId=$submerchantIds";
              
                $ds1sas   =  getDynamicConnection($custdb);
        $sff1sas = $ds1sas->prepare($qr);
        $sff1sas->execute();
         $re= $sff1sas->fetch();
    $s = $re['serialNo'];
     $sredeemableamt = $re['redeemableamt'];
     $saccruedpoints = $re['accruedpoints'];
    
if($s!=''){
    //update
    
    $nredamts=$nredamt+$sredeemableamt;
     $naccrudamts=$amount+$saccruedpoints;
    
    $addpoint_qry = "UPDATE `wallet` SET `accruedpoints`='$naccrudamts',`redeemableamt`='$nredamts',`tierpoint`='$ntierpnt' where serialNo='$custserial'and submerchantId=$submerchantIds";
								
}else
								{
								
								
								//insert
									$addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`,`tierLevel`, `comment`)
									VALUES ('001','2015','$submerchantIds','$custserial','$amount','$ntierpnt','$nredamt','$ntierLevel','autopost from airtime buying')";
								}
								
								  $dwsa   =  getDynamicConnection($custdb);
        $sf = $dwsa->prepare($addpoint_qry);
        $sf->execute();
        
        
        //Update subwallet with airtime value
        
        
 $subqry1ab = "SELECT * FROM `subwallet` WHERE serialNo='$custserial'";
               // $subwalqry = mysqli_query($link2,$subqry1);
               
               
                $ds1sab   =  getDynamicConnection($custdb);
        $sff1sab = $ds1sab->prepare($subqry1ab);
        $sff1sab->execute();
         $reswsab= $sff1sab->fetch();
    $serialNowe = $reswsab['serialNo'];
     $accruedairtime = $reswsab['accruedairtime'];
	 
	 if ($serialNowe !='')
{
    
    
    
///echo 'user  in subwal table';
	if($accruedairtime!=0){
		$totalairtime=$accruedairtime+$nredamt;
	}else{
		$totalairtime=$nredamt;
	}
	


	if($totalairtime>=$min_airtime){
	    
	    
	    
//send totalairtime & update sub wallet to 0 and keep record in airtime record table



//echo '<br>'.$totalairtime.'totalairtime<br>';
	
	
	
	//send airtime here
	
	$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$totalairtime&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$parentPhoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 50,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);

	
	$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`=0 where serialNo='$custserial' ";
//$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry2) or die(mysqli_error($link2));

  
                $ds1s   =  getDynamicConnection($custdb);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();
       
$airtimeqry = "INSERT INTO `airtimerecord`(`submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('201506','$customerid','001','$custserial','$totalairtime','$dateCreated','$dateCreated')";

									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
       


	}else{
	
//update sub wallet with new airtime amount
		$sumairtime=$accruedairtime+$nredamt;
		$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`='$sumairtime' where serialNo='$custserial'";
 $ds1s   =  getDynamicConnection($custdb);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();

	}
	
}else{


    

//echo 'user not in subwal table';
//echo '<br>'.$min_airtime.'min_airtime<br>';
//echo '<br>'.$nairtimeamt.'nairtimemt<br>';
																		
	if($nredamt>=$min_airtime)
	{
//send nairtime  and keep record in airtime record table
//echo 'mmmmee';
//echo '<br>'.$nairtimeamt.'nairtimeamt<br>';


$curls = curl_init();
$headers = [];
//$ref=22;
curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$nredamt&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$customerid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
 //echo $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
   $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
$airtimeqry = "INSERT INTO `airtimerecord`( `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													  VALUES('201506','$customerid','001','$custserial','$nredamt','$dateCreated','$dateCreated')";

									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
									
	}else{
//insert into sub wallet with new airtime amount
	//$sumairtime=$accruedairtime+$nairtimeamt;
	
	//echo 'airtime is less';
	
	$addsubwal_qry = "INSERT INTO `subwallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedairtime`)VALUES ('001','$merchantId','201506','$custserial','$nredamt')";
	 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($addsubwal_qry);
        $sfdf->execute();
        
        //$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry) or die(mysqli_error($link2));
}

}
    

        
        
//send success message
  $response['error']   = false;
            $response['message'] = 'airtime dispensed successfully ';

        $ds   =  getConnection();
        $sff = $ds->prepare($se);
        $sff->execute();
         $results = $sff->fetch();
    $child_id = $results['child_id'];
     $parent_id = $results['parent_id'];
     //e.g parent_id= 201500000243, child_id=201500000290
     
     //if referral is available
if($parent_id!='' && $child_id!=''){
    $db5   = getConnection();
        $stmt5 = $db5->prepare($sql5);
        $stmt5->bindParam(":usernos", $parent_id, PDO::PARAM_STR);
       
        $stmt5->execute();
        $result     = $stmt5->fetch();
        $programDB = $result['programDb'];
         $parentPhoneno = $result['userId'];
         $merchantId = $result['merchantId'];
         $parent_mobilenetwork= $result['mobilenetwork'];

 $getsettings = "SELECT * FROM `loyaltysettings` WHERE `submerchantId`='201506'";
   $ds1   =  getConnection();
        $sff1 = $ds1->prepare($getsettings);
        $sff1->execute();
         $resw = $sff1->fetch();
    $referpoint = $resw['referpoint'];
     $min_airtime = $resw['min_airtime'];
     
     
   //calculate referral point to benefit      
$airtimeamt=$amount / $referpoint;
							$nairtimeamt = round($airtimeamt, 2);
          
           
          //if user available in subwallet already
          $subqry1 = "SELECT * FROM `subwallet` WHERE serialNo='$parent_id'";
               // $subwalqry = mysqli_query($link2,$subqry1);
               
               
                $ds1s   =  getDynamicConnection($programDB);
        $sff1s = $ds1s->prepare($subqry1);
        $sff1s->execute();
         $resws= $sff1s->fetch();
    $serialNopp = $resws['serialNo'];
     $accruedairtime = $resws['accruedairtime'];
     
     if($parent_mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($parent_mobilenetwork=='Glo'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($parent_mobilenetwork=='9mobile'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($parent_mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
	  
    
  			 
if ( $serialNopp !='')
{
///echo 'user  in subwal table';
	if($accruedairtime!=0){
		$totalairtime=$accruedairtime+$nairtimeamt;
	}else{
		$totalairtime=$nairtimeamt;
	}
	


	if($totalairtime>=$min_airtime){
	    
	    
	    
//send totalairtime & update sub wallet to 0 and keep record in airtime record table



//echo '<br>'.$totalairtime.'totalairtime<br>';
	
	
	
	//send airtime here
	
	$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$totalairtime&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$parentPhoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);

	
	$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`=0 where serialNo='$parent_id' ";
//$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry2) or die(mysqli_error($link2));

  
                $ds1s   =  getDynamicConnection($programDB);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();
       
$airtimeqry = "INSERT INTO `airtimerecord`(`submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('201506','$parentPhoneno','001','$parent_id','$totalairtime','$dateCreated','$dateCreated')";

									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($programDB);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
       


	}else{
	
//update sub wallet with new airtime amount
		$sumairtime=$accruedairtime+$nairtimeamt;
		$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`='$sumairtime' where serialNo='$parent_id'";
 $ds1s   =  getDynamicConnection($programDB);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();

	}
	
}else{
    

//echo 'user not in subwal table';
//echo '<br>'.$min_airtime.'min_airtime<br>';
//echo '<br>'.$nairtimeamt.'nairtimemt<br>';
																		
	if($nairtimeamt>=$min_airtime)
	{
//send nairtime  and keep record in airtime record table
//echo 'mmmmee';
//echo '<br>'.$nairtimeamt.'nairtimeamt<br>';


$curls = curl_init();
$headers = [];
//$ref=22;
curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$nairtimeamt&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$parentPhoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
 //echo $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
   $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
$airtimeqry = "INSERT INTO `airtimerecord`( `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													  VALUES('201506','$parentPhoneno','001','$parent_id','$nairtimeamt','$dateCreated','$dateCreated')";

									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($programDB);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
									
	}else{
//insert into sub wallet with new airtime amount
	//$sumairtime=$accruedairtime+$nairtimeamt;
	
	//echo 'airtime is less';
	
	$addsubwal_qry = "INSERT INTO `subwallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedairtime`)VALUES ('001','$merchantId','201506','$parent_id','$nairtimeamt')";
	 $dser   =  getDynamicConnection($programDB);
        $sfdf = $dser->prepare($addsubwal_qry);
        $sfdf->execute();
        
        //$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry) or die(mysqli_error($link2));
}


    
}
     
  $addsubwal_qry1 = "UPDATE `multilevel` SET `activated`=1 WHERE parent_id='$parent_id' and child_phone='$phoneno'";
	  $db   = getConnection();
                $qrySerialNo2 = $db->prepare($addsubwal_qry1);
               
       
        $qrySerialNo2->execute();	   
     
    
}
        } else {
            $response['error']   = true;
            $response['message'] = 'airtime not dispensed ';
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});



$app->post('/user/accrualtest', function() use ($app)
{
    $postdata       = file_get_contents("php://input");
    $request        = json_decode($postdata);
    $response       = array();
    $userno         = $request->userno;
    $serialNo         = $request->userno;
    $password       = $request->password;
    $transamount    = $request->transamt;
    $submerchant_id = $request->submerchantid;
    $agent_id       = $request->agentid;
    $password       = md5($password);
    $merchant_id    = substr($submerchant_id, 0, 4);
    
    
        
       
        $transtype = 'A';
       
        $createdDate = date("Y-m-d H:i:s");
        $transDate = date("Y-m-d H:i:s");
    
    
    
    
    $sql3 = "SELECT * FROM `loyaltysettings` WHERE `merchantId`=:merchantId and `submerchantId`=:submerchantId";
    
    $billingqry = "SELECT * FROM `billing_setup` WHERE merchantId=:merchantId and submerchantid=:submerchantId";
    
    
    
    $sql2 = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` ,CM.`tier_ratio` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` ,UM.`tierLevel` ,U.`userId`, U.`firstName` ,
	                           U.`lastName` ,U.`default` ,U.`email` , U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 

 JOIN `config_program` CM ON CM.programId=UM.merchantId
JOIN `config_merchant` SM ON SM.merchantId=:submerid

	WHERE SM.merchantId =:submerid
             AND SM.`password`=:password
								LIMIT 1";
    
    
    
    
    
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":usernos", $userno, PDO::PARAM_STR);
        $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
        $stmt2->bindParam(":submerid", $submerchant_id,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $programDB = $result['programDb'];
        
        if ($result) {
            
            
           /* $response['id']         = $userno;
            $response['email']      = $result['email'];
            $response['default']    = $result['default'];
           
            $response['merchantDb'] = $result['merchantDb'];
            $response['serialNo']   = $result['serialNo'];
            $response['submer']     = $submerchant_id;
            $response['mer']        = $merchant_id;
           
            $response['tierLevels'] = $result['tierLevel'];
            $response['tier_ratio'] = $result['tier_ratio']; */
            
             $tier_ratio             = $result['tier_ratio'];
            $tierLevels             = $result['tierLevel']; 
             $userid = $result['userId'];
             //$serialNo= $result['serialNo'];
            $response['message']    = "user logged in";
            $response['status']     = "1";
            //get redemption and accrual ratios
            $db3                    = getConnection();
            $stmt3                  = $db3->prepare($sql3);
            $stmt3->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
            $stmt3->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
            
            $stmt3->execute();
            $result3                      = $stmt3->fetch();
           // $response['redemption_ratio'] = $result3['redemption_ratio'];
           // $response['accural_ratio']    = $result3['accural_ratio'];
            $redemption_ratio             = $result3['redemption_ratio'];
            $accural_ratio                = $result3['accural_ratio'];
            
            
            //get billing percentage
            
            $stmt4 = $db2->prepare($billingqry);
            $stmt4->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
            $stmt4->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
            
            $stmt4->execute();
            $result4 = $stmt4->fetch();
            
            $billingpercentage = $result4['percentage'];
            $billingrate       = $result4['rate'];
            
           // $response['billingpercentage'] = $result4['percentage'];
           // $response['billingrate']       = $result4['rate'];
            
            
            
            if ($accural_ratio != 0 && $redemption_ratio != 0 && $tier_ratio != 0 && $billingpercentage != 0 && $billingrate != 0) {
                
                
                 $db        = getDynamicConnection($programDB);
                $walletqry = "SELECT * FROM `wallet` WHERE serialNo=:serialNo and submerchantId=:submerchantId";
                $stmt5     = $db->prepare($walletqry);
                $stmt5->bindParam(":serialNo", $serialNo , PDO::PARAM_STR);
                $stmt5->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                
                $stmt5->execute();
                $result5                 = $stmt5->fetch();
                //$response['tierLevels2'] = $result5['tierLevel'];
                $accruedpoints           = $result5['accruedpoints'] == null ? 0 : $result5['accruedpoints'];
                $tierpoint               = $result5['tierpoint'] == null ? 0 : $result5['tierpoint'];
                $tierlevel               = $result5['tierLevel'] == null ? 1 : $result5['tierLevel'];
                $redeemableamt           = $result5['redeemableamt'] == null ? 0.00 : $result5['redeemableamt'];
                
               // $response['tierLevels3'] = $tierlevel;
                $getTier                 = "SELECT * FROM `tier_setup` WHERE tierLevel=:tierLevels and merchantId=:merchantId";
                $stmt6                   = $db2->prepare($getTier);
                $stmt6->bindParam(":tierLevels", $tierLevels, PDO::PARAM_STR);
                
                $stmt6->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                
                $stmt6->execute();
                $result6                     = $stmt6->fetch();
                $instorepntquota             = $result6[instorePntQuota];
                $tierpntquota                = $result6[tierpntquota];
                //$response['tierpntquota']    = $tierpntquota;
                //$response['instorepntquota'] = $instorepntquota;
                
                
                if ($tierpoint != 0 && $tierpoint >= $tierpntquota) {
                    //Calculate Vendor Billing
                    $billamtpercent = ($transamount * $billingpercentage) / 100;
                    $billamtrate    = $billingrate;
                    
                    $preferredbillamt = max($billamtpercent, $billamtrate);
                    
                    //check for expiry and reset here
                    //Reset Accural and Redemption When moved to Next Tier
                    
                    $naccrue    = 0;
                    $nredeemamt = $redeemableamt;
                    $ntierpnt   = 0;
                    $ntierLevel = $tierLevels + 1;
                    
                    //get Maximum Tier level from tier_setup table
                    
                    $maxquery = "SELECTMAX( tierLevel ) as tlevel FROM  `tier_setup`";
                    $stmt7    = $db2->prepare($maxquery);
                    
                    
                    $stmt7->execute();
                    $result7 = $stmt7->fetch(PDO::FETCH_ASSOC);
                    
                    $tierLevele = $result7['tlevel'];
                    
                    if ($ntierLevel > $tierLevele) {
                        $ntierLevel = $tierLevele;
                    }
                    
                    $upqry = "UPDATE `config_user_merchant_info` SET `tierLevel`=:ntierLevel where serialNo=:serialNo
									and merchantId=:merchantId";
                    
                    $stmt8 = $db2->prepare($upqry);
                    $stmt8->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                    $stmt8->bindValue(":serialNo", $serialNo , PDO::PARAM_STR);
                    
                    $stmt8->bindValue(":merchantId", $merchant_id, PDO::PARAM_STR);
                    
                    $stmt8->execute();
                    
                    
                    
                    //$delqry = mysqli_query($con,"DELETE FROM `wallet` WHERE serialNo='$serialNo'");
                    
                }else {
                    
                    //Calculate Vendor Billing
                    $billamtpercent = ($transamount * $billingpercentage) / 100;
                    $billamtrate    = $billingrate;
                    
                    $preferredbillamt = max($billamtpercent, $billamtrate);
                    
                    //$response['accural_ratio']    = $accural_ratio;
                    //Calculate accrual Points
                    $newaccuralpoints             = $transamount * $accural_ratio;
                    //$response['newaccuralpoints'] = $newaccuralpoints;
                    //$response['transamount']      = $transamount;
                    
                    //Calculate Redemption Amount
                    //$nredeemamt = $redeemableamt + ($newaccuralpoints / $redemption_ratio);
                    
                    $nredeemamt = $redeemableamt + ($transamount / $redemption_ratio);
                    $nredeemamt = round($nredeemamt, 2);
                    
                    $response['nredeemamt '] = $nredeemamt;
                    
                    //Increament accurals in wallet
                    $naccrue = $accruedpoints + $newaccuralpoints;
                    
                    
                    $response['naccrue '] = $naccrue;
                    
                    
                    
                    //Calculate ntierPoint
                    $ntierpnt              = $naccrue / $tier_ratio;
                    $ntierpnt              = floor($ntierpnt);
                    $ntierLevel            = $tierLevels;
                    $response['ntierpnt '] = $ntierpnt;
                    
                    if ($ntierpnt >= $tierpntquota) {
                        
                        //check for expiry and reset here
                        //Reset Accural  When moved to Next Tier
                        
                        $naccrue = 0;
                        
                        $ntierpnt   = 0;
                        $ntierLevel = $tierLevels + 1;
                        
                        
                        //get Maximum Tier level from tier_setup table
                        
                        $maxquery = "SELECTMAX( tierLevel ) as tlevel FROM  `tier_setup`";
                        $stmt7    = $db2->prepare($maxquery);
                        
                        
                        $stmt7->execute();
                        $result7                = $stmt7->fetch(PDO::FETCH_ASSOC);
                        $tierLevele             = $result7['tlevel'];
                        $response['tierLevele'] = $tierLevele;
                        if ($ntierLevel > $tierLevele) {
                            $ntierLevel = $tierLevele;
                        }
                        
                        
                        $upqry = "UPDATE `config_user_merchant_info` SET `tierLevel`=:ntierLevel where serialNo=:serialNo
										and merchantId=:merchantId";
                        $stmt8 = $db2->prepare($upqry);
                        $stmt8->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                        $stmt8->bindValue(":serialNo", $serialNo, PDO::PARAM_STR);
                        
                        $stmt8->bindValue(":merchantId", $merchant_id, PDO::PARAM_STR);
                        
                        $stmt8->execute();
                        //$ntierLevel = $tierLevels;
                    }
                    
                }
                
                //if userrecord  available already
                if ($result5) {
                    //update
                    
                    
                    
                    
                    $addpoint_qry = "UPDATE `wallet` SET `accruedpoints`=:naccrue,`redeemableamt`=:nredeemamt,`tierLevel`=:ntierLevel,`tierpoint`=:ntierpnt where serialNo=:serialNo and submerchantId=:submerchantId";
                    
                    $stmt9 = $db->prepare($addpoint_qry);
                    $stmt9->bindValue(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt9->bindValue(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":naccrue", $naccrue, PDO::PARAM_STR);
                    $stmt9->bindParam(":nredeemamt", $nredeemamt, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierpnt", $ntierpnt, PDO::PARAM_STR);
                    
                    
                    
                }
            
         else {
                    
                    $comment      = 'autopost from loyalty';
                    //insert
                    $addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`, `comment`)
									VALUES (:agentid,:merchantId,:submerchantId,:serialNo,:naccrue, :ntierpnt, :nredeemamt, :comment)";
                    
                    $stmt9 = $db->prepare($addpoint_qry);
                    $stmt9->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt9->bindParam(":naccrue", $naccrue, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierpnt", $ntierpnt, PDO::PARAM_STR);
                    
                    $stmt9->bindParam(":nredeemamt", $nredeemamt, PDO::PARAM_STR);
                    $stmt9->bindParam(":comment", $comment, PDO::PARAM_STR);
                }
                
                // $stmt9->execute();
                
                if ($accuralpoints != 0) {
                    $comment = $accuralpoints . " points ";
                }
                
                $tes=$stmt9->execute();
                if ($tes=='true') {
                    $qry = "INSERT INTO `transaction`(`submerchantId`,`userId`, `agentId`, `serialNo`, `transAmount`,`transType`, `points`,													 `priceTag`, `comment`, `status`, `createdDate`, `transDate`)
													   VALUES(:submerchantId,:userid,:agentid,:serialNo,:transamount,:transtype,:newaccuralpoints,
																 :priceamt,:comment,:status,:createdDate,:transDate)";
                    
                    //$qryresult = mysqli_query($link2, $qry) or die(mysqli_error($link2));
                    $stmt_tran = $db->prepare($qry);
                    
                     $stmt_tran ->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":userid", $userid, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":transamount", $transamount, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":transtype", $transtype, PDO::PARAM_STR);
                    
                    $stmt_tran ->bindParam(":newaccuralpoints", $newaccuralpoints, PDO::PARAM_STR);
                        $stmt_tran ->bindParam(":priceamt", $priceamt, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":status", $status, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":createdDate", $createdDate, PDO::PARAM_STR);
                    
                    $stmt_tran ->bindParam(":transDate", $transDate, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":comment", $comment, PDO::PARAM_STR);
                    $stmt_tran->execute();
                    $transactionid = $db->lastInsertId();
                    
                    $billcomment = $preferredbillamt . " bill charged on " . $transamount;
                    
                    
                    $qry5      = "INSERT INTO `billing_record`(`merchantId`, `submerchantId`, `agentId`, `transactionId`, `transAmount`, `billAmount`, `comment`,`transDate`)
									VALUES(:merchantId,:submerchantId,:agentid,:transactionid,:transamount,:preferredbillamt,:billcomment,:transDate)";
                   $stmt_bill = $db->prepare($qry5);
                    $stmt_bill->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":transactionid", $transactionid, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":transamount", $transamount, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":preferredbillamt", $preferredbillamt, PDO::PARAM_STR);
                    
                    $stmt_bill->bindParam(":billcomment", $billcomment, PDO::PARAM_STR);
                      
                    $stmt_bill->bindParam(":transDate", $transDate, PDO::PARAM_STR);
                    $stmt_bill->execute();
                    //$qryresult5 = mysqli_query($link2, $qry5) or die(mysqli_error($link2));
                     $response['message']    = "accrual transaction succesful";
            $response['status']     = "4";
                    
                }
                
                //end
                
                
            } else {
                
                $response['message'] = "Loyalty matrix has not been configured, please contact admin";
                $response['status']  = "0";
            }
            
            
            
            
            
            
            
            
            
            
            
        } else {
            
            $response['error']   = true;
            $response['message'] = "wrong user id or password";
            $response['status']  = "0";
            
        }
        
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});


//event ticket dispense
$app->post('/dispense/ticket', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    //  $ticketClass = array();
    //  $qty = array();
    //  $price = array();
    //  $class = array();
    $phoneno   = $request->customerid;
     $customerid= $request->customerid;
$amount= $request->amount;
$currency= $request->currency;
$email= $request->email;
$merchantId= $request->merchantId;
$submerchantId= $request->submerchantId;
//$event_id= $request->event_id;
$firstname= $request->firstname;
$lastname= $request->lastname;
$transaction_date = $request->transaction_date;
$length= $request->cart;
$myCart=$request->myCart;
$title= $request->title;
    $date = date(" Y ");
//$qty= 3;
$ref= $request->ref;
$sn=$request->sn;
    $tickquery = "SELECT `from_date`, `from_time`, `venue` FROM `config_event_ticket` WHERE sn = '$sn'";
	$dbquery   = getConnection();
	$statment = $dbquery->query($tickquery);
	$statment->execute();
	$row = $statment->fetch(PDO::FETCH_ASSOC);
	echo $venue = $row['venue'];
	echo $from_date = $row['from_date'];
	echo $from_time = $row['from_time'];
	
	
	
	
	
	           // $db   = getConnection();
            // $stmt = $db->query($sql);
            // $stmt->execute();
            //   while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {    
            // //$result = $stmt->fetch(PDO::FETCH_ASSOC);
            // $id = $result['sn'];
            // $res['sn'] = $result['sn'];
            // $res['merchantName'] = $result['merchantName'];
            // $res['merchantId'] = $result['merchantId'];
            // $res['submerchantId'] = $result['submerchantId'];
            // $res['event_id'] = $result['event_id'];
//$submerchantId= $myCart[0]->submerchantId;
//Test Values
//$length=2;
// $myCart->name='Reg';
// $myCart->name='VIP';
// // $myCart[0]->qty=2;
// // $myCart[1]->qty=1;
// // $myCart[0]->price=500;
// // $myCart[1]->price=1000;
//John code
// $query = "SELECT * FROM `config_event_ticket` ORDER BY id ASC";
// 				$result = mysqli_query($connect, $query);
// 				if(mysqli_num_rows($result) > 0)
// 				{
// 					while($row = mysqli_fetch_array($result))
// 					{
     
 $db   =  getConnection(); 
   
          
          	/* Exception class. */
require_once 'PHPMailer/src/Exception.php';

/* The main PHPMailer class. */
require_once 'PHPMailer/src/PHPMailer.php';

/* SMTP class, needed if you want to use SMTP. */
//require_once '/home/speckl7/gr8jobs.specklessinnovations.com/PHPMailer/src/SMTP.php';

require_once 'PHPMailer/src/SMTP.php';


  $mail = new PHPMailer(TRUE);

       $mail = new PHPMailer();
  $mail->SMTPDebug = 0;
  $mail->CharSet = 'UTF-8';
  $mail->isSMTP();
  $mail->SMTPAuth   = true;
  $mail->Host   = "premium42.web-hosting.com";
  $mail->Port       = 465;
  
  $mail->SMTPSecure = "ssl";
 //Sets SMTP authentication. Utilizes the Username and Password variables
       	$mail->Username = 'care@moloyal.com';					//Sets SMTP username
	$mail->Password = 'Welcome@13#';	
 					//Sets SMTP password
		

	$mail->From = 'care@moloyal.com';			//Sets the From email address for the message
	$mail->FromName = 'MoLoyal Tickets';			//Sets the From name of the message
 $mail->addAddress($email);

   /* Set the subject. */
  

   /* Set the mail message body. */
  	
						//Sets SMTP authentication. Utilizes the Username and Password variables
			//Sets the From email address for the message
$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML		
			//Adds a "To" address
							//Sets message type to HTML		
//Pdf generator plugin
	include('pdf.php');
	//qrcode generator plugin
	include "phpqrcode/qrlib.php";   
	
	//$output3 .= '';
	
	
     	include "table-head.php";                           
                               
                                
                                
                                
                        
       
		
	$output2  .= '<link rel="stylesheet" type="text/css" href="https://moloyal.com/test/loyaluserscript/api/email.css">';
		$output2 .='
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
<link  href="https://moloyal.com/test/loyaluserscript/api/email.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <table class="body">
      <tr>
        <td class="center" align="center" valign="top">
          <center data-parsed="">
            <table class="container text-center"><tbody><tr><td> <!-- This container adds the gap at the top of the email -->
              <table class="row grey"><tbody><tr>
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  &#xA0; 
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
            </td></tr></tbody></table> 
            
            <table class="container text-center"><tbody><tr><td> <!-- Main Email Content -->
              <table class="row"><tbody><tr> <!-- Logo -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  <center data-parsed="">
                    <a href="http://www.moloyal.com" align="center" class="text-center">
                      <img src="https://moloyal.com/images/moloyal.png" class="swu-logo" alt="Logo">
                    </a>
                  </center>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row masthead"><tbody><tr> <!-- Masthead -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  <h1 class="text-center">Your Receipt</h1>
                  <center data-parsed="">
                  <img src="https://www.moloyal.com/test/loyaltyadmin/ticket_images/coming-soon.png" valign="bottom" alt="Masthead Image" align="center" class="text-center">
                  </center>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row"><tbody><tr>
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  &#xA0; <!--This container adds the gap between masthead and digest content -->
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row"><tbody><tr> <!-- Email copy -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                <h5>Hi '.$firstname.',</h5>
                  <p> Please find ticket details in attach PDF.  </p>
                  <br>
                  
                  <hr>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row show-for-large"><tbody><tr> <!-- Receipt Header. Hidden for mobile--> 
                    <th class="small-12 large-4 columns first">
      <table>
        <tr>
          <th>
                  <b>Ticket</b>
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  <b>Price</b>
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  <b>Quantity</b>
                </th>
        </tr>
      </table>
    </th>
                   
                    <th class="small-12 large-2 columns last">
      <table>
        <tr>
          <th>
                  <b>Total</b>
                </th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row"><tbody><tr>';
              
              
              
              
              
              
              
              
  for ($i = 0; $i < $length; $i++) {
        
        $ticketClass[$i]=$request->myCart[$i]->name;
        
        $qty[$i]=$request->myCart[$i]->qty;
        $ticketPrice[$i]=$request->myCart[$i]->price;
        $tickettotalPrice[$i]=$request->myCart[$i]->totalPrice;
      
      //Reduce number of tickets based on tickets bought  
         $qsl="SELECT * FROM `event_category` WHERE `event_id`='$sn' AND `name`='$ticketClass[$i]'";
       
        $sfs = $db->prepare($qsl);
        $sfs->execute();
        $resw1 = $sfs->fetch();
    $tbl_qty = $resw1['quantity'];
    $new_qty=$tbl_qty -  $qty[$i];
     
     $qsl1="UPDATE `event_category` SET `quantity`='$new_qty'  WHERE `event_id`='$sn'  AND `name`='$ticketClass[$i]'";
       
    $sfs1 = $db->prepare($qsl1);
    $sfs1->execute();
    
        
        
         $output3 .='<tr>
                                    <td width="75%" align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding: 15px 10px 5px 10px;">
                                        '.$ticketClass[$i].'  ('.$qty[$i].')
                                    </td>
                                    <td width="25%" align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding: 15px 10px 5px 10px;">
                                       N'.$tickettotalPrice[$i].'
                                    </td>
                                </tr> ';
        
        
				
					$output2 .= '
               <table class="row"><tbody><tr> 
               
               
               <!-- Receipt first row -->
                    <th class="small-12 large-4 columns first">
      <table>
        <tr>
          <th>
                  '.$ticketClass[$i].'
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  '.$ticketPrice[$i].'
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                 '.$qty[$i].' 
                </th>
        </tr>
      </table>
    </th>
                
                    <th class="small-12 large-2 columns last">
      <table>
        <tr>
          <th>
                  '.$tickettotalPrice[$i].'
                </th>
        </tr>
      </table>
      
      
    </th>
              </tr></tbody></table>
              
              
		
			
			
		';
	//}
	
	
	
        
        //  array_push($qty, $qty[$i]);
        //  array_push($price, $ticketPrice[$i]);
        //  array_push($class, $ticketClass[$i]);
         
       
    //   $ticketPrice.$i= $myCart[$i]->price;
    //     $qty.$i=$myCart[$i]->qty;
       
//           foreach($qty as $k)
// 	{
	    
	    for ($k = 1; $k <=$qty[$i]; $k++) { 
	        $f_name = $ref.'-'.md5(rand());
	        	$pdffile_name = $f_name. '.pdf';
	        	$qr=md5(rand());
	        	$qrfilename=$qr.'.png';
	$tempDir = '../qr_files';
		//QRcode::png(data, $filename, QR_ECLEVEL_H, pixelsize, framesize);
	QRcode::png($qr, '../qr_files/'.$qrfilename, QR_ECLEVEL_H, 6, 2);
	   	$output = '
	   	
	   	
	<div class="table-responsive">
		<table class="table ">
			<tr >
			
			</tr>
	';
	
	$output .='
	<!DOCTYPE html>
<html>
    <head>
        <title> pdf </title>
    </head>
    <body>
            <p style="text-align:center; color: red;" >
                    Users are to note that the payment for this ticket is Non-Refundable.
                </p>
                
                <table border="1px" cellspacing="0" cellpadding="0" width="0" align="center" style="border-color: #000">
                    <tbody>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Name:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                        '.$firstname.' '.$lastname.' 
                                </p>
                            </td>
                            <td width="190" rowspan="5" valign="top">
                                <br>
                                <br>
                                <span style="padding-left:10px; padding-right:10px;">
                                             <img src="../qr_files/'.$qrfilename.'" style="border:2px solid #000;" "width="80%" /> 
                                </span>  
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Phone Number:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                        '.$customerid.' 
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Email Address:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                        '.$email.'
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Ticket Category:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                         '.$ticketClass[$i].'
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Transaction Reference:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                    '.$ref.'
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Date:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                    '.$transaction_date.'
                                </p>
                            </td>
                            <td width="190" valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td width="150" valign="top">
                                <p style="padding-left: 10px;">
                                    Amount:
                                </p>
                            </td>
                            <td width="200" valign="top">
                                <p style="padding-left: 10px;">
                                        '.$currency.''.$ticketPrice[$i].'
                                </p>
                            </td>
                            <td width="190" valign="top">
                                
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                
                
                <p style="text-align:center">
                        <strong>TICKET QR CODE FOR <span style="text-transform: uppercase;">'.$title.'</span> </strong>
                    </p>
                    
                <div style="text-align:center;">
                            <img width="179" height="51" src="images/moloyal.png" />
                            <br>
                            <img width="719" height="2" src="images/clip_image003.png"/>
                </div>
                
                
            
    </body>
</html>
	';
	
		$output5 .= '
		
			<tr>
				<td>'.$title.'</td>
				</tr>
				<tr>
				<td> Ticket Category: '.$ticketClass[$i].'</td>
				</tr>
				<tr>
					<td> Price: '.$ticketPrice[$i].'</td>
					
			</tr>
			<tr>
				<img src="../qr_files/'.$qrfilename.'" /></td>
					
			</tr>
			
			
		';
	//}
	$output .= '
		</table>
	</div>
	';
	
	
	  
	
	
		
	$file_name = $ref.'-'.md5(rand()) . '.pdf';
	$html_code = '<link rel="stylesheet" href="bootstrap.min.css">';
	$html_code .=$output;
	
	$pdf = new Pdf();
	$pdf->load_html($html_code);
	$pdf->render();
	$file = $pdf->output();
	file_put_contents('../pdf_files/'.$pdffile_name, $file);
 		$mail->AddAttachment('../pdf_files/'.$pdffile_name);
	  
	  $ql="INSERT INTO `ticket_record`( `user_id`,`lname`,`fname`, `email`, `qr`, `event_id`, `ticket_class`, `amount`, `pay_reference`, `buy_date_time`) 
	  VALUES ('$customerid','$lastname','$firstname','$email', '$qr','$sn','$ticketClass[$i]','$ticketPrice[$i]','$ref',NOW())";
       
        $sf = $db->prepare($ql);
        $sf->execute();
        
              
  
           
          
    }
    
  } 
  
  
  
  
   include "table-foot.php";
  
  
  
  
  
  
  
$output2 .=' <table class="row"><tbody><tr>
            
                <table class="row hide-for-large"><tbody><tr> <!-- Spacer -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  &#xA0;
                  <hr>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
               
            
              <table class="row show-for-large"><tbody><tr> <!-- Spacer -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  &#xA0;
                  <hr>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              
              <table class="row"><tbody><tr> <!-- Receipt total -->
                    <th class="small-12 large-4 columns first">
      <table>
        <tr>
          <th>
                  &#xA0;
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  &#xA0;
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  &#xA0;
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns">
      <table>
        <tr>
          <th>
                  Total
                </th>
        </tr>
      </table>
    </th>
                    <th class="small-12 large-2 columns last">
      <table>
        <tr>
          <th>
                  <b>N'.$amount.' </b>
                </th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
            
              <table class="row"><tbody><tr> <!-- Call to action button -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  <center data-parsed="">
                    <br align="center" class="text-center"><br align="center" class="text-center">
                    <div class="button">
                      
                      <a href="#" style="background-color:#f7931d;border:0px solid #f7931d;border-radius:3px;color:#ffffff;display:inline-block;font-family:sans-serif;font-size:16px;font-weight:bold;line-height:40px;text-align:center;text-decoration:none;width:160px;-webkit-text-size-adjust:none;mso-hide:all;">View Full Details</a>
                    </div>
                  </center>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
              <table class="row"><tbody><tr> <!--This row adds the gap between masthead and digest content -->
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  &#xA0; 
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
            </tr></tbody></table>
        
        </tr></tbody></table>
        
        
        
        
        
        
        
        </td></tr></tbody></table> <!-- / End main email content -->
            
            <table class="container text-center"><tbody><tr><td> <!-- Footer -->
              <table class="row grey"><tbody><tr>
                    <th class="small-12 large-12 columns first last">
      <table>
        <tr>
          <th>
                  <p class="text-center footercopy">&#xA9; Copyright '.$date.' Moloyal. All Rights Reserved.</p>
                </th>
<th class="expander"></th>
        </tr>
      </table>
    </th>
              </tr></tbody></table>
            </td></tr></tbody></table>  
            
            
          </center>
        </td>
      </tr>
    </table>
  </body>
</html>';
    
    
    
	
	$mail->Subject = 'Ticket Details for '.$title;			//Sets the Subject of the message
	//$mail->Body ='Hello '.$firstname.' '.$lastname.', <br>Your total order is '.$output2.'<br>Please find ticket details in attach PDF File.';
	$mail->Body ='  '.$output3.' ';
 // $mail->MIMEVersion = "MIME-Version: 1.0";
//$mail->ContentType =  "Content-Type: text/html; charset=ISO-8859-1";
	//An HTML or plain text message body
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
	
	
	$submerchantrewardId='201506';
	 $sqjser = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM JOIN `config_user` U ON U.UserId=UM.UserId  JOIN `config_program` CM ON CM.programId=UM.merchantId
	WHERE UM.`userId` ='$customerid' LIMIT 1";  
	
         $getsettings = "SELECT * FROM `loyaltysettings` WHERE `submerchantId`='$submerchantId'";
   $ds1   =  getConnection();
        $sff1 = $ds1->prepare($getsettings);
        $sff1->execute();
         $resw = $sff1->fetch();
    $referpoint = $resw['referpoint'];
     $redemption_ratio = $resw['redemption_ratio'];
     $min_airtime = $resw['min_airtime'];
     
     
      //calculate redemption value to benefit      
$aredamt=$amount / $redemption_ratio;
							$nredamt = round($aredamt, 2);
          
           
        
               
 $ds11   =  getConnection();
        $sffg = $ds11->prepare($sqjser);
        $sffg->execute();
         $resu = $sffg->fetch();
          $custserial = $resu['serialNo'];
           $custdb = $resu['programDb'];
           $programId = $resu['programId'];
           $mobilenetwork = $resu['mobilenetwork'];
          
          if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='Glo'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9mobile'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
	  
         $qr = "SELECT * FROM `wallet` WHERE serialNo='$custserial' and submerchantId=$submerchantrewardId";
              
                $ds1sas   =  getDynamicConnection($custdb);
        $sff1sas = $ds1sas->prepare($qr);
        $sff1sas->execute();
         $re= $sff1sas->fetch();
    $s = $re['serialNo'];
     $sredeemableamt = $re['redeemableamt'];
     $saccruedpoints = $re['accruedpoints'];
    
if($s!=''){
    //update
    
    $nredamts=$nredamt+$sredeemableamt;
     $naccrudamts=$amount+$saccruedpoints;
    
    $addpoint_qry = "UPDATE `wallet` SET `accruedpoints`='$naccrudamts',`redeemableamt`='$nredamts',`tierpoint`='$ntierpnt' where serialNo='$custserial'and submerchantId=$submerchantrewardId";
								
}else
								{
								
								
								//insert
									$addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`,`tierLevel`, `comment`)
									VALUES ('001','2015','$submerchantrewardId','$custserial','$amount','$ntierpnt','$nredamt','$ntierLevel','autopost from airtime buying')";
								}
								
								  $dwsa   =  getDynamicConnection($custdb);
        $sf = $dwsa->prepare($addpoint_qry);
        $sf->execute();
        
        
        //Update subwallet with airtime value
        
        
 $subqry1ab = "SELECT * FROM `subwallet` WHERE serialNo='$custserial'";
               // $subwalqry = mysqli_query($link2,$subqry1);
               
               
                $ds1sab   =  getDynamicConnection($custdb);
        $sff1sab = $ds1sab->prepare($subqry1ab);
        $sff1sab->execute();
         $reswsab= $sff1sab->fetch();
    $serialNowe = $reswsab['serialNo'];
     $accruedairtime = $reswsab['accruedairtime'];
	 
	 if ($serialNowe !='')
{
    
    
    
///echo 'user  in subwal table';
	if($accruedairtime!=0){
		$totalairtime=$accruedairtime+$nredamt;
	}else{
		$totalairtime=$nredamt;
	}
	
	if($totalairtime>=$min_airtime){
	    
	    
	    
//send totalairtime & update sub wallet to 0 and keep record in airtime record table
//echo '<br>'.$totalairtime.'totalairtime<br>';
	
	  $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));
 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];
  curl_close($curl);
	
	//send airtime here
	
	$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network
curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$totalairtime&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$customerid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));
 $response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
	
	$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`=0 where serialNo='$custserial' ";
//$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry2) or die(mysqli_error($link2));
  
                $ds1s   =  getDynamicConnection($custdb);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();
       
$airtimeqry = "INSERT INTO `airtimerecord`(`submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('$submerchantId','$customerid','001','$custserial','$totalairtime',NOW(),NOW())";
									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
       
	}	else{
	
//update sub wallet with new airtime amount
		$sumairtime=$accruedairtime+$nredamt;
		$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`='$sumairtime' where serialNo='$custserial'";
 $ds1s   =  getDynamicConnection($custdb);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();
	}
	
	
}else{
    
    
//echo 'user not in subwal table';
//echo '<br>'.$min_airtime.'min_airtime<br>';
//echo '<br>'.$nairtimeamt.'nairtimemt<br>';
																		
	if($nredamt>=$min_airtime)
	{
//send nairtime  and keep record in airtime record table
//echo 'mmmmee';
//echo '<br>'.$nairtimeamt.'nairtimeamt<br>';
$curls = curl_init();
$headers = [];
//$ref=22;
curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$nredamt&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$customerid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));
 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
 //echo $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
   $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
$airtimeqry = "INSERT INTO `airtimerecord`( `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													  VALUES('$submerchantrewardId','$customerid','001','$custserial','$nredamt',NOW(),NOW())";
									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
									
	}else{
//insert into sub wallet with new airtime amount
	//$sumairtime=$accruedairtime+$nairtimeamt;
	
	//echo 'airtime is less';
	
	$addsubwal_qry = "INSERT INTO `subwallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedairtime`)VALUES ('001','$merchantId','$submerchantrewardId','$custserial','$nredamt')";
	 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($addsubwal_qry);
        $sfdf->execute();
        
        //$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry) or die(mysqli_error($link2));
}
}
     
  
    
     
     $response['error']   ='false';
            $response['message'] ='Customer ticket has been sent successfully';
  
      
	}else{ 
	    $response['error']   ='true';
            $response['message'] ='There is an issue sending ticket to email';
  
  }
	
	
    // INSERT INTO `ticket_paymentrecord`(`id`, `user_id`, `email`, `qr`, `event_id`, `ticket_class`, `amount`, `pay_reference`, `buy_date_time`, `used`, `used_date_time`) 
    // VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11])
    
      $response['min_airtime']   =$min_airtime;
      $response['sbra']   =$submerchantrewardId;
      $response['serialNo']   =$serialNowe;
       $response['sn']   =$sn;
     $response['custmerid']   =$customerid;
            $response['submerchantId'] =$submerchantId;
  
  
      echo json_encode($response);
      
});   
      
     
       
//event ticket dispense
$app->post('/dispense/ticket2', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $phoneno   = $_POST['customerid'];
    $reffnos   = $_POST['ref'];
    $email = $_POST['email'];
     $length =$_POST['length'];
     $amount =$_POST['amount'];
      $submerchantID =$_POST['SubmerchantID'];
      $customerid =$_POST['customerid'];
     $ticketdetails  =$_POST['Cartdetails'];
      $sn = $_POST['sn'];
    // $currecy= $ticketdetails[0]->currency;
     $title= $ticketdetails->title;
     
     
//      currency: "NGN"
// name: "VVIP"
// price: "50000"
// qty: 1
// submerchant: undefined
// title: "Flytime festival"
// totalPrice: 50000
     //$submerchantIds='201506';
     //$dbname='moloyalc_avante_test';
  
  
//     $customerid= "08051125927";
// $amount= 5000;
// $currency= "NGN";
// $email= "oluodebiyi@gmail.com";
// $event_id= "203546";
// $merchantId= "2015";
// $qty= 3;
// $ref= "TICK251243598";
// $sn="1";
// $submerchantId= "201508";
// $ticketClass= "Regular";
// $ticketPrice= "3000";
// $title= "Flytime festival";
      
      
     //ticketService.buyticket({email: $scope.user.email, ref: response.reference, 
     //amount: $rootScope.total, submerchantId: submerchantId, Customerid: $scope.user.userId, title: title, event_id:event_id, 
     //ticketClass: ticketName, qty:qty, ticketPrice: price, currency: currency, merchantId: merchantId, sn: sn, firstname: $scope.user.firstname, lastname: $scope.user.lastname, })
       
    try{    
        
//send success message
  $response['error']   = $currecy;
            $response['message'] = $length;
            
            
            $connect=getConnection();
	$query = "SELECT * FROM config_event_ticket where sn='$sn'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	
	$qu = "SELECT * FROM `event_category` WHERE event_id='$sn'";
	$stat = $connect->prepare($qu);
	$stat->execute();
	$result = $stat->fetchAll();
	$filename='test2.png';
	include "phpqrcode/qrlib.php";   
	$tempDir = '../qr_files';
		//QRcode::png(data, $filename, QR_ECLEVEL_H, pixelsize, framesize);
	QRcode::png('45ef39c15bdf9bb47614b946cbb5e875', '../qr_files/'.$filename, QR_ECLEVEL_H, 6, 2);
	$output = '
	<div class="table-responsive">
		<table class="table ">
			<tr >
			
			</tr>
	';
	//foreach($result as $row)
	//{
		$output .= '
			<tr>
				<td>'.$title.'</td>
				</tr>
				<tr>
				<td> Ticket Category: '.$ticketClass.'</td>
				</tr>
				<tr>
					<td> Price: '.$ticketPrice.'</td>
					
			</tr>
			<tr>
					<td> <img src="../qr_files/test.png" /></td>
					
			</tr>
			
		';
	//}
	$output .= '
		</table>
	</div>
	';
	
	
		include('pdf.php');
	$file_name = md5(rand()) . '.pdf';
	$html_code = '<link rel="stylesheet" href="bootstrap.min.css">';
	$html_code .=$output;
	
	$pdf = new Pdf();
	$pdf->load_html($html_code);
	$pdf->render();
	$file = $pdf->output();
	file_put_contents($file_name, $file);
	
	
	/* Exception class. */
require_once 'PHPMailer/src/Exception.php';

/* The main PHPMailer class. */
require_once 'PHPMailer/src/PHPMailer.php';

/* SMTP class, needed if you want to use SMTP. */
//require_once '/home/speckl7/gr8jobs.specklessinnovations.com/PHPMailer/src/SMTP.php';

require_once 'PHPMailer/src/SMTP.php';


  $mail = new PHPMailer(TRUE);

       $mail = new PHPMailer();
  $mail->SMTPDebug = 0;
  $mail->CharSet = 'UTF-8';
  $mail->isSMTP();
  $mail->SMTPAuth   = true;
  $mail->Host   = "premium42.web-hosting.com";
  $mail->Port       = 465;
  
  $mail->SMTPSecure = "ssl";
 //Sets SMTP authentication. Utilizes the Username and Password variables
       	$mail->Username = 'care@moloyal.com';					//Sets SMTP username
	$mail->Password = 'Welcome@13#';	
 					//Sets SMTP password
		

	$mail->From = 'care@moloyal.com';			//Sets the From email address for the message
	$mail->FromName = 'MoLoyal Tickets';			//Sets the From name of the message
 $mail->addAddress($email, $type);

   /* Set the subject. */
  

   /* Set the mail message body. */
  	
						//Sets SMTP authentication. Utilizes the Username and Password variables
			//Sets the From email address for the message
$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML		
	
	
// foreach ($_FILES["attachment"]["name"] as $k => $v) {
//     $mail->AddAttachment( $_FILES["attachment"]["tmp_name"][$k], $_FILES["attachment"]["name"][$k] );
// }
	$mail->AddAttachment($file_name);     				//Adds an attachment from a path on the filesystem
	$mail->Subject = 'Ticket Details for '.$title;			//Sets the Subject of the message
	$mail->Body ='Hello '.$fn.', <br>Your total order is '.$amount.'<br>Please find ticket details in attach PDF File.';				//An HTML or plain text message body
	$mail->Send();
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
	
	 $sqjser = "SELECT CM.`programName` , CM.`programDb` , CM.`programEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                            U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM JOIN `config_user` U ON U.UserId=UM.UserId  JOIN `config_program` CM ON CM.programId=UM.merchantId
	WHERE UM.`userId` ='$customerid' LIMIT 1";  
	
         $getsettings = "SELECT * FROM `loyaltysettings` WHERE `submerchantId`='$submerchantId'";
   $ds1   =  getConnection();
        $sff1 = $ds1->prepare($getsettings);
        $sff1->execute();
         $resw = $sff1->fetch();
    $referpoint = $resw['referpoint'];
     $redemption_ratio = $resw['redemption_ratio'];
     $min_airtime = $resw['min_airtime'];
     
     
      //calculate redemption value to benefit      
$aredamt=$amount / $redemption_ratio;
							$nredamt = round($aredamt, 2);
          
           
        
               
 $ds11   =  getConnection();
        $sffg = $ds11->prepare($sqjser);
        $sffg->execute();
         $resu = $sffg->fetch();
          $custserial = $resu['serialNo'];
           $custdb = $resu['programDb'];
           $merchantId = $resu['merchantId'];
           $mobilenetwork = $resu['mobilenetwork'];
          
          if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='Glo'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9mobile'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
	  
         $qr = "SELECT * FROM `wallet` WHERE serialNo='$custserial' and submerchantId=$submerchantId";
              
                $ds1sas   =  getDynamicConnection($custdb);
        $sff1sas = $ds1sas->prepare($qr);
        $sff1sas->execute();
         $re= $sff1sas->fetch();
    $s = $re['serialNo'];
     $sredeemableamt = $re['redeemableamt'];
     $saccruedpoints = $re['accruedpoints'];
    
if($s!=''){
    //update
    
    $nredamts=$nredamt+$sredeemableamt;
     $naccrudamts=$amount+$saccruedpoints;
    
    $addpoint_qry = "UPDATE `wallet` SET `accruedpoints`='$naccrudamts',`redeemableamt`='$nredamts',`tierpoint`='$ntierpnt' where serialNo='$custserial'and submerchantId=$submerchantId";
								
}else
								{
								
								
								//insert
									$addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`,`tierLevel`, `comment`)
									VALUES ('001','2015','$submerchantId','$custserial','$amount','$ntierpnt','$nredamt','$ntierLevel','autopost from airtime buying')";
								}
								
								  $dwsa   =  getDynamicConnection($custdb);
        $sf = $dwsa->prepare($addpoint_qry);
        $sf->execute();
        
        
        //Update subwallet with airtime value
        
        
 $subqry1ab = "SELECT * FROM `subwallet` WHERE serialNo='$custserial'";
               // $subwalqry = mysqli_query($link2,$subqry1);
               
               
                $ds1sab   =  getDynamicConnection($custdb);
        $sff1sab = $ds1sab->prepare($subqry1ab);
        $sff1sab->execute();
         $reswsab= $sff1sab->fetch();
    $serialNowe = $reswsab['serialNo'];
     $accruedairtime = $reswsab['accruedairtime'];
	 
	 if ($serialNowe !='')
{
    
    
    
///echo 'user  in subwal table';
	if($accruedairtime!=0){
		$totalairtime=$accruedairtime+$nredamt;
	}else{
		$totalairtime=$nredamt;
	}
	
	if($totalairtime>=$min_airtime){
	    
	    
	    
//send totalairtime & update sub wallet to 0 and keep record in airtime record table
//echo '<br>'.$totalairtime.'totalairtime<br>';
	
	  $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));
 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];
  curl_close($curl);
	
	//send airtime here
	
	$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network
curl_setopt_array($curls, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$totalairtime&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$customerid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));
 //$response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
	
	$addsubwal_qry2 = "UPDATE `subwallet` SET `accruedairtime`=0 where serialNo='$custserial' ";
//$addsubwal_qry2 =  mysqli_query($link2,$addsubwal_qry2) or die(mysqli_error($link2));
  
                $ds1s   =  getDynamicConnection($custdb);
        $sff1s = $ds1s->prepare($addsubwal_qry2);
        $sff1s->execute();
       
$airtimeqry = "INSERT INTO `airtimerecord`(`submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('$submerchantId','$customerid','001','$custserial','$totalairtime','$dateCreated','$dateCreated')";
									//$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
									
									 $dser   =  getDynamicConnection($custdb);
        $sfdf = $dser->prepare($airtimeqry);
        $sfdf->execute();
       
	}
}
     $response['error']   =$serialNowe;
            $response['message'] ='Customer ticket has been sent successfully';
  
  
    
     
      
	}else{ 
	    $response['error']   ='true';
            $response['message'] ='There is an issue sending ticket to email';
  
  }
	//unlink($file_name);
	
	}catch (phpmailerException $e)
{
   /* PHPMailer exception. */
   $message =  $e->errorMessage();
}
    
    
    
    
      echo json_encode($response);
              
         
     
});




//Functions
//generateotp

function generateotp(){
 $characters = 6;
    $letters    = '123456789';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
    return $str;    
    
    
}
//Generate Random Number
function random()
{
    $characters = 8;
    $letters    = '234567890';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
    return $str;
}


function sendSMS($phone,$msg)
{
   
   $msg=urlencode($msg);
   $url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to='.$phone.'&body='.$msg.'&dnd=2';
    
    $curl = curl_init();
//$url='https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=t2T319wBXjEQsaGAHDQesL4EBss4VwmdjYRdGUQd0YgRVHt59vqI63IWcKln&from=MoLoyal&to=09096456814&body=testing messgae lummy&dnd=2';
curl_setopt_array($curl, array(
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  
));

$response = curl_exec($curl);

curl_close($curl);
return $response;
}


function getTransactionRef(){
     $characters = 3;
    $letters    = '23456789';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
     $ref=date("Ymdgis");
     $k=$ref.$str;
     return $k;
     
}


function sendEmail($from, $to, $msg, $subject, $type)
{
    
   $from = "care@moloyal.com"; //enter your email address
    
   
    
    $text    = $msg; // text versions of email.
    $message = '<!DOCTYPE html>
<html>
<head>
<title>Moloyal Registration</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<style type="text/css">
/* CLIENT-SPECIFIC STYLES */
body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
img { -ms-interpolation-mode: bicubic; }

/* RESET STYLES */
img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
table { border-collapse: collapse !important; }
body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }

/* iOS BLUE LINKS */
a[x-apple-data-detectors] {
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* MEDIA QUERIES */
@media screen and (max-width: 480px) {
    .mobile-hide {
        display: none !important;
    }
    .mobile-center {
        text-align: center !important;
    }
}

/* ANDROID CENTER FIX */
div[style="margin: 16px 0;"] { margin: 0 !important; }
</style> 
<body style="margin: 0 !important; padding: 0 !important; background-color: #eeeeee;" bgcolor="#eeeeee">

<!-- HIDDEN PREHEADER TEXT -->



<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td align="center" style="background-color: #eeeeee;" bgcolor="#eeeeee">

        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
            <tr>
                <td align="center" valign="top" style="font-size:0; padding: 35px;" bgcolor="#fff">

                <div style="display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;">
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
                        <tr>
                            <td align="left" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 36px; font-weight: 800; line-height: 48px;" class="mobile-center">
                               <!-- <h1 style="font-size: 36px; font-weight: 800; margin: 0; color: #ffffff;">Beretun</h1>-->
                               <img src="https://moloyal.com/images/moloyal.png" >
                            </td>
                        </tr>
                    </table>
                </div>


                </td>
            </tr>
            <tr>
                <td align="center" style="padding: 35px 35px 20px 35px; background-color: #ffffff;" bgcolor="#ffffff">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
               ' . $msg . '
                    </table>

                </td>
            </tr>
            <tr>
                <td align="center" style=" padding: 35px; background-color: #1b9ba3;" bgcolor="#1b9ba3">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                    <tr>
                        <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
                            <h2 style="font-size: 24px; font-weight: 800; line-height: 30px; color: #ffffff; margin: 0;">
                                <!--Get 15% off your next order.-->
                                Don\'t you have the Mobile App!
                            </h2>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 25px 0 15px 0;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="center" style="border-radius: 5px;" bgcolor="#66b3b7">
                                      <a href="https://play.google.com/store/apps/details?id=com.moloyal.moloyal.app&hl=en" target="_blank" style="font-size: 18px;  font-family: Open Sans, Helvetica, Arial, sans-serif;  display: block;"><img src="https://moloyal.com/test/loyaluserscript/api/images/downloadapp.png" style="width: 120px;"></a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                </td>
            </tr>
            <tr>
                <td align="center" style="padding: 35px; background-color: #ffffff;" bgcolor="#ffffff">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                    <tr>
                        <td align="center" >
                         <a href="https://www.facebook.com/moloyalapp/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/facebook.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://bit.ly/hellomoloyal">   <img src="https://moloyal.com/test/loyaluserscript/api/images/whatsapp.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://www.twitter.com/moloyalapp/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/twitter.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                         <a href="https://www.instagram.com/moloyal_app/">   <img src="https://moloyal.com/test/loyaluserscript/api/images/instagram.png" width="37" height="37" style="display: block; border: 0px; display:inline;"/></a>
                        </td>
                    </tr>
                   <!-- <tr>
                        <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; padding: 5px 0 10px 0;">
                            <p style="font-size: 14px; font-weight: 800; line-height: 18px; color: #333333;">
                                675 Massachusetts Avenue<br>
                                Cambridge, MA 02139 
                            </p>
                        </td>
                    </tr>-->
                    <tr>
                        <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px;">
                            <p style="font-size: 14px; font-weight: 400; line-height: 20px; color: #777777; text-align:center;">
                                    Click on Profile Settings on the left-hand menu to update your profile. 
                                    <br>
                                    If you have any questions, please feel free to contact our support team 
                                    <br>
                                    
                                    Email: <a href="mailto:care@moloyal.com">care@moloyal.com</a>   or Call: 08188775534.
                                    <br>
                                    Our customer support team will be happy to assist you.
                            </p>
                        </td>
                    </tr>
                </table>

                </td>
            </tr>
        </table>

        </td>
    </tr>
</table>
    
</body>
</html>
';
    
/* Exception class. */
require_once 'PHPMailer/src/Exception.php';

/* The main PHPMailer class. */
require_once 'PHPMailer/src/PHPMailer.php';

/* SMTP class, needed if you want to use SMTP. */
//require_once '/home/speckl7/gr8jobs.specklessinnovations.com/PHPMailer/src/SMTP.php';

require_once 'PHPMailer/src/SMTP.php';


  $mail = new PHPMailer(TRUE);

       $mail = new PHPMailer();
  $mail->SMTPDebug = 0;
  $mail->CharSet = 'UTF-8';
  $mail->isSMTP();
  $mail->SMTPAuth   = true;
  $mail->Host   = "premium42.web-hosting.com";
  $mail->Port       = 465;
  
  $mail->SMTPSecure = "ssl";
 //Sets SMTP authentication. Utilizes the Username and Password variables
       	$mail->Username = 'care@moloyal.com';					//Sets SMTP username
	$mail->Password = 'Welcome@13#';	
 					//Sets SMTP password
		

	$mail->From = 'care@moloyal.com';			//Sets the From email address for the message
	$mail->FromName = 'MoLoyal Support';			//Sets the From name of the message
 $mail->addAddress($to, $type);

   /* Set the subject. */
   $mail->Subject = $subject;

   /* Set the mail message body. */
   $mail->Body = $message;
	$mail->WordWrap = 50;						//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);	
   /* Finally send the mail. */
   $kk=$mail->send();
   /* Finally send the mail. */
if ($kk==0)
{
 //echo 'Mailer Error: ' . $mail->ErrorInfo;
 
 return 'Mailer Error: ' . $mail->ErrorInfo;
//echo("<p>" . $mail->getMessage() . "</p>");
}
else {
return 1;
}

}





// $headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

// $text = ''; // text versions of email.
// $html = $message; // html versions of email.

// $crlf = "\n";




// $mime = new Mail_mime($crlf);
// $mime->setTXTBody($text);
// $mime->setHTMLBody($html);

// //do not ever try to call these lines in reverse order
// $body = $mime->get();
// $headers = $mime->headers($headers);

//  $host = "localhost"; // all scripts must use localhost
//  $username = "care@moloyal.com"; //  your email address (same as webmail username)
//  $password = "Welcome@13#"; // your password (same as webmail password)

// $smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
// 'username' => $username,'password' => $password));

// $mail = $smtp->send($to, $headers, $body);

// if (PEAR::isError($mail)) {
// return 0;
// //echo("<p>" . $mail->getMessage() . "</p>");
// }
// else {
// return 1;

// //echo("<p>Message successfully sent!</p>");
// // header("Location: http://www.example.com/");
// }


// }

function getMobileNetwork($phoneno)
{
    
    $identifier=substr($phoneno,0,4);
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from mobile_network_carrier  WHERE prefix=:identifier");
    $stmt->bindParam(":identifier", $identifier, PDO::PARAM_STR);
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result) {
        return $result['mobile_network'];
    } else {
        return null;
    }
}


function isAgentPhoneExist($phoneno)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_agent WHERE agentId=:phoneno");
    $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result['agentId']!='') {
        return true;
    } else {
        return false;
    }
}

function isBvnExist($bvn)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_user WHERE BVN_num=:bvn");
    $stmt->bindParam(":bvn", $bvn, PDO::PARAM_STR);
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result['BVN_num']!='') {
        return true;
    } else {
        return false;
    }
}
function isPhoneExist($phoneno)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_user WHERE userId=:phoneno");
    $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result['userId']!='') {
        return true;
    } else {
        return false;
    }
}

function isAgentEmailExist($email)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_agent WHERE email =:email");
    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
    
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result['email']!='') {
        return true;
    } else {
        return false;
    }
}

function isEmailExist($email)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_user WHERE email =:email");
    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
    
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result['email']!='') {
        return true;
    } else {
        return false;
    }
}


function getConnection()
{
    $dbhost = "localhost";
    $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    
    $dbname = "moloyalc_mosave_master_test";
    //  $dbhost="localhost";
    //  $dbuser="root";
    //  $dbpass="";
    //  $dbname="moloyalc_mosave_master_test";
    $dbh    = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}


function getDynamicConnection($dbname)
{
    //    $dbhost="localhost";
    //    $dbuser="root";
    //    $dbpass="";
    //    $dbname=$dbname;
    
    $dbhost = "localhost";
    $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    $dbname = $dbname;
    
    
    $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}




$app->run();

?>
