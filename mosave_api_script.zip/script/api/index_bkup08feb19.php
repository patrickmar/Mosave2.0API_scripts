<?php
require 'PasswordHash.php';
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();


$app = new \Slim\Slim();
$app->get('/hello', function()
{
    echo "Hello, World";
});

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    
    exit(0);
}


$app->post('/users/register', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $expiryDate = date('Y-m-d', strtotime('+20 years'));
    $firstname  = $request->firstname;
    $phoneno    = $request->phoneno;
    $mobilenetwork    = $request->mobilenetwork;
    $lastname    = $request->lastname;
    $email       = $request->email;
    $merchantId  = $request->merchantId;
    $password    = md5($request->password);
    $dateCreated = date("Y-m-d");
    
    
    
    $sql = "INSERT INTO config_user(firstname,lastname,email,password,mobilenetwork,userId,dateCreated)
 VALUES (:firstname,:lastname,:email,:password,:mobilenetwork,:phoneno,:datecreated)";
    
    //auto assign SerialNo
    $qrySerialNo = "SELECT * FROM `code_carddetails` where status='I' and printed=0 and merchantId=:merchantId limit 1";
    
    //auto assign SerialNo
    $qrydbname = "SELECT * FROM `config_merchant` where merchantId=:merchantId limit 1";
    
    
    //post info in conig_user_merchant_info
    $qrypostinfo = "INSERT INTO `config_user_merchant_info`(`userId`,`merchantId`, `serialNo`,`tierLevel`)
	VALUES(:phone,:merchantId,:serialno,'1')";
    
    
    
    
    
    
    try {
        //auto assign SerialNo
		if (isEmailExist($email)) {
        $response['error']   = true;
        $response['message'] = "This email already exist";
        echo json_encode($response);
        return;
    }elseif (isPhoneExist($phoneno)) {
        $response['error']   = true;
        $response['message'] = "This phone number already exist";
        echo json_encode($response);
        return;
    }else{
        $db         = getConnection();
        $stmtdbname = $db->prepare($qrydbname);
        $stmtdbname->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
        $stmtdbname->execute();
        $res    = $stmtdbname->fetch();
        $dbname = $res['merchantDb'];
        
        $stmtSerialNo = $db->prepare($qrySerialNo);
        $stmtSerialNo->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
        $stmtSerialNo->execute();
        $res      = $stmtSerialNo->fetch();
        $serialno = $res['serialNo'];
        
        if ($serialno != "") {
            
            try {
                $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
                $stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
                $stmt->bindParam(":email", $email, PDO::PARAM_STR);
                $stmt->bindParam(":mobilenetwork", $mobilenetwork, PDO::PARAM_STR);
                $stmt->bindParam(":password", $password, PDO::PARAM_STR);
                
                $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
                
                $stmt->execute();
            }
            catch (PDOException $e) {
                $response['error']   = true;
                $response['message'] = $serialno;
                echo json_encode($response);
                
            }
            $stmtpostinfo = $db->prepare($qrypostinfo);
            $stmtpostinfo->bindParam(":phone", $phoneno, PDO::PARAM_STR);
            $stmtpostinfo->bindParam(":merchantId", $merchantId, PDO::PARAM_STR);
            $stmtpostinfo->bindParam(":serialno", $serialno, PDO::PARAM_STR);
            $stmtpostinfo->execute();
            
            if ($stmt->rowCount()) {
                $qryupdatecard  = "UPDATE `code_carddetails` SET dateActivated=:dateCreated, status='A' WHERE `serialNo`=:serialno";
                $stmtupdatecard = $db->prepare($qryupdatecard);
                $stmtupdatecard->bindParam(":dateCreated", $dateCreated, PDO::PARAM_STR);
                
                $stmtupdatecard->bindParam(":serialno", $serialno, PDO::PARAM_STR);
                $stmtupdatecard->execute();
                
                $db2    = getDynamicConnection($dbname);
                $qry10  = "INSERT INTO `subscription`(`userId`, `merchantId`, `serialNo`, `dateCreated`, `lastSubscriptionDate`, `expiryDate`, `status`) VALUES ('$phoneno','$merchantId','$serialno','$dateCreated','$dateCreated','$expiryDate','A')";
                $qry10s = $db2->prepare($qry10);
                
                $qry10s->execute();
                
                $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg     = 'You have been assigned serial Number ' . $serialno . ' . <br>This will be used for all future transactions.';
                $subject = "Moloyal Registration";
                $type    = "Moloyal New Registration";
                
                sendEmail($from, $to, $msg, $subject, $type);
                $response['error']   = false;
                $response['message'] = "Welcome to Moloyal.";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
            }
			
            echo json_encode($response);
        }
		}
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});


//login user


$app->post('/user/login', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userno   = $request->userno;
    $password = $request->password;
    $password = md5($password);
    
    
    //$sql = "SELECT   sn, email,password,userId FROM config_user WHERE userId=:userno and password=:password";
    //try {
    //  $db = getConnection();
    //$stmt = $db->prepare($sql);
    //$stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    
    
    $sql2 = "SELECT CM.`merchantName` , CM.`merchantDb` , CM.`merchantEmail` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` , U.`firstName` ,
	                           U.`lastName` ,U.`default` ,U.`email` ,U.`mobilenetwork`, U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 
 JOIN `config_merchant` CM ON CM.merchantId=UM.merchantId

	WHERE U.`userId` =:usernos
             AND U.`password`=:password
								LIMIT 1";
    
    
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":usernos", $userno, PDO::PARAM_STR);
        $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
        //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $merchantDB = $result['merchantDb'];
        
        if ($result) {
            
            
            if ($merchantDB) {
                //$response['error']=$postdata;
                $response['id']         = $result['sn'];
                $response['email']      = $result['email'];
                $response['default']    = $result['default'];
                $response['merchantDb'] = $result['merchantDb'];
                $response['serialNo']   = $result['serialNo'];
                $response['mobilenetwork']   = $result['mobilenetwork'];
            } else {
                $response['error']   = true;
                $response['message'] = "wrong user id or password";
            }
            
        } else {
            $response['error']   = true;
            $response['message'] = "wrong user id or password";
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});





//forgot password


$app->post('/users/forgotpass', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userid   = $request->userid; 	

    $email    = $request->email;
    
    if (!isEmailExist($email)) {
        $response['error']   = true;
        $response['message'] = "Email does not exist in our records";
        echo json_encode($response);
        return;
    }
    if (!isPhoneExist($userid)) {
        $response['error']   = true;
        $response['message'] = "User id does not exist in our records";
        echo json_encode($response);
        return;
    }
    
    //$randompwd=random();
    $rando = random();
    
    $randompwd = md5($rando);
    $def       = 1;
    $from      = "noreply@moloyal.com";
    $to        = $email;
    $msg       = 'Your new temporary password is ' . $rando . ' <br>kindly use to login and reset to a new password. ';
    $subject   = "Moloyal Forgot Password";
    
    $sql2 = "Update config_user SET `password`=:rand, `default`=:def WHERE `userId`=:userid and `email`=:email";
    try {
        $type = "Moloyal forgot password";
        $mi=sendEmail($from, $to, $msg, $subject, $type);
        if ($mi==1) {
            $db2   = getConnection();
            $stmt2 = $db2->prepare($sql2);
            $stmt2->bindParam(":userid", $userid, PDO::PARAM_STR);
            $stmt2->bindParam(":email", $email, PDO::PARAM_STR);
            $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
            
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($stmt2->execute()) {
                $response['error']   = false;
                $response['message'] = "A temporary password has been sent to your email";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
        }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});


//Reset password


$app->post('/users/resetpass', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userid   = $request->userid;
    $email    = $request->email;
    $password = $request->password;
    
    
    if (!isPhoneExist($userid)) {
        $response['error']   = true;
        $response['message'] = "User id does not exist in our records";
        echo json_encode($response);
        return;
    }
    
    
    
    $randompwd = md5($password);
    $def       = '0';
    $from      = "noreply@moloyal.com";
    $to        = $email;
    $msg       = 'You have requested for a password reset on Moloyal. <br> If you did not initiate this request, Please contact the admin';
    $subject   = "Moloyal Password Reset";
    
    $sql2 = "Update config_user SET `password`=:rand, `default`=:def WHERE `userId`=:userid";
    try {
        $type = "Moloyal reset password";
        if (isEmailExist($email)) {
            sendEmail($from, $to, $msg, $subject, $type);
        } {
            $db2   = getConnection();
            $stmt2 = $db2->prepare($sql2);
            $stmt2->bindParam(":rand", $randompwd, PDO::PARAM_STR);
            
            $stmt2->bindParam(":def", $def, PDO::PARAM_STR);
            
            $stmt2->bindParam(":userid", $userid, PDO::PARAM_STR);
            
            
            //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
            
            
            $errorInfos = $stmt2->errorInfo();
            if (isset($errorInfos[2])) {
                $response['error']   = true;
                $response['message'] = $errorInfos[2];
                echo json_encode($response);
            }
            if ($stmt2->execute()) {
                $response['error']   = false;
                $response['message'] = "Your password reset is successful";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
            //$response= $stmt2->fetch();
            echo json_encode($response);
        }
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});


//Support Email


$app->post('/users/support', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userid   = $request->userid;
    $email    = $request->email;
    $username = $request->username;
    $message  = $request->message;
    $title    = $request->title;
    $phoneno  = $request->phoneno;
   if ($email == ""){
        $email = "noreply@moloyal.com"; }
       
    
    
    $from    = $email;
    $to      = "care@moloyal.com";
    $msg     = "A customer with phone number " . $phoneno . " sent the message below: <br>" . $message;
    $subject = "Moloyal App Support: " . $title;
    
    
    
    
        $type = "Moloyal App support";
        
       try {
        $type = "Moloyal App support";
        
        
       if(sendEmail($from, $to, $msg, $subject, $type)){
        
        
        $response['error']   = false;
        $response['message'] = "Your message has been sent. Thanks for contacting us.";
       }else{
           
            $response['error']   = true;
        $response['message'] = "Your message not sent. ";
       }
        
        
        
        
        
        echo json_encode($response);
        
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});



//get Voucher Setup Data


$app->post('/voucher/getVoucherdata', function() use ($app)
{
    $response = array();
   // $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
   
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    
    $sql1 = "SELECT *
FROM config_user_merchant_info 
WHERE  `serialNo` =:serialnum";
    
    
    $db1   = getConnection();
    $stmt1 = $db1->prepare($sql1);
    $stmt1->bindParam(":serialnum", $serialnum, PDO::PARAM_STR);
    
    $stmt1->execute();
    
    $resulta    = $stmt1->fetch();
    $merchantId = $resulta['merchantId'];
    $tierLevel  = $resulta['tierLevel'];
    $userId     = $resulta['userId'];
    
    
    $sql = "SELECT  vou.merchantId, vou.submerchantId, vou.tierlevel, vou.percentageDiscount, vou.NoOfTimesUsed, vou.maxTimesUsage, vou.useFromDate, vou.useToDate,
	vou.vouchertype, vou.voucherFor, vou.createdDate, vou.expiryDate,vou.status, vou.activationDate, csub.submerchantName,csub.submerchantimage, ts.tierName
FROM voucher vou JOIN moloyalc_master.config_submerchant csub ON csub.submerchantId = vou.submerchantId 
JOIN moloyalc_master.tier_setup ts ON ts.tierLevel=vou.tierlevel
WHERE  vou.tierlevel =  '$tierLevel'  AND  vou.merchantId = '$merchantId'";
    
    
    try {
        //$db = getDynamicConnection($dbname);
        $db   = getConnection($dbname);
        $stmt = $db->query($sql);
        $stmt->execute();
        //$result = $stmt->fetchAll(PDO::FETCH_OBJ);
        
       $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $res['NoOfTimesUsed'] = $result['NoOfTimesUsed'];
            
            $res['activationDate'] = $result['activationDate'];
            $res['createdDate']    = $result['createdDate'];
            $res['expiryDate']     = $result['expiryDate'];
            
            
            
            
            /*
            elseif($vouchertype==2 && $NoOfTimesUsed>=1)
            {
            $message="Your one time voucher has been used";
            $validUser=9;
            }
            elseif($vouchertype==3 && $NoOfTimesUsed>=$maxTimesUsage)
            {
            $message = "Maximum voucher usage exceeded";
            $validUser=9;
            }
            elseif($vouchertype==4 && (date("Y-m-d")<$useFromDate || date("Y-m-d")>$useToDate))
            {
            $message="Voucher can no longer be used on this date";
            $validUser=9;
            }
            */
            
            
            if (date("Y-m-d H:i:s") > $res['expiryDate']) {
                $res['expiry'] = "1";
                
                
            } else {
                $res['expiry'] = "0";
            }
            $res['status']             = $result['status'];
            $res['maxTimesUsage']      = $result['maxTimesUsage'];
            $res['merchantId']         = $result['merchantId'];
            $res['percentageDiscount'] = $result['percentageDiscount'];
            $res['submerchantId']      = $result['submerchantId'];
            $res['submerchantName']    = $result['submerchantName'];
            $res['submerchantimage']   = $result['submerchantimage'];
            $res['tierName']           = $result['tierName'];
            $res['tierlevel']          = $result['tierlevel'];
            $res['submerchantimage']   = $result['submerchantimage'];
            $res['tierName']           = $result['tierName'];
            $res['useToDate']          = $result['useToDate'];
            $res['useFromDate']        = $result['useFromDate'];
            $res['voucherFor']         = $result['voucherFor'];
            $res['vouchertype']        = $result['vouchertype'];
            $res['status']             = $result['status'];
            array_push($response, $res);
            
        
        
        
        
        $db = null;
        
        echo json_encode($response);
        
        
    }
    catch (PDOException $e) {
        echo '{"error":' . $e->getMessage() . '}';
    }
    
});

//get my Voucher record
$app->post('/voucher/getMyVrecord', function() use ($app)
{
    $response = array();
    //$user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    //$response = array();
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    //$id = $req->get('id');
    
    
    $sql = "SELECT  `submerchantId`, `serialno`, `tierlevel`, `NoOfTimesUsed`, `activationDate`, `status` FROM `voucher_records`
		WHERE `serialno`='$serialnum'";
    
    
    try {
        $db     = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"voucher": ' . json_encode($result) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});




//get all transaction
$app->get('/transactions/all', function()
{
    $sql = "SELECT jp.id,jp.job_title,jp.experience,jp.location,jp.skill_required,
          jp.job_description,DATE_FORMAT(jp.date_posted,'%M %d,  %Y') AS date_posted,
          DATE_FORMAT(jp.expiry_date,'%M %d,  %Y') AS expiry_date,
          sec.name,emp.company_name
          FROM job_postings jp JOIN sectors sec ON sec.id=jp.sector_id
          JOIN employers emp ON emp.id=jp.emp_id
          WHERE jp.status=1";
    try {
        $db   = getConnection();
        $stmt = $db->query($sql);
        $jobs = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db   = null;
        echo '{"jobs": ' . json_encode($jobs) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});




//get my transaction
$app->post('/transact/getMyTransaction', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    //$id = $req->get('id');
    
    
    $sql = "SELECT `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `transType`, `points`, `discount`, `priceTag`, `comment`, `status`, `createdDate`, `transDate` FROM `transaction`
				WHERE `serialNo`='$serialnum' order by transDate desc limit 10";
    
    
    try {
        $db     = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"transactions": ' . json_encode($result) . '}';
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});


//get banners

$app->get('/home/banners', function() use ($app)
{
    $response = array();
    
    
   
    
    $sql = "SELECT  `hoe`, `spix`, `bpix`, `body`, `desc`, `web`, `date`, `time`, `ip`, `admin` FROM `ban`";
    
    
    try {
        $db     = getConnection();
        //$stmt = $db->query($sql);
        $stmt   = $db->query($sql);
        //$stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        { echo json_encode($response); };
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
    
});


//get my Wallet Balance
$app->post('/wallet/getMybalance', function() use ($app)
{
    $response = array();
    //$user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    //$response = array();
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    
    $sql = "SELECT  wa.agentId, wa.merchantId, wa.submerchantId, wa.serialNo, wa.accruedpoints, wa.tierpoint, wa.redeemableamt, wa.tierLevel, wa.comment, csub.submerchantName, csub.submerchantimage  FROM $dbname.wallet wa JOIN moloyalc_master.config_submerchant csub ON csub.submerchantId = wa.submerchantId   WHERE wa.serialNo='$serialnum' or wa.serialNo=''";
    
    /*SELECT jp.id,jp.job_title,jp.experience,jp.location,jp.skill_required,
    jp.job_description,DATE_FORMAT(jp.date_posted,'%M %d,  %Y') AS date_posted,
    DATE_FORMAT(jp.expiry_date,'%M %d,  %Y') AS expiry_date,
    sec.name,emp.company_name
    FROM job_postings jp JOIN sectors sec ON sec.id=jp.sector_id
    JOIN employers emp ON emp.id=jp.emp_id
    WHERE jp.status=1";*/
    
    // $sql = "SELECT wa.agentId, wa.merchantId, wa.submerchantId,  wa.serialNo,  wa.accruedpoints,  wa.tierpoint,  wa.redeemableamt,  //wa.tierLevel FROM wallet  WHERE `serialNo`='$serialnum'";
    
    
    try {
        $db   = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt = $db->query($sql);
        
        $result = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db     = null;
        echo '{"wallet": ' . json_encode($result) . '}';
        
        
        //$stmt->execute();
        // $result = $stmt->fetch();
        //if($result){
        //$bal['id']=$result['sn'];
        // $bal['wBalance']=intval($result['wBalance']);
        
        // $response['error']=false;
        // $response['bal'] = $bal;
        
        // }else{
        //$response['error']=true;
        //$response['error']="No Points found";
        //}
        //$db = null;
        //echo json_encode($response);
        
        
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = getMessage();
    }
    
});




//update user profile

$app->post('/user/update', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $email = $request->email;
    $firstname = $request->firstname;
    $lastname  = $request->lastname;
     $network  = $request->mobilenetwork;
    $othername = $request->othername;
    $userId    = $request->UserId;
    $address   = $request->address;
    $id        = $request->id;
    
    //$skill = $skill . ',';
    
    
     $sql3 = "SELECT sn,street1, city, state, userId, firstName, lastName, email, mobilenetwork FROM config_user WHERE sn=$id";
    
    
        
    
    $sql = "UPDATE config_user SET `firstName`=:firstname, lastName=:lastname,email=:email,mobilenetwork=:network,
 userId=:userid,street1=:address WHERE sn='$id'";
    
    try {
        $db   = getConnection();
        $stmt = $db->prepare($sql);
        
        $stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
         $stmt->bindParam(":network", $network, PDO::PARAM_STR);
        $stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        //$stmt->bindParam(":othername", $othername,PDO::PARAM_STR);
        $stmt->bindParam(":userid", $userId, PDO::PARAM_STR);
        $stmt->bindParam(":address", $address, PDO::PARAM_STR);
        
        if($id==''){
            
             $response['error'] = true;
             $response['message'] = 'id not passed';
        }else{
            
        
        $stmt->execute();
        
        $errorInfo = $stmt->errorInfo();
        if (isset($errorInfo[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfo[2];
            echo json_encode($response);
        } else {
            $response['error'] = false;
             $response['message'] = 'profile has been updated';
        }
        
        $stmt3 = $db->query($sql3);
        $stmt3->execute();
        $result = $stmt3->fetch();
        if ($result) {
            $user['id']        = $result['sn'];
            $user['firstname'] = $result['firstName'];
            $user['lastname']  = $result['lastName'];
            $user['email']     = $result['email'];
            $user['mobilenetwork']     = $result['mobilenetwork'];
            $user['city']      = $result['city'];
            $user['state']     = $result['state'];
            $user['userId']    = $result['userId'];
            $user['street1']   = $result['street1'];
            $response['error'] = false;
            $response['user']  = $user;
            
        } else {
            $response['error'] = true;
            $response['message'] = "No profile found";
        }
        
        }
        // if($stmt->rowCount()){
        //   $response['error']=false;
        // }else{
        //   $response['error']=true;
        //   $response['message']="There was an error contacting the server";
        // }
        echo json_encode($response);
        
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
});





$app->get('/user/profile', function() use ($app)
{
    $response = array();
    $user     = array();
    $req      = $app->request();
    $id       = $req->get('id');
    
    $sql = "SELECT sn,street1, city, state, userId, firstName, lastName, email, mobilenetwork FROM config_user WHERE sn=$id";
    
    try {
        $db   = getConnection();
        $stmt = $db->query($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        if ($result) {
            $user['id']        = $result['sn'];
            $user['firstname'] = $result['firstName'];
            $user['lastname']  = $result['lastName'];
            $user['email']     = $result['email'];
            $user['mobilenetwork']     = $result['mobilenetwork'];
            $user['city']      = $result['city'];
            $user['state']     = $result['state'];
            $user['userId']    = $result['userId'];
            $user['street1']   = $result['street1'];
            $response['error'] = false;
            $response['user']  = $user;
            
        } else {
            $response['error'] = true;
            $response['error'] = "No profile found";
        }
        $db = null;
        echo json_encode($response);
    }
    catch (PDOException $e) {
        $response['error'] = true;
        $response['error'] = getMessage();
    }
    
});


//get User Line Graph Values
$app->post('/graph/getLineGraphdata', function() use ($app)
{
    $response = array();
    $user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $res      = array();
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    //$id = $req->get('id');
    
    $sql = "SELECT   `transAmount`,   `transDate` from transaction WHERE  `transType` =  'R' AND  `serialNo` = '$serialnum' order by transdate desc limit 14";
    
    $sql2 = "SELECT  `transAmount`,   `transDate` from transaction WHERE  `transType` =  'A' AND  `serialNo` = '$serialnum' order by transdate desc limit 14";
    
    
    
    
    try {
        $db               = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt             = $db->query($sql);
        $stmt2            = $db->query($sql2);
        //$stmt->execute();
        $result           = $stmt->fetchAll(PDO::FETCH_OBJ);
        $result2          = $stmt2->fetchAll(PDO::FETCH_OBJ);
        $res[graphredeem] = $result;
        $res[graphaccrue] = $result2;
        $db               = null;
        echo json_encode($res);
        // echo '{"graphaccrue": ' . json_encode($result2) . '}';
        
    }
    catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
});

//get Graph2 details
$app->post('/graph/getGraphdata', function() use ($app)
{
     $response = array();
    //$user     = array();
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    //$response = array();
    
    $dbname = $request->dbname;
    
    $id        = $request->id;
    $serialnum = $request->serialnum;
    //$id = $req->get('id');
    
    
    $sql  = "SELECT COUNT(`transType`) AS RedemTrans
FROM transaction
WHERE  `transType` =  'R'  AND  `serialNo` = '$serialnum'";
    $sql2 = "SELECT COUNT(`transType`) AS AccuralTrans
FROM transaction
WHERE  `transType` =  'A' AND  `serialNo` = '$serialnum' ";
    //    $sql3 = "SELECT COUNT(`transType`) AS AccuralTrans
    //FROM transaction
    //WHERE  `transType` =  'A';
    //$sql ="SELECT * FROM applications where user_id=$id";
    try {
        $db    = getDynamicConnection($dbname);
        //$stmt = $db->query($sql);
        $stmt  = $db->query($sql);
        $stmt2 = $db->query($sql2);
        $stmt->execute();
        $res[redeem] = $stmt->fetch();
        $stmt2->execute();
        $res[accrue] = $stmt2->fetch();
        //$stmt->execute();
        //$res[redeem] = $stmt->fetchAll(PDO::FETCH_OBJ);
        //$res[accrue] = $stmt2->fetchAll(PDO::FETCH_OBJ);
        $response[]  = $res;
        
        $db = null;
        echo json_encode($res);
        
        
        
        
        
        
        
        
        
    }
    catch (PDOException $e) {
        echo '{"error":' . $e->getMessage() . '}}';
    }
    
    
});



//API SECTION


$app->post('/user/logintest', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $userno   = $request->userno;
    $password = $request->password;
    $password = md5($password);
    
    
    //$sql = "SELECT   sn, email,password,userId FROM config_user WHERE userId=:userno and password=:password";
    //try {
    //  $db = getConnection();
    //$stmt = $db->prepare($sql);
    //$stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    
    
    
    
    $sql2 = "SELECT CM.`merchantName` , CM.`merchantDb` , CM.`merchantEmail` ,CM.`tier_ratio` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` ,UM.`tierLevel` ,U.`userId`, U.`firstName` ,
	                           U.`lastName` ,U.`default` ,U.`email` , U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 

 JOIN `config_merchant` CM ON CM.merchantId=UM.merchantId
JOIN `config_submerchant` SM ON SM.submerchantId=:submerid

	WHERE SM.submerchantId =:submerid
             AND SM.`password`=:password
								LIMIT 1";
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":submerid", $userno, PDO::PARAM_STR);
        $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
        //$stmt2->bindParam(":merchantId", $merchantId,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $merchantDB = $result['merchantDb'];
        
        if ($result) {
            
            
            if ($merchantDB) {
                //$response['error']=$postdata;
                $response['id']         = $result['sn'];
                $response['email']      = $result['email'];
                $response['default']    = $result['default'];
                $response['merchantDb'] = $result['merchantDb'];
                $response['serialNo']   = $result['serialNo'];
                 $response['message']    = "user logged in";
            $response['status']     = "1";
            } else {
                $response['status']   = 0;
                $response['message'] = "wrong user id or password";
            }
            
        } else {
            $response['status']   = 0;
            $response['message'] = "wrong user id or password";
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['status']   = 0;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});



//get aLL MeRchants
$app->post('/refer/merchant', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    //$request  = json_decode($postdata);
    $response = array();
    
    
    
    //$sql = "SELECT   sn, email,password,userId FROM config_user WHERE userId=:userno and password=:password";
    //try {
    //  $db = getConnection();
    //$stmt = $db->prepare($sql);
    //$stmt->bindParam(":userno",$userno,PDO::PARAM_STR);
    //$stmt->bindParam(":password", $password,PDO::PARAM_STR);
    //$stmt->execute();
    //$errorInfo = $stmt->errorInfo();
    //if(isset($errorInfo[2])){
    //  $response['error']=true;
    //  $response['message']=$errorInfo[2];
    //  echo json_encode($response);
    //}
    // $resulta = $stmt->fetch();
    // $merchantId= $resulta['merchantId'];
    // $userId= $resulta['userId'];
    
    $ttl=1;
    $sql2 = "SELECT CM.`submerchantName` ,CM.`submerchantId` ,  CM.`submerchantImage` ,UM.`merchantId`,   UM.`referStatus`
								FROM `config_submerchant` CM
                 
 JOIN `loyaltysettings` UM ON UM.submerchantId=CM.submerchantId
WHERE UM.`referStatus` ='$ttl'";
    
    
    
    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
       
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
       // $result     = $stmt2->fetch();
        //$merchantDB = $result['merchantDb'];
         //echo json_encode($response);
       while ($result = $stmt2->fetch()) {
            
            
                //$response['error']=$postdata;
                $res['referStatus']         = $result['referStatus'];
                 $res['submerchantImage']  = $result['submerchantImage'];
                $res['submerchantId']      = $result['submerchantId'];
                $res['submerchantName']    = $result['submerchantName'];
                $res['merchantId'] = $result['merchantId'];
                //$response['serialNo']   = $result['serialNo'];
            
            
         array_push($response, $res);
            
        }
        
        echo json_encode($response);
        
       // $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});




//Do referal

$app->post('/users/referral', function() use ($app)
{
    $postdata   = file_get_contents("php://input");
    $request    = json_decode($postdata);
    $response   = array();
    $expiryDate = date('Y-m-d', strtotime('+20 years'));
    $senderid  = $request->senderid;
   // $merchantIdarray  = $request->submerchantId;
    $phoneno    = $request->phoneno;
    
    //$senderid  = 201500000001;
    //$merchantIdarray  = ["201501", "201503"];
    //$phoneno    = 07011883388;
    
     //$email    = 'oluodebiyi@gmail.com';
    
   
    $email       = $request->email;
    //$merchantId  = $request->merchantId;
    //$merchantId  =$request->params('merchantId');
    $dateCreated = date("Y-m-d");
    
  

    $sql = "INSERT INTO  `multilevel`( `parent_id`, `child_phone`, `child_email`, `submerchantId`, `activated`,`datecreated`)
 VALUES (:parid,:childphone,:childemail,:merchantId,0,:datecreated)";
    
    //auto assign SerialNo
    $chek = "SELECT * FROM `multilevel` where parent_id=:parid and child_email=:childemail and submerchantId=:merchantId";
     
    //auto assign SerialNo
     $getserialcode = "SELECT * FROM `config_user_merchant_info` where serialNo=:parent";
     $db2   = getConnection();
    $stmt2 = $db2->prepare($getserialcode);
    $stmt2->bindParam(":parent", $senderid);
     $stmt2->execute();
    
    $resultas    = $stmt2->fetch();
    
    $userId = $resultas['userId'];
    
    
    $getrefcode = "SELECT * FROM `config_user` where userId=:userid";
     $db1   = getConnection();
    $stmt1 = $db1->prepare($getrefcode);
    $stmt1->bindParam(":userid", $userId);
    
    $stmt1->execute();
    
    $resulta    = $stmt1->fetch();
    $str = $resulta['userId'];
    $firstname = $resulta['firstName'];
     $lastname = $resulta['lastName'];
    //post info in conig_user_merchant_info
   // $qrypostinfo = "INSERT INTO `config_user_merchant_info`(`userId`,`merchantId`, `serialNo`,`tierLevel`)
   // VALUES(:phone,:merchantId,:serialno,'1')";
    
    
    
    
    
    
   
            
            try {
                 
                $j='201506';
                 $db   = getConnection();
                $qrySerialNo = $db->prepare($chek);
                $qrySerialNo->bindParam(":parid", $senderid, PDO::PARAM_STR);
                $qrySerialNo->bindParam(":childemail", $email, PDO::PARAM_STR);
                
                $qrySerialNo->bindParam(":merchantId", $j, PDO::PARAM_STR);
                
    $qrySerialNo->execute();
    $results = $qrySerialNo->fetch();
    $child_email = $results['child_email'];
    if ($child_email!='') {
     $response['error']   = true;
                $response['message'] = 'Email has been refered before';
    }else{

               $db   = getConnection();
                $stmt = $db->prepare($sql);
                $stmt->bindParam(":parid", $senderid, PDO::PARAM_STR);
                $stmt->bindParam(":childemail", $email, PDO::PARAM_STR);
                 $stmt->bindParam(":childphone", $phoneno, PDO::PARAM_STR);
                $stmt->bindParam(":merchantId", $j, PDO::PARAM_STR);
                $stmt->bindParam(":datecreated", $dateCreated, PDO::PARAM_STR);
               
                
                $stmt->execute();
           $tt=0;


                $from    = "noreply@moloyal.com";
                $to      = $email;
                $msg     = 'You have been referred by '. $firstname.' '.$lastname.' on the MoLoyal Loyalty Program. <br>click the link below to complete your registration: <br><br>https://www.moloyal.com/refer/'.$str.'<br>';
                $subject = "Moloyal Referral";
                $type    = "Moloyal Referral";
                sendEmail($from, $to, $msg, $subject, $type);
                
                 if ($tt==0) {
                $response['error']   = false;
                $response['message'] = "Your referral is successful";
            } else {
                $response['error']   = true;
                $response['message'] = "There was an error contacting the server";
                
                
                
            }
    }
               
                
            
            
            echo json_encode($response);
         }
            catch (PDOException $e) {
                $response['error']   = true;
                $response['message'] = $e->getMessage();
                echo json_encode($response);
                
            }
           
    
});


//get aLL stores
$app->get('/all/stores', function() use ($app)
{
   
    $response = array();
    
    
   
    
    $sql2 = "SELECT CM.`submerchantName` ,CM.`submerchantId` ,  CM.`submerchantImage`
								FROM `config_submerchant` CM";
                 

    
    
    //             $sql2="Select * from config_user where userId=:usernos and password=:password";
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
       
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
       
       while ($result = $stmt2->fetch()) {
            
            
                //$response['error']=$postdata;
                $res['referStatus']         = $result['referStatus'];
                 $res['submerchantImage']  = $result['submerchantImage'];
                $res['submerchantId']      = $result['submerchantId'];
                $res['submerchantName']    = $result['submerchantName'];
                $res['merchantId'] = $result['merchantId'];
                //$response['serialNo']   = $result['serialNo'];
            
            
         array_push($response, $res);
            
        }
        
        echo json_encode($response);
        
       // $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});






//buy airtime



$app->post('/users/payment', function() use ($app)
{
    $postdata = file_get_contents("php://input");
    $request  = json_decode($postdata);
    $response = array();
    $phoneno   = $request->phoneno;
    $reffnos   = $request->refno;
    $email = $request->email;
     $amount = $request->amount;
      $mobilenetwork = $request->network;
     $merchantId  = $request->merchantId;
     
   
   
    if($mobilenetwork=='MTN'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='Glo'){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9mobile'){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
	  
 

 $dateCreated = date("Y-m-d g:i:s");
 
    // insert ref to $reffnos
    $sql2 = "INSERT INTO airtimepurchase(phoneno, network, transAmount)VALUES ('$phoneno','$mobilenetwork', '$amount')";
                    
                   
    
    
    
    
    
   
    try {
         //$db         = getConnection();
       
        $db2   =  getConnection();
        $stmt9 = $db2->prepare($sql2);
      
                 /*   $stmt9->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
                    $stmt9->bindParam(":network", $mobilenetwork, PDO::PARAM_STR);
                    $stmt9->bindParam(":amount", $amount, PDO::PARAM_STR);
                    $stmt9->bindParam(":createddate", $datecreated, PDO::PARAM_STR);
                  */ 

        
       // $res=;
        $errorInfos = $stmt9->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = 'test';
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt9->fetch();
       // $merchantDB = $result['merchantDb'];
        
        if ($stmt9->execute()) {
             $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://34.244.205.139/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];

  curl_close($curl);
$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://34.244.205.139/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$amount&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$phoneno",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);


            $response['error']   = false;
            $response['message'] = 'airtime dispensed successfully ';
           
        } else {
            $response['error']   = true;
            $response['message'] = 'airtime not dispensed ';
            
        }
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = $phoneno;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});


$app->post('/user/accrualtest', function() use ($app)
{
    $postdata       = file_get_contents("php://input");
    $request        = json_decode($postdata);
    $response       = array();
    $userno         = $request->userno;
    $serialNo         = $request->userno;
    $password       = $request->password;
    $transamount    = $request->transamt;
    $submerchant_id = $request->submerchantid;
    $agent_id       = $request->agentid;
    $password       = md5($password);
    $merchant_id    = substr($submerchant_id, 0, 4);
    
    
        
       
        $transtype = 'A';
       
        $createdDate = date("Y-m-d H:i:s");
        $transDate = date("Y-m-d H:i:s");
    
    
    
    
    $sql3 = "SELECT * FROM `loyaltysettings` WHERE `merchantId`=:merchantId and `submerchantId`=:submerchantId";
    
    $billingqry = "SELECT * FROM `billing_setup` WHERE merchantId=:merchantId and submerchantid=:submerchantId";
    
    
    
    $sql2 = "SELECT CM.`merchantName` , CM.`merchantDb` , CM.`merchantEmail` ,CM.`tier_ratio` , UM.`userId` ,UM.`merchantId`, UM.`serialNo` ,UM.`tierLevel` ,U.`userId`, U.`firstName` ,
	                           U.`lastName` ,U.`default` ,U.`email` , U.`status` , U.`dateCreated` , U.`sn`
								FROM `config_user_merchant_info` UM
                  JOIN 

`config_user` U ON U.UserId=UM.UserId 

 JOIN `config_merchant` CM ON CM.merchantId=UM.merchantId
JOIN `config_submerchant` SM ON SM.submerchantId=:submerid

	WHERE SM.submerchantId =:submerid
             AND SM.`password`=:password
								LIMIT 1";
    
    
    
    
    
    try {
        $db2   = getConnection();
        $stmt2 = $db2->prepare($sql2);
        $stmt2->bindParam(":usernos", $userno, PDO::PARAM_STR);
        $stmt2->bindParam(":password", $password, PDO::PARAM_STR);
        $stmt2->bindParam(":submerid", $submerchant_id,PDO::PARAM_STR);
        
        $stmt2->execute();
        $errorInfos = $stmt2->errorInfo();
        if (isset($errorInfos[2])) {
            $response['error']   = true;
            $response['message'] = $errorInfos[2];
            echo json_encode($response);
        }
        $result     = $stmt2->fetch();
        $merchantDB = $result['merchantDb'];
        
        if ($result) {
            
            
           /* $response['id']         = $userno;
            $response['email']      = $result['email'];
            $response['default']    = $result['default'];
           
            $response['merchantDb'] = $result['merchantDb'];
            $response['serialNo']   = $result['serialNo'];
            $response['submer']     = $submerchant_id;
            $response['mer']        = $merchant_id;
           
            $response['tierLevels'] = $result['tierLevel'];
            $response['tier_ratio'] = $result['tier_ratio']; */
            
             $tier_ratio             = $result['tier_ratio'];
            $tierLevels             = $result['tierLevel']; 
             $userid = $result['userId'];
             //$serialNo= $result['serialNo'];
            $response['message']    = "user logged in";
            $response['status']     = "1";
            //get redemption and accrual ratios
            $db3                    = getConnection();
            $stmt3                  = $db3->prepare($sql3);
            $stmt3->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
            $stmt3->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
            
            $stmt3->execute();
            $result3                      = $stmt3->fetch();
           // $response['redemption_ratio'] = $result3['redemption_ratio'];
           // $response['accural_ratio']    = $result3['accural_ratio'];
            $redemption_ratio             = $result3['redemption_ratio'];
            $accural_ratio                = $result3['accural_ratio'];
            
            
            //get billing percentage
            
            $stmt4 = $db2->prepare($billingqry);
            $stmt4->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
            $stmt4->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
            
            $stmt4->execute();
            $result4 = $stmt4->fetch();
            
            $billingpercentage = $result4['percentage'];
            $billingrate       = $result4['rate'];
            
           // $response['billingpercentage'] = $result4['percentage'];
           // $response['billingrate']       = $result4['rate'];
            
            
            
            if ($accural_ratio != 0 && $redemption_ratio != 0 && $tier_ratio != 0 && $billingpercentage != 0 && $billingrate != 0) {
                
                
                 $db        = getDynamicConnection($merchantDB);
                $walletqry = "SELECT * FROM `wallet` WHERE serialNo=:serialNo and submerchantId=:submerchantId";
                $stmt5     = $db->prepare($walletqry);
                $stmt5->bindParam(":serialNo", $serialNo , PDO::PARAM_STR);
                $stmt5->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                
                $stmt5->execute();
                $result5                 = $stmt5->fetch();
                //$response['tierLevels2'] = $result5['tierLevel'];
                $accruedpoints           = $result5['accruedpoints'] == null ? 0 : $result5['accruedpoints'];
                $tierpoint               = $result5['tierpoint'] == null ? 0 : $result5['tierpoint'];
                $tierlevel               = $result5['tierLevel'] == null ? 1 : $result5['tierLevel'];
                $redeemableamt           = $result5['redeemableamt'] == null ? 0.00 : $result5['redeemableamt'];
                
               // $response['tierLevels3'] = $tierlevel;
                $getTier                 = "SELECT * FROM `tier_setup` WHERE tierLevel=:tierLevels and merchantId=:merchantId";
                $stmt6                   = $db2->prepare($getTier);
                $stmt6->bindParam(":tierLevels", $tierLevels, PDO::PARAM_STR);
                
                $stmt6->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                
                $stmt6->execute();
                $result6                     = $stmt6->fetch();
                $instorepntquota             = $result6[instorePntQuota];
                $tierpntquota                = $result6[tierpntquota];
                //$response['tierpntquota']    = $tierpntquota;
                //$response['instorepntquota'] = $instorepntquota;
                
                
                if ($tierpoint != 0 && $tierpoint >= $tierpntquota) {
                    //Calculate Vendor Billing
                    $billamtpercent = ($transamount * $billingpercentage) / 100;
                    $billamtrate    = $billingrate;
                    
                    $preferredbillamt = max($billamtpercent, $billamtrate);
                    
                    //check for expiry and reset here
                    //Reset Accural and Redemption When moved to Next Tier
                    
                    $naccrue    = 0;
                    $nredeemamt = $redeemableamt;
                    $ntierpnt   = 0;
                    $ntierLevel = $tierLevels + 1;
                    
                    //get Maximum Tier level from tier_setup table
                    
                    $maxquery = "SELECTMAX( tierLevel ) as tlevel FROM  `tier_setup`";
                    $stmt7    = $db2->prepare($maxquery);
                    
                    
                    $stmt7->execute();
                    $result7 = $stmt7->fetch(PDO::FETCH_ASSOC);
                    
                    $tierLevele = $result7['tlevel'];
                    
                    if ($ntierLevel > $tierLevele) {
                        $ntierLevel = $tierLevele;
                    }
                    
                    $upqry = "UPDATE `config_user_merchant_info` SET `tierLevel`=:ntierLevel where serialNo=:serialNo
									and merchantId=:merchantId";
                    
                    $stmt8 = $db2->prepare($upqry);
                    $stmt8->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                    $stmt8->bindValue(":serialNo", $serialNo , PDO::PARAM_STR);
                    
                    $stmt8->bindValue(":merchantId", $merchant_id, PDO::PARAM_STR);
                    
                    $stmt8->execute();
                    
                    
                    
                    //$delqry = mysqli_query($con,"DELETE FROM `wallet` WHERE serialNo='$serialNo'");
                    
                }else {
                    
                    //Calculate Vendor Billing
                    $billamtpercent = ($transamount * $billingpercentage) / 100;
                    $billamtrate    = $billingrate;
                    
                    $preferredbillamt = max($billamtpercent, $billamtrate);
                    
                    //$response['accural_ratio']    = $accural_ratio;
                    //Calculate accrual Points
                    $newaccuralpoints             = $transamount * $accural_ratio;
                    //$response['newaccuralpoints'] = $newaccuralpoints;
                    //$response['transamount']      = $transamount;
                    
                    //Calculate Redemption Amount
                    //$nredeemamt = $redeemableamt + ($newaccuralpoints / $redemption_ratio);
                    
                    $nredeemamt = $redeemableamt + ($transamount / $redemption_ratio);
                    $nredeemamt = round($nredeemamt, 2);
                    
                    $response['nredeemamt '] = $nredeemamt;
                    
                    //Increament accurals in wallet
                    $naccrue = $accruedpoints + $newaccuralpoints;
                    
                    
                    $response['naccrue '] = $naccrue;
                    
                    
                    
                    //Calculate ntierPoint
                    $ntierpnt              = $naccrue / $tier_ratio;
                    $ntierpnt              = floor($ntierpnt);
                    $ntierLevel            = $tierLevels;
                    $response['ntierpnt '] = $ntierpnt;
                    
                    if ($ntierpnt >= $tierpntquota) {
                        
                        //check for expiry and reset here
                        //Reset Accural  When moved to Next Tier
                        
                        $naccrue = 0;
                        
                        $ntierpnt   = 0;
                        $ntierLevel = $tierLevels + 1;
                        
                        
                        //get Maximum Tier level from tier_setup table
                        
                        $maxquery = "SELECTMAX( tierLevel ) as tlevel FROM  `tier_setup`";
                        $stmt7    = $db2->prepare($maxquery);
                        
                        
                        $stmt7->execute();
                        $result7                = $stmt7->fetch(PDO::FETCH_ASSOC);
                        $tierLevele             = $result7['tlevel'];
                        $response['tierLevele'] = $tierLevele;
                        if ($ntierLevel > $tierLevele) {
                            $ntierLevel = $tierLevele;
                        }
                        
                        
                        $upqry = "UPDATE `config_user_merchant_info` SET `tierLevel`=:ntierLevel where serialNo=:serialNo
										and merchantId=:merchantId";
                        $stmt8 = $db2->prepare($upqry);
                        $stmt8->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                        $stmt8->bindValue(":serialNo", $serialNo, PDO::PARAM_STR);
                        
                        $stmt8->bindValue(":merchantId", $merchant_id, PDO::PARAM_STR);
                        
                        $stmt8->execute();
                        //$ntierLevel = $tierLevels;
                    }
                    
                }
                
                //if userrecord  available already
                if ($result5) {
                    //update
                    
                    
                    
                    
                    $addpoint_qry = "UPDATE `wallet` SET `accruedpoints`=:naccrue,`redeemableamt`=:nredeemamt,`tierLevel`=:ntierLevel,`tierpoint`=:ntierpnt where serialNo=:serialNo and submerchantId=:submerchantId";
                    
                    $stmt9 = $db->prepare($addpoint_qry);
                    $stmt9->bindValue(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt9->bindValue(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":naccrue", $naccrue, PDO::PARAM_STR);
                    $stmt9->bindParam(":nredeemamt", $nredeemamt, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierLevel", $ntierLevel, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierpnt", $ntierpnt, PDO::PARAM_STR);
                    
                    
                    
                }
            
         else {
                    
                    $comment      = 'autopost from loyalty';
                    //insert
                    $addpoint_qry = "INSERT INTO `wallet`(`agentId`, `merchantId`, `submerchantId`, `serialNo`, `accruedpoints`,`tierpoint`, `redeemableamt`, `comment`)
									VALUES (:agentid,:merchantId,:submerchantId,:serialNo,:naccrue, :ntierpnt, :nredeemamt, :comment)";
                    
                    $stmt9 = $db->prepare($addpoint_qry);
                    $stmt9->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt9->bindParam(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt9->bindParam(":naccrue", $naccrue, PDO::PARAM_STR);
                    $stmt9->bindParam(":ntierpnt", $ntierpnt, PDO::PARAM_STR);
                    
                    $stmt9->bindParam(":nredeemamt", $nredeemamt, PDO::PARAM_STR);
                    $stmt9->bindParam(":comment", $comment, PDO::PARAM_STR);
                }
                
                // $stmt9->execute();
                
                if ($accuralpoints != 0) {
                    $comment = $accuralpoints . " points ";
                }
                
                $tes=$stmt9->execute();
                if ($tes=='true') {
                    $qry = "INSERT INTO `transaction`(`submerchantId`,`userId`, `agentId`, `serialNo`, `transAmount`,`transType`, `points`,													 `priceTag`, `comment`, `status`, `createdDate`, `transDate`)
													   VALUES(:submerchantId,:userid,:agentid,:serialNo,:transamount,:transtype,:newaccuralpoints,
																 :priceamt,:comment,:status,:createdDate,:transDate)";
                    
                    //$qryresult = mysqli_query($link2, $qry) or die(mysqli_error($link2));
                    $stmt_tran = $db->prepare($qry);
                    
                     $stmt_tran ->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":userid", $userid, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":serialNo", $serialNo, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":transamount", $transamount, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":transtype", $transtype, PDO::PARAM_STR);
                    
                    $stmt_tran ->bindParam(":newaccuralpoints", $newaccuralpoints, PDO::PARAM_STR);
                        $stmt_tran ->bindParam(":priceamt", $priceamt, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":status", $status, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":createdDate", $createdDate, PDO::PARAM_STR);
                    
                    $stmt_tran ->bindParam(":transDate", $transDate, PDO::PARAM_STR);
                    $stmt_tran ->bindParam(":comment", $comment, PDO::PARAM_STR);
                    $stmt_tran->execute();
                    $transactionid = $db->lastInsertId();
                    
                    $billcomment = $preferredbillamt . " bill charged on " . $transamount;
                    
                    
                    $qry5      = "INSERT INTO `billing_record`(`merchantId`, `submerchantId`, `agentId`, `transactionId`, `transAmount`, `billAmount`, `comment`,`transDate`)
									VALUES(:merchantId,:submerchantId,:agentid,:transactionid,:transamount,:preferredbillamt,:billcomment,:transDate)";
                   $stmt_bill = $db->prepare($qry5);
                    $stmt_bill->bindParam(":agentid", $agent_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":merchantId", $merchant_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":submerchantId", $submerchant_id, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":transactionid", $transactionid, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":transamount", $transamount, PDO::PARAM_STR);
                    $stmt_bill->bindParam(":preferredbillamt", $preferredbillamt, PDO::PARAM_STR);
                    
                    $stmt_bill->bindParam(":billcomment", $billcomment, PDO::PARAM_STR);
                      
                    $stmt_bill->bindParam(":transDate", $transDate, PDO::PARAM_STR);
                    $stmt_bill->execute();
                    //$qryresult5 = mysqli_query($link2, $qry5) or die(mysqli_error($link2));
                     $response['message']    = "accrual transaction succesful";
            $response['status']     = "4";
                    
                }
                
                //end
                
                
            } else {
                
                $response['message'] = "Loyalty matrix has not been configured, please contact admin";
                $response['status']  = "0";
            }
            
            
            
            
            
            
            
            
            
            
            
        } else {
            
            $response['error']   = true;
            $response['message'] = "wrong user id or password";
            $response['status']  = "0";
            
        }
        
        echo json_encode($response);
        
        $db  = null;
        $db2 = null;
    }
    catch (PDOException $e) {
        $response['error']   = true;
        $response['message'] = $e->getMessage();
        echo json_encode($response);
        
    }
    //} catch(PDOException $e) {
    //$response['error']=true;
    //$response['message']=$e->getMessage();
    //echo json_encode($response);
    
    //}
});





//FUNCTIONS

function isPhoneExist($phoneno)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_user WHERE userId=:phoneno");
    $stmt->bindParam(":phoneno", $phoneno, PDO::PARAM_STR);
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result) {
        return true;
    } else {
        return false;
    }
}

function isEmailExist($email)
{
    $db   = getConnection();
    $stmt = $db->prepare("SELECT * from config_user WHERE email =:email");
    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
    
    
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result) {
        return true;
    } else {
        return false;
    }
}


function sendEmail($from, $to, $msg, $subject, $type)
{
    
   $from = "noreply@moloyal.com"; //enter your email address
    
   
    
    $text    = $msg; // text versions of email.
    $message = '<html>
<head>

<style type="text/css">
html { -webkit-text-size-adjust:none; -ms-text-size-adjust: none;}
@media only screen and (max-device-width: 680px), only screen and (max-width: 680px) {
	*[class="table_width_100"] {
		width: 96% !important;
	}
	*[class="border-right_mob"] {
		border-right: 1px solid #dddddd;
	}
	*[class="mob_100"] {
		width: 100% !important;
	}
	*[class="mob_center"] {
		text-align: center !important;
	}
	*[class="mob_center_bl"] {
		float: none !important;
		display: block !important;
		margin: 0px auto;
	}
	.iage_footer a {
		text-decoration: none;
		color: #929ca8;
	}
	img.mob_display_none {
		width: 0px !important;
		height: 0px !important;
		display: none !important;
	}
	img.mob_width_50 {
		width: 40% !important;
		height: auto !important;
	}
}
.table_width_100 {
	width: 680px;
}
</style>
</head>

<body style="padding: 0px; margin: 0px;">
<div id="mailsub" class="notification" align="center">

<table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 320px;"><tr><td align="center" bgcolor="#eff3f8">


<!--[if gte mso 10]>
<table width="680" border="0" cellspacing="0" cellpadding="0">
<tr><td>
<![endif]-->

<table border="0" cellspacing="0" cellpadding="0" class="table_width_100" width="100%" style="max-width: 680px; min-width: 300px;">
	<!--header -->
	<tr><td align="center" bgcolor="#eff3f8">
		<!-- padding --><div style="height: 20px; line-height: 20px; font-size: 10px;">&nbsp;</div>
		<table width="96%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="left"><!--

				Item --><div class="mob_center_bl" style="float: left; display: inline-block; width: 115px;">
					<table class="mob_center" width="115" border="0" cellspacing="0" cellpadding="0" align="left" style="border-collapse: collapse;">
						<tr><td align="left" valign="middle">
							<!-- padding --><div style="height: 20px; line-height: 20px; font-size: 10px;">&nbsp;</div>
							<table width="115" border="0" cellspacing="0" cellpadding="0" >
								<tr><td align="left" valign="top" class="mob_center">
									<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 13px;">
									<font face="Arial, Helvetica, sans-seri; font-size: 13px;" size="3" color="#596167">
									<img src="http://moloyal.com/email-imgs/mologo.jpg" width="115" height="19" alt="Moloyal" border="0" style="display: block;" /></font></a>
								</td></tr>
							</table>
						</td></tr>
					</table></div><!-- Item END--><!--[if gte mso 10]>
					</td>
					<td align="right">
				<![endif]--><!--

				Item --><div class="mob_center_bl" style="float: right; display: inline-block; width: 88px;">
					<table width="88" border="0" cellspacing="0" cellpadding="0" align="right" style="border-collapse: collapse;">
						<tr><td align="right" valign="middle">
							<!-- padding --><div style="height: 20px; line-height: 20px; font-size: 10px;">&nbsp;</div>
							<table width="100%" border="0" cellspacing="0" cellpadding="0" >
								<tr><td align="right">
									<!--social -->
									<div class="mob_center_bl" style="width: 88px;">
									<table border="0" cellspacing="0" cellpadding="0">
										<tr><td width="30" align="center" style="line-height: 19px;">
											<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 12px;">
											<font face="Arial, Helvetica, sans-serif" size="2" color="#596167">
											<img src="https://moloyal.com/email-imgs/facebook.gif" width="10" height="19" alt="Facebook" border="0" style="display: block;" /></font></a>
										</td><td width="39" align="center" style="line-height: 19px;">
											<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 12px;">
											<font face="Arial, Helvetica, sans-serif" size="2" color="#596167">
											<img src="https://moloyal.com/email-imgs/twitter.gif" width="19" height="16" alt="Twitter" border="0" style="display: block;" /></font></a>
										</td><td width="29" align="right" style="line-height: 19px;">
											<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 12px;">
											<font face="Arial, Helvetica, sans-serif" size="2" color="#596167">
											<img src="https://moloyal.com/email-imgs/dribbble.gif" width="19" height="19" alt="Dribbble" border="0" style="display: block;" /></font></a>
										</td></tr>
									</table>
									</div>
									<!--social END-->
								</td></tr>
							</table>
						</td></tr>
					</table></div><!-- Item END--></td>
			</tr>
		</table>
		<!-- padding --><div style="height: 30px; line-height: 30px; font-size: 10px;">&nbsp;</div>
	</td></tr>
	<!--header END-->

	<!--content 1 -->
	<tr><td align="center" bgcolor="#ffffff">
		<table width="90%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center">
				<!-- padding --><div style="height: 100px; line-height: 100px; font-size: 10px;">&nbsp;</div>
				<div style="line-height: 44px;">
					<font face="Arial, Helvetica, sans-serif" size="5" color="#57697e" style="font-size: 34px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 30px; color: #57697e;">
						' . $type . '
					</span></font>
				</div>
				<!-- padding --><div style="height: 30px; line-height: 30px; font-size: 10px;">&nbsp;</div>
			</td></tr>
			<tr><td align="center">
				<div style="line-height: 30px;">
					<font face="Arial, Helvetica, sans-serif" size="5" color="#4db3a4" style="font-size: 17px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 17px; color: #4db3a4;">
						Hello ' . $txtfirstName . ', </span></font>
				</div>
				<!-- padding --><div style="height: 35px; line-height: 35px; font-size: 10px;">&nbsp;</div>
			</td></tr>
			<tr><td align="center">
						<table width="80%" align="center" border="0" cellspacing="0" cellpadding="0">
							<tr><td align="center">
								<div style="line-height: 24px;">
									<font face="Arial, Helvetica, sans-serif" size="4" color="#57697e" style="font-size: 16px;">
									<span style="font-family: Arial, Helvetica, sans-serif; font-size: 15px; color: #57697e;">
										' . $msg . '
					</span></font>
								</div>
							</td></tr>
						</table>
				<!-- padding --><div style="height: 45px; line-height: 45px; font-size: 10px;">&nbsp;</div>
			</td></tr>
			<tr><td align="center">
				<!--<div style="line-height:24px;">
					<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 13px;">
						<font face="Arial, Helvetica, sans-seri; font-size: 13px;" size="3" color="#596167">
							<img src="https://moloyal.com/email-imgs/confirm-reg.gif" width="225" height="43" alt="CONFIRM REGISTRATION" border="0" style="display: block;" /></font></a>
				</div>-->
				<!-- padding --><div style="height: 100px; line-height: 100px; font-size: 10px;">&nbsp;</div>
			</td></tr>
		</table>
	</td></tr>
	<!--content 1 END-->

	<!--links -->
	<tr><td align="center" bgcolor="#f9fafc">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center">
				<!-- padding --><div style="height: 30px; line-height: 30px; font-size: 10px;">&nbsp;</div>
        <table width="80%" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="middle" style="font-size: 12px; line-height:22px;">
            	<font face="Tahoma, Arial, Helvetica, sans-serif" size="2" color="#282f37" style="font-size: 12px;">
								<span style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #5b9bd1;">
		              <a href="#" target="_blank" style="color: #5b9bd1; text-decoration: none;">GENERAL QUESTIONS</a>
		              &nbsp;&nbsp;&nbsp;&nbsp;<img src="https://moloyal.com/email-imgs/dot.gif" alt="|" width="6" height="9" class="mob_display_none" /></a>&nbsp;&nbsp;&nbsp;&nbsp;
		              <a href="#" target="_blank" style="color: #5b9bd1; text-decoration: none;">TERMS &amp; CONDITIONS</a>
		              &nbsp;&nbsp;&nbsp;&nbsp;<img src="https://moloyal.com/email-imgs/dot.gif" alt="|" width="6" height="9" class="mob_display_none" />&nbsp;&nbsp;&nbsp;&nbsp;
		              <a href="#" target="_blank" style="color: #5b9bd1; text-decoration: none;">UNSUBSCRIBE EMAIL</a>
              </span></font>
            </td>
          </tr>
        </table>
			</td></tr>
			<tr><td><!-- padding --><div style="height: 30px; line-height: 30px; font-size: 10px;">&nbsp;</div></td></tr>
		</table>
	</td></tr>
	<!--links END-->

	<!--footer -->
	<tr><td class="iage_footer" align="center" bgcolor="#eff3f8">
		<!-- padding --><div style="height: 40px; line-height: 40px; font-size: 10px;">&nbsp;</div>

		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center">
				<font face="Arial, Helvetica, sans-serif" size="3" color="#96a5b5" style="font-size: 13px;">
				<span style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #96a5b5;">
					2016 &copy; Moloyal. ALL Rights Reserved.
				</span></font>
			</td></tr>
		</table>

		<!-- padding --><div style="height: 50px; line-height: 50px; font-size: 10px;">&nbsp;</div>
	</td></tr>
	<!--footer END-->
</table>
<!--[if gte mso 10]>
</td></tr>
</table>
<![endif]-->

</td></tr>
</table>

</div>
</body>
</html>';
    
  //$to='oluodebiyi@gmail.com';
  
require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

$text = ''; // text versions of email.
$html = $message; // html versions of email.

$crlf = "\n";

$mime = new Mail_mime($crlf);
$mime->setTXTBody($text);
$mime->setHTMLBody($html);

//do not ever try to call these lines in reverse order
$body = $mime->get();
$headers = $mime->headers($headers);

 $host = "localhost"; // all scripts must use localhost
 $username = "noreply@moloyal.com"; //  your email address (same as webmail username)
 $password = "6)][3W#OTkRu"; // your password (same as webmail password)

$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
'username' => $username,'password' => $password));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
return 0;
//echo("<p>" . $mail->getMessage() . "</p>");
}
else {
return 1;

//echo("<p>Message successfully sent!</p>");
// header("Location: http://www.example.com/");
}









   

}


//Generate Random Number
function random()
{
    $characters = 8;
    $letters    = '23456789bcdfghjkmnpqrstvwxyz';
    $str        = '';
    for ($i = 0; $i < $characters; $i++) {
        $str .= substr($letters, mt_rand(0, strlen($letters) - 1), 1);
    }
    return $str;
}





function getConnection()
{
    $dbhost = "localhost";
    $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    
    $dbname = "moloyalc_master_test";
    //  $dbhost="localhost";
    //  $dbuser="root";
    //  $dbpass="";
    //  $dbname="moloyalc_master";
    $dbh    = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}


function getDynamicConnection($dbname)
{
    //    $dbhost="localhost";
    //    $dbuser="root";
    //    $dbpass="";
    //    $dbname=$dbname;
    
    $dbhost = "localhost";
    $dbuser = "moloyalc_user2";
    $dbpass = "Welcome12*£";
    $dbname = $dbname;
    
    
    $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbh;
}




$app->run();

?>
