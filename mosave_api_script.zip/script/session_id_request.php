<?php $curl = curl_init();
echo $posdate = date("Y-m-d");
       echo $posdatetime = date("Y-m-d G:i:s a");
	   
	   echo $newunix= date("YmdGis");
	   $phoneno='08076544464';
	   echo $mobilen=substr($phoneno,0,3);
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://91.109.117.92/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
  $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];
echo $token.'sesid<br>';

echo $ref_no.'ref<br>';

?>